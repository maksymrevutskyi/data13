
1) SC5C0
   please set "DEVICE=AME_MZ0380" in MAKEFILE then make

2) make

Step1. Copy below files in firmware folder to /lib/firmware/
	

	MZ*



Step2. Copy LXV4L2D_MZ0380.ko to your module directory.

cp LXV4L2D_MZ0380.ko /lib/modules/`uname -r`/

Step3. Add LXV4L2D_MZ0380.ko to modules.dep.

depmod -a

Step4. Load LXV4L2D_MZ0380.ko module.

modprobe LXV4L2D_MZ0380

Note: after driver loading, please use dmesg to check if 

��FIRMWARE VERSION: xxx�� is the same as ��BOARD VERSION:xxx��
Otherwise, reboot


If ��invalid module format�� error occurs, try to use �Vf parameter.

modprobe -f LXV4L2D_MZ0380


######################
Module Uninstallation#
######################

modprobe -r LXV4L2D_MZ0380




######################
NOTE: MZ0380 (SC5C0 or SC3C0)
1)enlarge memory allocation at system boot for 32 bit OS,

  for Fedora, update menu.lst, add "vmalloc=512M" after "quiet"

  for Ubuntu 11.10
	find "/etc/default/grub" and edit the line "GRUB_CMDLINE_LINUX_DEFAULT". Now, add the option:
	vmalloc=512MB
	GRUB_CMDLINE_LINUX_DEFAULT="quiet splash vmalloc=512MB"
	sudo update-grub

2)SC3C0 preview only support 720*480/576

3) driver with default debug message, it can be rmove by following in LINUXV4L2.h

//#define F966EAAB748564259849CBD3F3D6C48A7( level, msg... )	printk( level "[LINUXV4L2] : " msg )

#define F966EAAB748564259849CBD3F3D6C48A7( level, msg... )
