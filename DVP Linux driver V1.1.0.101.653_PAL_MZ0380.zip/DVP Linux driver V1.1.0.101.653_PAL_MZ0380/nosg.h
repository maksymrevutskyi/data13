#ifndef NOSG_H

#define NOSG_H

BYTE NOSG_LOGO[ 153600 ] = { 0x10 };

#endif