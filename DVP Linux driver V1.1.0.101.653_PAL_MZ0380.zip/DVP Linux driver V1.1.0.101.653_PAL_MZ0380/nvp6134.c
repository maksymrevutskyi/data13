#include "nvp6134.h"

extern F42A18AF66EFF459eA332CA253FFF8A65 * g_pDevice[ 128 ];

BYTE NVP6134_GetRegister( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, BYTE nIndex )
{
	#ifdef AME_MZ0380

		return E6FB1249C1F642A38BC0228741149CD8( pDevice, 0, 0x60, nIndex );

	#endif

	return 0x00;
}

BOOL NVP6134_SetRegister( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, BYTE nIndex, BYTE nValue )
{
	#ifdef AME_MZ0380

		return DBF051EEA3B648B49859145F02FA268C( pDevice, 0, 0x60, nIndex, nValue );

	#endif

	return TRUE;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#if 1

VOID NVP6134_SET_COMMON_VALUE( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG chnmode ) // [HUENGPEI] [2017.02.05.16110301] 
{
	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );

	NVP6134_SetRegister( pDevice, 0x00 + (i % 4), 0x10 );

	NVP6134_SetRegister( pDevice, 0x23 + (i % 4) * 4, 0x43 );

	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), 0x10 );

	NVP6134_SetRegister( pDevice, 0x34 + (i % 4), 0x02 ); // 08.25

	NVP6134_SetRegister( pDevice, 0x93 + (i % 4), 0x00 ); // HZOOM OFF

	// ANALOG IP - EQ BYPASS
	//
	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );

	NVP6134_SetRegister( pDevice, 0x00, 0xC0 ); // CLAMP SPEED

	NVP6134_SetRegister( pDevice, 0x01, 0x02 ); // BACKEND ANTIALIASING FILTER BANDWIDTH 50MHZ

	NVP6134_SetRegister( pDevice, 0x08, 0x50 );

	NVP6134_SetRegister( pDevice, 0x11, 0x06 );

	NVP6134_SetRegister( pDevice, 0x23, 0x00 ); // PN INIT

	NVP6134_SetRegister( pDevice, 0x2A, 0x52 );

	NVP6134_SetRegister( pDevice, 0x58, 0x02 );	// ANALOG IP ( F7F93DF8A9ECE49c1884C75ADC18648B7 [ 5 ~ 8 ], 0x58 [7 ~ 4] : 0 (BYPASS), [3 ~ 0] : 10M, 20M, 50M, 80M )

	NVP6134_SetRegister( pDevice, 0x59, 0x11 ); // ANALOG FILTER BYPASS (BYPASS ON)

	NVP6134_SetRegister( pDevice, 0xB8, 0xB9 ); // H-PLL NO VIDEO OPTION THESE WILL BE RECOVERY BY EQ ROUTINE

	NVP6134_SetRegister( pDevice, 0xC8, 0x04 ); // FOR EQ (COMMON)
	
	// INITIALIZE ANALOG IP: EQ BYPASS AND EQ
	//
	NVP6134_SetRegister( pDevice, 0xFF, 0x0A + (i % 4) / 2 );

	NVP6134_SetRegister( pDevice, 0x74 + (i % 2) * 0x80, 0x02 );
	
	// SET VFC PARAMETER
	//
	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );

	NVP6134_SetRegister( pDevice, 0x64, 0x98 ); 

	NVP6134_SetRegister( pDevice, 0x6A, 0x18 );

	NVP6134_SetRegister( pDevice, 0x6B, 0xFF ); 

	// INITIALIZE DIGITAL EQ: DISABLE DIGITAL EQ ( CH1=9x80, CH2=9xA0,  CH3=9xC0, CH4=9xE0 )
	//
	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );

	NVP6134_SetRegister( pDevice, 0x80 + (i % 4) * 0x20, 0x00 );

	NVP6134_SetRegister( pDevice, 0x81 + (i % 4) * 0x20, 0x00 );

	 // RECOVERY F7F93DF8A9ECE49c1884C75ADC18648B7A DATA
	//
	NVP6134_SetRegister( pDevice, 0xFF, 0x0A + (i % 4) / 2 );

	NVP6134_SetRegister( pDevice, 0x60 + (i % 2) * 0x80, 0x02 );

	NVP6134_SetRegister( pDevice, 0x61 + (i % 2) * 0x80, 0x01 ); 

	NVP6134_SetRegister( pDevice, 0x62 + (i % 2) * 0x80, 0x00 ); 

	NVP6134_SetRegister( pDevice, 0x63 + (i % 2) * 0x80, 0x01 ); 

	NVP6134_SetRegister( pDevice, 0x64 + (i % 2) * 0x80, 0x03 ); 

	NVP6134_SetRegister( pDevice, 0x65 + (i % 2) * 0x80, 0xA0 ); 

	NVP6134_SetRegister( pDevice, 0x66 + (i % 2) * 0x80, 0x04 ); 

	NVP6134_SetRegister( pDevice, 0x67 + (i % 2) * 0x80, 0x03 ); 

	NVP6134_SetRegister( pDevice, 0x68 + (i % 2) * 0x80, 0x03 ); 

	NVP6134_SetRegister( pDevice, 0x69 + (i % 2) * 0x80, 0x0B ); 

	NVP6134_SetRegister( pDevice, 0x6A + (i % 2) * 0x80, 0x0A ); 

	NVP6134_SetRegister( pDevice, 0x6B + (i % 2) * 0x80, 0x11 ); 

	NVP6134_SetRegister( pDevice, 0x6C + (i % 2) * 0x80, 0x0D ); 

	NVP6134_SetRegister( pDevice, 0x6D + (i % 2) * 0x80, 0x06 ); 

	NVP6134_SetRegister( pDevice, 0x6E + (i % 2) * 0x80, 0x27 );

	NVP6134_SetRegister( pDevice, 0x6F + (i % 2) * 0x80, 0x00 ); 

	NVP6134_SetRegister( pDevice, 0x70 + (i % 2) * 0x80, 0x4E ); 

	NVP6134_SetRegister( pDevice, 0x71 + (i % 2) * 0x80, 0x6D ); 

	NVP6134_SetRegister( pDevice, 0x72 + (i % 2) * 0x80, 0x74 ); 
}												    	 

VOID NVP6134_SETCHN_COMMON_CVBS( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_COMMON_CVBS( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x00 + (i % 4), 0x00 ); 

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x00, 0xC0 );
	NVP6134_SetRegister( pDevice, 0x01, 0x00 ); 
	NVP6134_SetRegister( pDevice, 0x58, 0x00 ); 
	NVP6134_SetRegister( pDevice, 0x59, 0x00 ); 
	NVP6134_SetRegister( pDevice, 0x5B, 0x03 ); 

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x08 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0xDD : 0xA0 );
	NVP6134_SetRegister( pDevice, 0x0C + (i % 4), 0x08 );
	NVP6134_SetRegister( pDevice, 0x10 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x88 : 0x88 );
	NVP6134_SetRegister( pDevice, 0x14 + (i % 4), 0x90 );
	NVP6134_SetRegister( pDevice, 0x18 + (i % 4), 0x08 );
	NVP6134_SetRegister( pDevice, 0x21 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x02 : 0x82 );
	NVP6134_SetRegister( pDevice, 0x3C + (i % 4), 0x84 );
	NVP6134_SetRegister( pDevice, 0x44 + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x48 + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x4C + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	BYTE ycmerge = NVP6134_GetRegister( pDevice, 0xED ); CLE_BIT( ycmerge, (i % 4) );
	NVP6134_SetRegister( pDevice, 0xED, ycmerge );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x69, 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x47, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0x04 );
	NVP6134_SetRegister( pDevice, 0x50, (vfmt == NVP6134_STD_PAL) ? 0x84 : 0x84 );
	NVP6134_SetRegister( pDevice, 0x84, 0x00 );
	NVP6134_SetRegister( pDevice, 0x86, 0x00 );
	NVP6134_SetRegister( pDevice, 0xD1, (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x57, 0x00 );
	NVP6134_SetRegister( pDevice, 0x90, 0x01 );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x08, 0x50 );     
	NVP6134_SetRegister( pDevice, 0x11, 0x04 );
	NVP6134_SetRegister( pDevice, 0x1B, (vfmt == NVP6134_STD_PAL) ? 0x20 : 0x20 );
	NVP6134_SetRegister( pDevice, 0x24, (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x2A );  
	NVP6134_SetRegister( pDevice, 0x25, (vfmt == NVP6134_STD_PAL) ? 0xCA : 0xDA );
	NVP6134_SetRegister( pDevice, 0x26, 0x30 );
	NVP6134_SetRegister( pDevice, 0x29, 0x30 ); 
	NVP6134_SetRegister( pDevice, 0x2A, 0x52 ); 
	NVP6134_SetRegister( pDevice, 0x2B, 0xA8 );					

	NVP6134_SetRegister( pDevice, 0x5F, 0x70 );
	NVP6134_SetRegister( pDevice, 0x56, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );	
	NVP6134_SetRegister( pDevice, 0x90, (vfmt == NVP6134_STD_PAL) ? 0x0D : 0x01 );
	NVP6134_SetRegister( pDevice, 0x9B, 0x80 );
	NVP6134_SetRegister( pDevice, 0xB5, 0x00 );
	NVP6134_SetRegister( pDevice, 0xB7, 0xFF );
	NVP6134_SetRegister( pDevice, 0xB8, 0xB8 );
	NVP6134_SetRegister( pDevice, 0xBB, (vfmt == NVP6134_STD_PAL) ? 0xB8 : 0xB8 );
	NVP6134_SetRegister( pDevice, 0xD1, (vfmt == NVP6134_STD_PAL) ? 0x20 : 0x00 );  

	NVP6134_SetRegister( pDevice, 0x20, (vfmt == NVP6134_STD_PAL) ? 0x84 : 0x84 );	
	NVP6134_SetRegister( pDevice, 0x27, (vfmt == NVP6134_STD_PAL) ? 0x57 : 0x57 );	
	NVP6134_SetRegister( pDevice, 0x76, (vfmt == NVP6134_STD_PAL) ? 0x01 : 0x01 );	

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x6E, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x6F, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	BYTE pn_set = NVP6134_GetRegister( pDevice, 0x44 ); CLE_BIT( pn_set, (i % 4) );
	NVP6134_SetRegister( pDevice, 0x44, pn_set );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0xCB : 0x1E );
	NVP6134_SetRegister( pDevice, 0x51 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x8A : 0x7C );
	NVP6134_SetRegister( pDevice, 0x52 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x09 : 0xF0 );
	NVP6134_SetRegister( pDevice, 0x53 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x2A : 0x21 );	
	NVP6134_SetRegister( pDevice, 0x97 + (i % 4) * 0x20, 0x00 );
	NVP6134_SetRegister( pDevice, 0x98 + (i % 4) * 0x20, 0x00 );
	NVP6134_SetRegister( pDevice, 0x99 + (i % 4) * 0x20, 0x00 );
  
	NVP6134_SetRegister( pDevice, 0xFF, 0x02 );
	NVP6134_SetRegister( pDevice, 0x02 + (i % 4) * 0x07, 0x03 );
	NVP6134_SetRegister( pDevice, 0x28 + (i % 4) * 0x06, 0x01 );
	NVP6134_SetRegister( pDevice, 0x29 + (i % 4) * 0x06, 0x3C );
	NVP6134_SetRegister( pDevice, 0x2A + (i % 4) * 0x06, (vfmt == NVP6134_STD_PAL) ? 0x0C : 0x0A );
	NVP6134_SetRegister( pDevice, 0x2B + (i % 4) * 0x06, 0x06 );
	NVP6134_SetRegister( pDevice, 0x2C + (i % 4) * 0x06, 0x36 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x11 );
	NVP6134_SetRegister( pDevice, 0x00 + (i % 4) * 0x20, 0x00 );
}

VOID NVP6134_SETCHN_720H( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_720H( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_COMMON_CVBS( pDevice, i, vfmt );

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x47 : 0x47 );
	NVP6134_SetRegister( pDevice, 0x8c + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0xA6 : 0xA6 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x70 : 0x60 );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x18 + (i % 4), 0x14 );
	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x30 : 0x40 );
	NVP6134_SetRegister( pDevice, 0x5C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x1E : 0x1E );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x2D : 0x28 );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x30 : 0x30 );
	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x18 : 0x08 );
	NVP6134_SetRegister( pDevice, 0xA4 + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x64, 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x02 );
	NVP6134_SetRegister( pDevice, 0x28 + (i % 4) * 0x06, 0x00 );
	NVP6134_SetRegister( pDevice, 0x29 + (i % 4) * 0x06, 0x2D );
	NVP6134_SetRegister( pDevice, 0x2A + (i % 4) * 0x06, (vfmt == NVP6134_STD_PAL) ? 0x0C : 0x0A );
	NVP6134_SetRegister( pDevice, 0x2C + (i % 4) * 0x06, 0x27 );
}

VOID NVP6134_SETCHN_960H( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_960H( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_COMMON_CVBS( pDevice, i, vfmt );

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x47 : 0x47 );	
	NVP6134_SetRegister( pDevice, 0x8C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0xA6 : 0xA6 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x80 : 0x80 );
	NVP6134_SetRegister( pDevice, 0x5C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x1E : 0x1E );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x2D : 0x28 );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x03 : 0x00 );
	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x08 : 0x08 );
	NVP6134_SetRegister( pDevice, 0xA4 + (i % 4), 0x00 );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x64, 0x00 );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x02 );
	NVP6134_SetRegister( pDevice, 0x28 + (i % 4) * 0x06, 0x01 );
	NVP6134_SetRegister( pDevice, 0x29 + (i % 4) * 0x06, 0x3C );
	NVP6134_SetRegister( pDevice, 0x2A + (i % 4) * 0x06, (vfmt == NVP6134_STD_PAL) ? 0x0C : 0x0A );
	NVP6134_SetRegister( pDevice, 0x2C + (i % 4) * 0x06, 0x36 );
}

VOID NVP6134_SETCHN_1280H( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_1280H( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_COMMON_CVBS( pDevice, i, vfmt );

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x47 :0x47 );	
	NVP6134_SetRegister( pDevice, 0x8C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x06 :0x06 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 :0x00 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x30 :0x20 );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4),0x00);

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x80 : 0x80 );
	NVP6134_SetRegister( pDevice, 0x5C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x1E : 0x1E );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x2D : 0x28 );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x07 : 0x0A );
	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x18 : 0x08 );
	NVP6134_SetRegister( pDevice, 0xA4 + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x64, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x01 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x02 );
	NVP6134_SetRegister( pDevice, 0x28 + (i % 4) * 0x06, 0x00 );
	NVP6134_SetRegister( pDevice, 0x29 + (i % 4) * 0x06, 0x50 );
	NVP6134_SetRegister( pDevice, 0x2A + (i % 4) * 0x06, (vfmt == NVP6134_STD_PAL) ? 0x0C : 0x0A );
	NVP6134_SetRegister( pDevice, 0x2C + (i % 4) * 0x06, 0x4A );
}

VOID NVP6134_SETCHN_1440H( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_1440H( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_COMMON_CVBS( pDevice, i, vfmt );

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x47 : 0x47 );
	NVP6134_SetRegister( pDevice, 0x8C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x06 : 0x06 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x50 : 0x40 );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x20 );
	NVP6134_SetRegister( pDevice, 0x5C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x1E : 0x1E );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x2D : 0x28 );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x08 : 0x07 );
	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x18 : 0x08 );
	NVP6134_SetRegister( pDevice, 0xA4 + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x97 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x98 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x99 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x56, (vfmt == NVP6134_STD_PAL) ? 0x08 : 0x08 );	
	NVP6134_SetRegister( pDevice, 0x64, 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x02 );
	NVP6134_SetRegister( pDevice, 0x28 + (i % 4) * 0x06, 0x00 );
	NVP6134_SetRegister( pDevice, 0x29 + (i % 4) * 0x06, 0x5A );
	NVP6134_SetRegister( pDevice, 0x2A + (i % 4) * 0x06, (vfmt == NVP6134_STD_PAL) ? 0x0C : 0x0A );
	NVP6134_SetRegister( pDevice, 0x2C + (i % 4) * 0x06, 0x54 );
}

VOID NVP6134_SETCHN_1920H( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_1920H( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_COMMON_CVBS( pDevice, i, vfmt );

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x47 : 0x47 );
	NVP6134_SetRegister( pDevice, 0x8C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x06 : 0x06 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0xB0 : 0xA0 );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x80 : 0x80 );
	NVP6134_SetRegister( pDevice, 0x5C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x1E : 0x1E );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x2D : 0x28 );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x18 : 0x08 );
	NVP6134_SetRegister( pDevice, 0xA4 + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x64, 0x00 );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x02 );
	NVP6134_SetRegister( pDevice, 0x28 + (i % 4) * 0x06, 0x01 );
	NVP6134_SetRegister( pDevice, 0x29 + (i % 4) * 0x06, 0x78 );
	NVP6134_SetRegister( pDevice, 0x2A + (i % 4) * 0x06, (vfmt == NVP6134_STD_PAL) ? 0x0C : 0x0A );
	NVP6134_SetRegister( pDevice, 0x2C + (i % 4) * 0x06, 0x72 );
}

VOID NVP6134_SETCHN_3840H( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_3840H( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_COMMON_CVBS( pDevice, i, vfmt );

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x47 : 0x47 ); 
	NVP6134_SetRegister( pDevice, 0x8C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x46 : 0x46 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0xD0 : 0xC0 );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x84 : 0x84 );
	NVP6134_SetRegister( pDevice, 0x5C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x1E : 0x1E );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x2D : 0x28 );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x08 : 0x06 );
	NVP6134_SetRegister( pDevice, 0x93 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x01 : 0x01 );
	NVP6134_SetRegister( pDevice, 0x98 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x0D : 0x07 );
	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x18 : 0x08 );
	NVP6134_SetRegister( pDevice, 0xA4 + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x64, 0x00 );
	   
	NVP6134_SetRegister( pDevice, 0xFF, 0x02 );
	NVP6134_SetRegister( pDevice, 0x28 + (i % 4) * 0x06, 0x01 );
	NVP6134_SetRegister( pDevice, 0x29 + (i % 4) * 0x06, 0xF0 );
	NVP6134_SetRegister( pDevice, 0x2A + (i % 4) * 0x06, (vfmt == NVP6134_STD_PAL) ? 0x0C : 0x0A );
	NVP6134_SetRegister( pDevice, 0x2C + (i % 4) * 0x06, 0xEA );
}

VOID NVP6134_SETCHN_COMMON_720P( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_COMMON_720P( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x00 + (i % 4), 0x00 ); 

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x00, 0xC0 );
	NVP6134_SetRegister( pDevice, 0x01, 0x02 );  
	NVP6134_SetRegister( pDevice, 0x58, 0x02 );  
	NVP6134_SetRegister( pDevice, 0x59, 0x00 );
	NVP6134_SetRegister( pDevice, 0x5B, 0x03 );
	NVP6134_SetRegister( pDevice, 0x69, 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x0C + (i % 4), 0x08 );
	NVP6134_SetRegister( pDevice, 0x10 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x8D : 0x8B );
	NVP6134_SetRegister( pDevice, 0x14 + (i % 4), 0x90 );
	NVP6134_SetRegister( pDevice, 0x18 + (i % 4), 0x20 );
	NVP6134_SetRegister( pDevice, 0x21 + (i % 4) * 0x04, 0x92 );
	NVP6134_SetRegister( pDevice, 0x3C + (i % 4), 0x84 );
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x01 : 0xF7 );
	NVP6134_SetRegister( pDevice, 0x44 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x20 : 0x1A );
	NVP6134_SetRegister( pDevice, 0x48 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x11 : 0x11 );
	NVP6134_SetRegister( pDevice, 0x4C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0xF6 : 0xF4 );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0xF5 : 0xF6 );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x47, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0x04 );
	NVP6134_SetRegister( pDevice, 0x50, (vfmt == NVP6134_STD_PAL) ? 0x84 : 0x84 );
	NVP6134_SetRegister( pDevice, 0x20, (vfmt == NVP6134_STD_PAL) ? 0x87 : 0x86 );
	NVP6134_SetRegister( pDevice, 0x27, (vfmt == NVP6134_STD_PAL) ? 0x57 : 0x57 );
	NVP6134_SetRegister( pDevice, 0x76, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x57, 0x00 );
	NVP6134_SetRegister( pDevice, 0x90, 0x01 );
	NVP6134_SetRegister( pDevice, 0x2B, 0xA8 );
	NVP6134_SetRegister( pDevice, 0xB8, 0x38 );                 

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x6E, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x6F, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	BYTE ycmerge = NVP6134_GetRegister( pDevice, 0xED ); CLE_BIT( ycmerge, (i % 4) );
	NVP6134_SetRegister( pDevice, 0xED, ycmerge );

	NVP6134_SetRegister( pDevice, 0xFF, 0x02 );
	NVP6134_SetRegister( pDevice, 0x02 + (i % 4) * 0x07, 0x23 );
	NVP6134_SetRegister( pDevice, 0x28 + (i % 4) * 0x06, 0x11 );
	NVP6134_SetRegister( pDevice, 0x29 + (i % 4) * 0x06, 0x50 );
	NVP6134_SetRegister( pDevice, 0x2A + (i % 4) * 0x06, 0x1E );
	NVP6134_SetRegister( pDevice, 0x2B + (i % 4) * 0x06, 0x06 );
	NVP6134_SetRegister( pDevice, 0x2C + (i % 4) * 0x06, 0x4A );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	BYTE pn_set = NVP6134_GetRegister( pDevice, 0x44 ); CLE_BIT( pn_set, (i % 4) );
	NVP6134_SetRegister( pDevice, 0x44, pn_set );
	NVP6134_SetRegister( pDevice, 0x97 + (i % 4) * 0x20, 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x11 );
	NVP6134_SetRegister( pDevice, 0x00 + (i % 4) * 0x20, 0x00 );	
}

VOID NVP6134_SETCHN_AHD_720P( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_AHD_720P( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_COMMON_720P( pDevice, i, vfmt );

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x8C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x0A : 0x0A );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x08 + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x07 : 0x06 );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x08 : 0x08 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x80 : 0x80 );
	NVP6134_SetRegister( pDevice, 0x5C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x1E : 0x1E );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x31 : 0x32 );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0xA4 + (i % 4), 0x09 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x97 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x98 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x99 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x1B, (vfmt == NVP6134_STD_PAL) ? 0x08 : 0x08 );
	NVP6134_SetRegister( pDevice, 0x24, (vfmt == NVP6134_STD_PAL) ? 0x20 : 0x20 );  
	NVP6134_SetRegister( pDevice, 0x25, 0xDC );  
	NVP6134_SetRegister( pDevice, 0x26, 0xF0 );
	NVP6134_SetRegister( pDevice, 0x29, 0x00 );
	NVP6134_SetRegister( pDevice, 0x2A, 0x52 );
	NVP6134_SetRegister( pDevice, 0x5F, 0x00 );
	NVP6134_SetRegister( pDevice, 0x84, 0x00 );
	NVP6134_SetRegister( pDevice, 0x86, 0x00 );
	NVP6134_SetRegister( pDevice, 0x90, 0x01 );
	NVP6134_SetRegister( pDevice, 0x9B, 0x80 );
	NVP6134_SetRegister( pDevice, 0xB5, 0x00 );
	NVP6134_SetRegister( pDevice, 0xB7, 0xFF );
	NVP6134_SetRegister( pDevice, 0xB8, 0x38 );
	NVP6134_SetRegister( pDevice, 0xBB, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0x04 );
	NVP6134_SetRegister( pDevice, 0xD1, 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x45 : 0xED );
	NVP6134_SetRegister( pDevice, 0x51 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x08 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x52 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x10 : 0xE5 );
	NVP6134_SetRegister( pDevice, 0x53 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x4F : 0x4E );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
}

VOID NVP6134_SETCHN_AHD_720PEX( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_AHD_720PEX( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_COMMON_720P( pDevice, i, vfmt );

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 ); 
	NVP6134_SetRegister( pDevice, 0x8C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x40 : 0x40 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x11 );
	NVP6134_SetRegister( pDevice, 0x00 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x0D : 0x0D );
	NVP6134_SetRegister( pDevice, 0x01 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x02 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x80 : 0x80 );
	NVP6134_SetRegister( pDevice, 0x03 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x0A : 0x0A );
	NVP6134_SetRegister( pDevice, 0x04 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x05 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x0F : 0x0C );
	NVP6134_SetRegister( pDevice, 0x06 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x78 : 0xE4 );
	NVP6134_SetRegister( pDevice, 0x07 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x08 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0xDC : 0xDC );
	NVP6134_SetRegister( pDevice, 0x10 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x11 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0xF8 : 0xF8 );
	NVP6134_SetRegister( pDevice, 0x12 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x01 : 0x01 );
	NVP6134_SetRegister( pDevice, 0x13 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0xA4 : 0xA4 );
	NVP6134_SetRegister( pDevice, 0x14 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x15 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x33 : 0x33 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x08 + (i % 4), 0x60 );
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x0E : 0x0F );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x04 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x80 : 0x80 );
	NVP6134_SetRegister( pDevice, 0x5C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x1E : 0x1E );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x31 : 0x32 );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x20 : 0x21 );
	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), 0x08 );
	NVP6134_SetRegister( pDevice, 0xA4 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x97 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x98 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x99 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x1B, (vfmt == NVP6134_STD_PAL) ? 0x08 : 0x08 );
	NVP6134_SetRegister( pDevice, 0x24, (vfmt == NVP6134_STD_PAL) ? 0x20 : 0x20 );
	NVP6134_SetRegister( pDevice, 0x25, 0xDB );	
	NVP6134_SetRegister( pDevice, 0x26, 0xF0 );
	NVP6134_SetRegister( pDevice, 0x29, 0x00 );
	NVP6134_SetRegister( pDevice, 0x2A, 0x52 );
	NVP6134_SetRegister( pDevice, 0x5F, 0x00 );
	NVP6134_SetRegister( pDevice, 0x75, 0x00 );
	NVP6134_SetRegister( pDevice, 0x84, 0x01 );
	NVP6134_SetRegister( pDevice, 0x86, 0x20 );
	NVP6134_SetRegister( pDevice, 0x90, 0x01 );
	NVP6134_SetRegister( pDevice, 0x9B, 0x80 );
	NVP6134_SetRegister( pDevice, 0xB5, 0x00 );
	NVP6134_SetRegister( pDevice, 0xB7, 0xFF );
	NVP6134_SetRegister( pDevice, 0xB8, 0x38 );
	NVP6134_SetRegister( pDevice, 0xBB, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0x04 );
	NVP6134_SetRegister( pDevice, 0xD1, 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	BYTE pn_set = NVP6134_GetRegister( pDevice, 0x44 ); SET_BIT( pn_set, (i % 4) );
	NVP6134_SetRegister( pDevice, 0x44, pn_set );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x22 : 0x76 );
	NVP6134_SetRegister( pDevice, 0x51 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0x80 );
	NVP6134_SetRegister( pDevice, 0x52 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x88 : 0x72 );
	NVP6134_SetRegister( pDevice, 0x53 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x27 : 0x27 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x02 );
	NVP6134_SetRegister( pDevice, 0x29 + (i % 4) * 0x06, 0xA0 );
	NVP6134_SetRegister( pDevice, 0x2C + (i % 4) * 0x06, 0x9A );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x0A + ((i % 4) / 2) );
	NVP6134_SetRegister( pDevice, 0x60 + (i % 2) * 0x80, 0x2A );
	NVP6134_SetRegister( pDevice, 0x61 + (i % 2) * 0x80, 0x03 );
	NVP6134_SetRegister( pDevice, 0x62 + (i % 2) * 0x80, 0x07 );
	NVP6134_SetRegister( pDevice, 0x63 + (i % 2) * 0x80, 0x05 );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 2) * 0x80, 0x07 );
	NVP6134_SetRegister( pDevice, 0x65 + (i % 2) * 0x80, 0xA0 );
	NVP6134_SetRegister( pDevice, 0x66 + (i % 2) * 0x80, 0x14 );
	NVP6134_SetRegister( pDevice, 0x67 + (i % 2) * 0x80, 0x12 );
	NVP6134_SetRegister( pDevice, 0x68 + (i % 2) * 0x80, 0x06 );
	NVP6134_SetRegister( pDevice, 0x69 + (i % 2) * 0x80, 0x22 );
	NVP6134_SetRegister( pDevice, 0x6A + (i % 2) * 0x80, 0x0A );
	NVP6134_SetRegister( pDevice, 0x6B + (i % 2) * 0x80, 0x26 );
	NVP6134_SetRegister( pDevice, 0x6C + (i % 2) * 0x80, 0x04 );
	NVP6134_SetRegister( pDevice, 0x6D + (i % 2) * 0x80, 0x29 );
	NVP6134_SetRegister( pDevice, 0x6E + (i % 2) * 0x80, 0x38 );
	NVP6134_SetRegister( pDevice, 0x6F + (i % 2) * 0x80, 0x18 );
	NVP6134_SetRegister( pDevice, 0x70 + (i % 2) * 0x80, 0x15 );
	NVP6134_SetRegister( pDevice, 0x71 + (i % 2) * 0x80, 0x24 );
	NVP6134_SetRegister( pDevice, 0x72 + (i % 2) * 0x80, 0xC0 );
}

VOID NVP6134_SETCHN_EXC_720P( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_EXC_720P( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x8c + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x20 : 0x20 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x07 : 0x06 );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4),0x02);

	NVP6134_SETCHN_COMMON_720P( pDevice, i, vfmt );	

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x08 + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x30 : 0x30 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x07 : 0x06 );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x02 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x80 : 0x80 );
	NVP6134_SetRegister( pDevice, 0x5C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x1E : 0x1E );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x2E : 0x2E );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x01 );
	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), 0x08 );
	NVP6134_SetRegister( pDevice, 0xA4 + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x97 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x29 : 0x19 );
	NVP6134_SetRegister( pDevice, 0x98 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0xC0 : 0xA2 );
	NVP6134_SetRegister( pDevice, 0x99 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x01 : 0x01 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x1B, (vfmt == NVP6134_STD_PAL) ? 0x08 : 0x08 );
	NVP6134_SetRegister( pDevice, 0x20, (vfmt == NVP6134_STD_PAL) ? 0x90 : 0x90 );
	NVP6134_SetRegister( pDevice, 0x24, (vfmt == NVP6134_STD_PAL) ? 0x30 : 0x30 );
	NVP6134_SetRegister( pDevice, 0x25, (vfmt == NVP6134_STD_PAL) ? 0xDC : 0xDC );
	NVP6134_SetRegister( pDevice, 0x26, 0x30 );
	NVP6134_SetRegister( pDevice, 0x29, 0x00 );
	NVP6134_SetRegister( pDevice, 0x2A, 0xD2 );
	NVP6134_SetRegister( pDevice, 0x5F, 0x00 );
	NVP6134_SetRegister( pDevice, 0x84, 0x01 );	
	NVP6134_SetRegister( pDevice, 0x86, 0x40 );	
	NVP6134_SetRegister( pDevice, 0x90, 0x05 );
	NVP6134_SetRegister( pDevice, 0x9B, 0x80 );
	NVP6134_SetRegister( pDevice, 0xB5, 0x00 );
	NVP6134_SetRegister( pDevice, 0xB7, 0xFF );
	NVP6134_SetRegister( pDevice, 0xBB, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0x04 );
	NVP6134_SetRegister( pDevice, 0xD1, 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x61 : 0x60 );
	NVP6134_SetRegister( pDevice, 0x51 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0xDE : 0xDE );
	NVP6134_SetRegister( pDevice, 0x52 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0xCE : 0xCE );
	NVP6134_SetRegister( pDevice, 0x53 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x90 : 0x90 );
}

VOID NVP6134_SETCHN_EXC_720PEX( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_EXC_720PEX( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_EXC_720P( pDevice, i, vfmt );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x80 : 0x80 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x0B : 0x0A );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x24 : 0x02 );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x8C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x40 : 0x40 );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x02 );
	NVP6134_SetRegister( pDevice, 0x29 + (i % 4) * 0x06, 0xA0 );
	NVP6134_SetRegister( pDevice, 0x2C + (i % 4) * 0x06, 0x9A );
}

VOID NVP6134_SETCHN_EXT_BSF( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_EXT_BSF( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SetRegister( pDevice, 0xFF, 0x0A + (i % 4) / 2 );
	NVP6134_SetRegister( pDevice, 0x60 + (i % 2) * 0x80, 0xA0 );	
	NVP6134_SetRegister( pDevice, 0x61 + (i % 2) * 0x80, 0x01 );
	NVP6134_SetRegister( pDevice, 0x62 + (i % 2) * 0x80, 0x01 );
	NVP6134_SetRegister( pDevice, 0x63 + (i % 2) * 0x80, 0x01 );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 2) * 0x80, 0x03 );			
	NVP6134_SetRegister( pDevice, 0x65 + (i % 2) * 0x80, 0x02 );
	NVP6134_SetRegister( pDevice, 0x66 + (i % 2) * 0x80, 0x03 );
	NVP6134_SetRegister( pDevice, 0x67 + (i % 2) * 0x80, 0x02 );
	NVP6134_SetRegister( pDevice, 0x68 + (i % 2) * 0x80, 0x09 );			
	NVP6134_SetRegister( pDevice, 0x69 + (i % 2) * 0x80, 0x09 );
	NVP6134_SetRegister( pDevice, 0x6A + (i % 2) * 0x80, 0x2A );
	NVP6134_SetRegister( pDevice, 0x6B + (i % 2) * 0x80, 0x04 );
	NVP6134_SetRegister( pDevice, 0x6C + (i % 2) * 0x80, 0x17 );			
	NVP6134_SetRegister( pDevice, 0x6D + (i % 2) * 0x80, 0x1B );
	NVP6134_SetRegister( pDevice, 0x6E + (i % 2) * 0x80, 0x05 );
	NVP6134_SetRegister( pDevice, 0x6F + (i % 2) * 0x80, 0x00 );
	NVP6134_SetRegister( pDevice, 0x70 + (i % 2) * 0x80, 0x46 );			
	NVP6134_SetRegister( pDevice, 0x71 + (i % 2) * 0x80, 0x89 );
	NVP6134_SetRegister( pDevice, 0x72 + (i % 2) * 0x80, 0xA6 );		                                                        
}

VOID NVP6134_SETCHN_EXTA_720P( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_EXTA_720P( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x55 : 0x55 );
	NVP6134_SetRegister( pDevice, 0x8c + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x04 : 0x04 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x08 + (i % 4), 0x60 );
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x02 : 0x02 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x07 : 0x06 );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x01 );

	NVP6134_SETCHN_COMMON_720P( pDevice, i, vfmt );	

	NVP6134_SETCHN_EXT_BSF( pDevice, i, vfmt );	

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x47, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0x04 );
	NVP6134_SetRegister( pDevice, 0x50, (vfmt == NVP6134_STD_PAL) ? 0x84 : 0x84 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x80 : 0x80 );
	NVP6134_SetRegister( pDevice, 0x5C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x1E : 0x1E );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0xAE : 0xAE );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), 0x08 );
	NVP6134_SetRegister( pDevice, 0xA4 + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x97 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x51 : 0x51 );
	NVP6134_SetRegister( pDevice, 0x98 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x80 : 0x0C );
	NVP6134_SetRegister( pDevice, 0x99 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x1B, (vfmt == NVP6134_STD_PAL) ? 0x08 : 0x08 );
	NVP6134_SetRegister( pDevice, 0x20, (vfmt == NVP6134_STD_PAL) ? 0x98 : 0x98 );
	NVP6134_SetRegister( pDevice, 0x24, (vfmt == NVP6134_STD_PAL) ? 0x12 : 0x12 );
	NVP6134_SetRegister( pDevice, 0x25, 0xDB );
	NVP6134_SetRegister( pDevice, 0x26, 0xF0 );
	NVP6134_SetRegister( pDevice, 0x29, 0x00 );
	NVP6134_SetRegister( pDevice, 0x2A, 0xD2 );
	NVP6134_SetRegister( pDevice, 0x5F, 0x00 );
	NVP6134_SetRegister( pDevice, 0x84, 0x01 );	
	NVP6134_SetRegister( pDevice, 0x86, (vfmt == NVP6134_STD_PAL) ? 0x20 : 0x40 );	
	NVP6134_SetRegister( pDevice, 0x90, (vfmt == NVP6134_STD_PAL) ? 0x05 : 0x05 );
	NVP6134_SetRegister( pDevice, 0x9B, 0x80 );
	NVP6134_SetRegister( pDevice, 0xB5, 0x00 );
	NVP6134_SetRegister( pDevice, 0xB7, 0xFF );
	NVP6134_SetRegister( pDevice, 0xB8, 0xB8 );
	NVP6134_SetRegister( pDevice, 0xBB, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0x04 );
	NVP6134_SetRegister( pDevice, 0xD1, 0x00 );
	NVP6134_SetRegister( pDevice, 0xD4, 0x1F );
        
	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4) * 0x04, 0x8B );
	NVP6134_SetRegister( pDevice, 0x51 + (i % 4) * 0x04, 0x2E );
	NVP6134_SetRegister( pDevice, 0x52 + (i % 4) * 0x04, 0xBB );
	NVP6134_SetRegister( pDevice, 0x53 + (i % 4) * 0x04, 0x48 );
}

VOID NVP6134_SETCHN_EXTA_720PEX( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_EXTA_720PEX( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_EXTA_720P( pDevice, i, vfmt );	

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x0B : 0x0A );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x60 : 0xA0 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x20 );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x8C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x44 : 0x44 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x84, 0x00 );
	NVP6134_SetRegister( pDevice, 0x86, 0x40 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x02 );
	NVP6134_SetRegister( pDevice, 0x29 + (i % 4) * 0x06, 0xA0 );
	NVP6134_SetRegister( pDevice, 0x2C + (i % 4) * 0x06, 0x9A );
}

VOID NVP6134_SETCHN_EXTB_720P( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_EXTB_720P( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x8c + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x20 : 0x20 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x08 + (i % 4), 0x60 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x07 : 0x06 );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x03 );

	NVP6134_SETCHN_COMMON_720P( pDevice, i, vfmt );	

	NVP6134_SETCHN_EXT_BSF( pDevice, i, vfmt );	

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x47, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0x04 );
	NVP6134_SetRegister( pDevice, 0x50, (vfmt == NVP6134_STD_PAL) ? 0x84 : 0x84 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x14 : 0x14 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x84 : 0x84 );
	NVP6134_SetRegister( pDevice, 0x5C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x1E : 0x1E );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x2E : 0x2E );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), 0x08 );
	NVP6134_SetRegister( pDevice, 0xA4 + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x97 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x98 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x99 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x0C + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x10 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x90 : 0x90 );
	NVP6134_SetRegister( pDevice, 0x3C + (i % 4), 0xB0 );
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), 0x02 );
	NVP6134_SetRegister( pDevice, 0x93 + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x98 + (i % 4), 0x00 );	
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x20, (vfmt == NVP6134_STD_PAL) ? 0x86 : 0x86 );
	NVP6134_SetRegister( pDevice, 0x27, (vfmt == NVP6134_STD_PAL) ? 0x57 : 0x57 );
	NVP6134_SetRegister( pDevice, 0x2B, (vfmt == NVP6134_STD_PAL) ? 0xA8 : 0xA8 );
	NVP6134_SetRegister( pDevice, 0x47, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0x04 );
	NVP6134_SetRegister( pDevice, 0x50, (vfmt == NVP6134_STD_PAL) ? 0x84 : 0x84 );
	NVP6134_SetRegister( pDevice, 0x57, 0x00 );
	NVP6134_SetRegister( pDevice, 0x76, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x1B, (vfmt == NVP6134_STD_PAL) ? 0x08 : 0x08 );
	NVP6134_SetRegister( pDevice, 0x24, (vfmt == NVP6134_STD_PAL) ? 0x12 : 0x12 );
	NVP6134_SetRegister( pDevice, 0x25, 0xDB );
	NVP6134_SetRegister( pDevice, 0x26, 0xF0 );
	NVP6134_SetRegister( pDevice, 0x29, 0x00 );
	NVP6134_SetRegister( pDevice, 0x2A, 0xD2 );
	NVP6134_SetRegister( pDevice, 0x5F, 0x00 );
	NVP6134_SetRegister( pDevice, 0x6E, 0x10 );
	NVP6134_SetRegister( pDevice, 0x6F, 0x19 );
	NVP6134_SetRegister( pDevice, 0x84, 0x00 );
	NVP6134_SetRegister( pDevice, 0x86, 0x00 );
	NVP6134_SetRegister( pDevice, 0x90, 0x05 );
	NVP6134_SetRegister( pDevice, 0x9B, 0x80 );
	NVP6134_SetRegister( pDevice, 0xB5, 0x00 );
	NVP6134_SetRegister( pDevice, 0xB7, 0xFF );
	NVP6134_SetRegister( pDevice, 0xB8, 0x38 );
	NVP6134_SetRegister( pDevice, 0xBB, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0x04 );
	NVP6134_SetRegister( pDevice, 0xD1, 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x16 : 0x16 );
	NVP6134_SetRegister( pDevice, 0x51 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x5D : 0x5D );
	NVP6134_SetRegister( pDevice, 0x52 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x76 : 0x76 );
	NVP6134_SetRegister( pDevice, 0x53 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x91 : 0x91 );
}

VOID NVP6134_SETCHN_EXTB_720PEX( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_EXTB_720PEX( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_EXTB_720P( pDevice, i, vfmt );	
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x07 : 0x06 );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x8c + (i % 4), 0x40 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x02 );
	NVP6134_SetRegister( pDevice, 0x29 + (i % 4) * 0x06, 0xA0 );
	NVP6134_SetRegister( pDevice, 0x2C + (i % 4) * 0x06, 0x9A );

	NVP6134_SetRegister( pDevice, 0xFF, 0x11 );
	NVP6134_SetRegister( pDevice, 0x00 + (i % 4) * 0x20, 0x10 );
}

VOID NVP6134_SETCHN_AHD_720P5060( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_AHD_720P5060( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_COMMON_720P( pDevice, i, vfmt );	

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x8c + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x40 : 0x40 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x08 + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x0C + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x10 + (i % 4), 0x90 );
	NVP6134_SetRegister( pDevice, 0x3C + (i % 4), 0x7C );

	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x03 : 0x03 );
	NVP6134_SetRegister( pDevice, 0x44 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x48 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0xF8 : 0xF8 );
	NVP6134_SetRegister( pDevice, 0x4C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0xF2 : 0xF2 );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0xF6 : 0xF6 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x05 : 0x04 );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x47, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0xEE );
	NVP6134_SetRegister( pDevice, 0x50, (vfmt == NVP6134_STD_PAL) ? 0x86 : 0xC6 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x80 : 0x82 );
	NVP6134_SetRegister( pDevice, 0x5C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x1E : 0x1E );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x30 : 0x31 );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0xA4 + (i % 4), 0x09 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x97 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x98 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x99 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x1B, (vfmt == NVP6134_STD_PAL) ? 0x08 : 0x08 );
	NVP6134_SetRegister( pDevice, 0x20, (vfmt == NVP6134_STD_PAL) ? 0x82 : 0x82 ); 
	NVP6134_SetRegister( pDevice, 0x24, (vfmt == NVP6134_STD_PAL) ? 0x2A : 0x20 );
	NVP6134_SetRegister( pDevice, 0x25, 0xDC );
	NVP6134_SetRegister( pDevice, 0x26, 0x30 );
	NVP6134_SetRegister( pDevice, 0x29, 0x1F );
	NVP6134_SetRegister( pDevice, 0x2A, 0x52 );
	NVP6134_SetRegister( pDevice, 0x5F, 0x00 );
	NVP6134_SetRegister( pDevice, 0x84, 0x01 );
	NVP6134_SetRegister( pDevice, 0x86, 0x30 );
	NVP6134_SetRegister( pDevice, 0x90, 0x01 );
	NVP6134_SetRegister( pDevice, 0x9B, 0x80 );
	NVP6134_SetRegister( pDevice, 0xB5, 0x00 );
	NVP6134_SetRegister( pDevice, 0xB7, (vfmt == NVP6134_STD_PAL) ? 0xFF : 0xFC );
	NVP6134_SetRegister( pDevice, 0xB8, 0x38 );
	NVP6134_SetRegister( pDevice, 0xBB, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0xFE );
	NVP6134_SetRegister( pDevice, 0xD1, 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4) * 0x04, 0x2C );
	NVP6134_SetRegister( pDevice, 0x51 + (i % 4) * 0x04, 0xE7 );
	NVP6134_SetRegister( pDevice, 0x52 + (i % 4) * 0x04, 0xCF );
	NVP6134_SetRegister( pDevice, 0x53 + (i % 4) * 0x04, 0x52 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x11 );
	NVP6134_SetRegister( pDevice, 0x00 + (i % 4) * 0x20, 0x00 );
}

VOID NVP6134_SETCHN_AHD_M_720P5060( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_AHD_M_720P5060( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_COMMON_720P( pDevice, i, vfmt );	

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), 0xE4 );
	NVP6134_SetRegister( pDevice, 0x8c + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x44 : 0x44 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	BYTE ycmerge = NVP6134_GetRegister( pDevice, 0xED ); CLE_BIT( ycmerge, (i % 4) );
	NVP6134_SetRegister( pDevice, 0xED, ycmerge );

	NVP6134_SetRegister( pDevice, 0xFF, 0x0A );
	NVP6134_SetRegister( pDevice, 0x60, 0x80 );
	NVP6134_SetRegister( pDevice, 0x61, 0x01 );
	NVP6134_SetRegister( pDevice, 0x62, 0x02 );
	NVP6134_SetRegister( pDevice, 0x63, 0x00 );
	NVP6134_SetRegister( pDevice, 0x64, 0x03 );
	NVP6134_SetRegister( pDevice, 0x65, 0x0A );
	NVP6134_SetRegister( pDevice, 0x66, 0x05 );
	NVP6134_SetRegister( pDevice, 0x67, 0x01 );
	NVP6134_SetRegister( pDevice, 0x68, 0x09 );
	NVP6134_SetRegister( pDevice, 0x69, 0x0D );
	NVP6134_SetRegister( pDevice, 0x6A, 0xA8 );
	NVP6134_SetRegister( pDevice, 0x6B, 0x01 );
	NVP6134_SetRegister( pDevice, 0x6C, 0x16 );
	NVP6134_SetRegister( pDevice, 0x6D, 0x1F );
	NVP6134_SetRegister( pDevice, 0x6E, 0x02 );
	NVP6134_SetRegister( pDevice, 0x6F, 0x00 );
	NVP6134_SetRegister( pDevice, 0x70, 0x43 );
	NVP6134_SetRegister( pDevice, 0x71, 0x8D );
	NVP6134_SetRegister( pDevice, 0x72, 0xAC );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x08 + (i % 4), 0x60 );
	NVP6134_SetRegister( pDevice, 0x18 + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x23 + (i * 4), 0x43 );
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x05 : 0x04 );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x01 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x47, (vfmt == NVP6134_STD_PAL) ? 0xEE : 0xEE );
	NVP6134_SetRegister( pDevice, 0x50, (vfmt == NVP6134_STD_PAL) ? 0xC6 : 0xC6 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), 0x2D );
	NVP6134_SetRegister( pDevice, 0x5C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x1E : 0x1E );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0xAF : 0xAF );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x04 : 0x10 );
	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), 0x08 );
	NVP6134_SetRegister( pDevice, 0xA4 + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x97 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x98 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x99 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x08, 0x50 );
	NVP6134_SetRegister( pDevice, 0x1B, (vfmt == NVP6134_STD_PAL) ? 0x08 : 0x08 );
	NVP6134_SetRegister( pDevice, 0x24, (vfmt == NVP6134_STD_PAL) ? 0x20 : 0x20 );
	NVP6134_SetRegister( pDevice, 0x25, 0xCC );
	NVP6134_SetRegister( pDevice, 0x26, 0x30 );
	NVP6134_SetRegister( pDevice, 0x29, 0x00 );
	NVP6134_SetRegister( pDevice, 0x2A, 0xD2 );
	NVP6134_SetRegister( pDevice, 0x5F, 0x00 );
	NVP6134_SetRegister( pDevice, 0x84, 0x01 );	
	NVP6134_SetRegister( pDevice, 0x86, 0x20 );	
	NVP6134_SetRegister( pDevice, 0x84, 0x01 );	
	NVP6134_SetRegister( pDevice, 0x86, 0x50 );	
	NVP6134_SetRegister( pDevice, 0x90, 0x05 );
	NVP6134_SetRegister( pDevice, 0x9B, 0x80 );
	NVP6134_SetRegister( pDevice, 0xB5, 0x00 );
	NVP6134_SetRegister( pDevice, 0xB7, 0xFF );
	NVP6134_SetRegister( pDevice, 0xB8, 0x38 );
	NVP6134_SetRegister( pDevice, 0xBB, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0x04 );
	NVP6134_SetRegister( pDevice, 0xD1, 0x00 );
	NVP6134_SetRegister( pDevice, 0xD4, 0x1F );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x44, ycmerge );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4) * 0x04, 0x72 );
	NVP6134_SetRegister( pDevice, 0x51 + (i % 4) * 0x04, 0xF5 );
	NVP6134_SetRegister( pDevice, 0x52 + (i % 4) * 0x04, 0x31 );
	NVP6134_SetRegister( pDevice, 0x53 + (i % 4) * 0x04, 0x37 );
}

VOID NVP6134_SETCHN_EXC_720P5060( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_EXC_720P5060( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x55 : 0x55 );
	NVP6134_SetRegister( pDevice, 0x8c + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x44 : 0x44 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x05 : 0x04 );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x02 );

	NVP6134_SETCHN_COMMON_720P( pDevice, i, vfmt );

	NVP6134_SETCHN_EXT_BSF( pDevice, i, vfmt );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x08 + (i % 4), 0x60 );
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x20 : 0x20 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x47, (vfmt == NVP6134_STD_PAL) ? 0xEE : 0xEE );
	NVP6134_SetRegister( pDevice, 0x50, (vfmt == NVP6134_STD_PAL) ? 0xC6 : 0xC6 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x80 : 0x80 );
	NVP6134_SetRegister( pDevice, 0x5C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x1E : 0x1E );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x2E : 0x2F );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x10 );
	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), 0x08 );
	NVP6134_SetRegister( pDevice, 0xA4 + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x97 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x29 : 0x19 );
	NVP6134_SetRegister( pDevice, 0x98 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0xC4 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x99 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x01 : 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x1B, (vfmt == NVP6134_STD_PAL) ? 0x08 : 0x08 );
	NVP6134_SetRegister( pDevice, 0x24, (vfmt == NVP6134_STD_PAL) ? 0x20 : 0x20 );
	NVP6134_SetRegister( pDevice, 0x25, 0xDC );
	NVP6134_SetRegister( pDevice, 0x26, 0x30 );
	NVP6134_SetRegister( pDevice, 0x29, 0x00 );
	NVP6134_SetRegister( pDevice, 0x2A, 0xD2 );
	NVP6134_SetRegister( pDevice, 0x5F, 0x00 );
	NVP6134_SetRegister( pDevice, 0x75, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x84, 0x01 );
	NVP6134_SetRegister( pDevice, 0x86, 0x40 );
	NVP6134_SetRegister( pDevice, 0x90, 0x05 );
	NVP6134_SetRegister( pDevice, 0x9B, 0x80 );
	NVP6134_SetRegister( pDevice, 0xB5, 0x00 );
	NVP6134_SetRegister( pDevice, 0xB7, 0xFF );
	NVP6134_SetRegister( pDevice, 0xB8, 0x38 );
	NVP6134_SetRegister( pDevice, 0xBB, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0x04 );
	NVP6134_SetRegister( pDevice, 0xD1, 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4) * 0x04, 0x4B );
	NVP6134_SetRegister( pDevice, 0x51 + (i % 4) * 0x04, 0x4F );
	NVP6134_SetRegister( pDevice, 0x52 + (i % 4) * 0x04, 0x04 );
	NVP6134_SetRegister( pDevice, 0x53 + (i % 4) * 0x04, 0x83 );

	NVP6134_SetRegister( pDevice, 0x8C + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x8D + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0xA0 : 0xA0 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x9C : 0x9C );
	NVP6134_SetRegister( pDevice, 0x8F + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x3D : 0x3D );
	NVP6134_SetRegister( pDevice, 0x90 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0xFF : 0xFF );
	NVP6134_SetRegister( pDevice, 0x91 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0xF7 : 0xF7 );
	NVP6134_SetRegister( pDevice, 0x92 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0x04 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x02 );
	NVP6134_SetRegister( pDevice, 0x29 + (i % 4) * 0x06, 0x78 );
	NVP6134_SetRegister( pDevice, 0x2C + (i % 4) * 0x06, 0x72 );
}

VOID NVP6134_SETCHN_EXT_720P5060( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_EXT_720P5060( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x55 : 0x55 );
	NVP6134_SetRegister( pDevice, 0x8C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x44 : 0x44 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x08 + (i % 4), 0x60 );
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x20 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x05 : 0x04 );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x01 );

	NVP6134_SETCHN_COMMON_720P( pDevice, i, vfmt );	

	NVP6134_SETCHN_EXT_BSF( pDevice, i, vfmt );	

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x47, (vfmt == NVP6134_STD_PAL) ? 0xEE : 0xEE );
	NVP6134_SetRegister( pDevice, 0x50, (vfmt == NVP6134_STD_PAL) ? 0xC6 : 0xC6 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x80 : 0x80 );
	NVP6134_SetRegister( pDevice, 0x5C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x1E : 0x1E );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0xAF : 0xAF );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x0D : 0x19 );
	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), 0x08 );
	NVP6134_SetRegister( pDevice, 0xA4 + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x97 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x98 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x99 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
												 	    
	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );					 	    
	NVP6134_SetRegister( pDevice, 0x1B, (vfmt == NVP6134_STD_PAL) ? 0x08 : 0x08 );
	NVP6134_SetRegister( pDevice, 0x24, (vfmt == NVP6134_STD_PAL) ? 0x20 : 0x20 );
	NVP6134_SetRegister( pDevice, 0x25, 0xCC );
	NVP6134_SetRegister( pDevice, 0x26, 0x30 );
	NVP6134_SetRegister( pDevice, 0x29, 0x00 );
	NVP6134_SetRegister( pDevice, 0x2A, 0xD2 );
	NVP6134_SetRegister( pDevice, 0x5F, 0x00 );
	NVP6134_SetRegister( pDevice, 0x84, 0x01 );
	NVP6134_SetRegister( pDevice, 0x86, 0x20 );
	NVP6134_SetRegister( pDevice, 0x90, 0x05 );
	NVP6134_SetRegister( pDevice, 0x9B, 0x80 );
	NVP6134_SetRegister( pDevice, 0xB5, 0x00 );
	NVP6134_SetRegister( pDevice, 0xB7, 0xFF );
	NVP6134_SetRegister( pDevice, 0xB8, 0x38 );
	NVP6134_SetRegister( pDevice, 0xBB, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0x04 );
	NVP6134_SetRegister( pDevice, 0xD1, 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4) * 0x04, 0x4B );
	NVP6134_SetRegister( pDevice, 0x51 + (i % 4) * 0x04, 0x4F );
	NVP6134_SetRegister( pDevice, 0x52 + (i % 4) * 0x04, 0x04 );
	NVP6134_SetRegister( pDevice, 0x53 + (i % 4) * 0x04, 0x83 );
}

VOID NVP6134_SETCHN_COMMON_FHD( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_COMMON_FHD( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x00 + (i % 4), 0x10 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x00, 0xC0 );
	NVP6134_SetRegister( pDevice, 0x01, 0x03 );
	NVP6134_SetRegister( pDevice, 0x58, 0x03 );
	NVP6134_SetRegister( pDevice, 0x59, 0x00 );
	NVP6134_SetRegister( pDevice, 0x5B, 0x03 );
	NVP6134_SetRegister( pDevice, 0x69, 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x0c + (i % 4), 0x08 );
	NVP6134_SetRegister( pDevice, 0x10 + (i % 4), 0x88 );
	NVP6134_SetRegister( pDevice, 0x14 + (i % 4), 0x90 );
	NVP6134_SetRegister( pDevice, 0x18 + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x21 + (i % 4) * 0x04, 0x92 );
	NVP6134_SetRegister( pDevice, 0x22 + (i % 4) * 0x04, 0x0B );
	NVP6134_SetRegister( pDevice, 0x3C + (i % 4), 0x84 );
	NVP6134_SetRegister( pDevice, 0x44 + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x48 + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x4c + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );    
	NVP6134_SetRegister( pDevice, 0x1B, 0x08 );
	NVP6134_SetRegister( pDevice, 0x20, (vfmt == NVP6134_STD_PAL) ? 0x84 : 0x84 );
	NVP6134_SetRegister( pDevice, 0x26, 0xF0 );
	NVP6134_SetRegister( pDevice, 0x27, (vfmt == NVP6134_STD_PAL) ? 0x57 : 0x57 );
	NVP6134_SetRegister( pDevice, 0x29, 0x00 );
	NVP6134_SetRegister( pDevice, 0x76, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x57, 0x00 );
	NVP6134_SetRegister( pDevice, 0x5F, 0x00 );
	NVP6134_SetRegister( pDevice, 0x90, 0x01 );
	NVP6134_SetRegister( pDevice, 0x2B, 0xA8 );
	NVP6134_SetRegister( pDevice, 0xD1, 0x00 );
	NVP6134_SetRegister( pDevice, 0xD4, 0x00 );                 
	NVP6134_SetRegister( pDevice, 0xB8, 0xB9 );	

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x80 : 0x80 );
	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x6E, (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x6F, (vfmt == NVP6134_STD_PAL) ? 0x2A : 0x2B );

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );					
	BYTE ycmerge = NVP6134_GetRegister( pDevice, 0xED ); CLE_BIT( ycmerge, (i % 4) );
	NVP6134_SetRegister( pDevice, 0xED, ycmerge );

	NVP6134_SetRegister( pDevice, 0xFF, 0x02 );
	NVP6134_SetRegister( pDevice, 0x02 + (i % 4) * 0x07, 0x23 );
	NVP6134_SetRegister( pDevice, 0x28 + (i % 4) * 0x06, 0x10 );
	NVP6134_SetRegister( pDevice, 0x29 + (i % 4) * 0x06, 0x78 );
	NVP6134_SetRegister( pDevice, 0x2A + (i % 4) * 0x06, 0x2D );
	NVP6134_SetRegister( pDevice, 0x2B + (i % 4) * 0x06, 0x06 );
	NVP6134_SetRegister( pDevice, 0x2C + (i % 4) * 0x06, 0x72 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), 0x00 );
	BYTE pn_set = NVP6134_GetRegister( pDevice, 0x44 ); CLE_BIT( pn_set, (i % 4) );
	NVP6134_SetRegister( pDevice, 0x44, pn_set );
	NVP6134_SetRegister( pDevice, 0x97 + (i % 4) * 0x20, 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x11 );
	NVP6134_SetRegister( pDevice, 0x00 + (i % 4) * 0x20, 0x00 );
}

VOID NVP6134_SETCHN_AHD_1080P2530( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_AHD_1080P2530( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_COMMON_FHD( pDevice, i, vfmt );	

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x8C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x40 : 0x40 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x18 + (i % 4), 0x30 );
	NVP6134_SetRegister( pDevice, 0x08 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x03 : 0x02 );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x47, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0xEE );
	NVP6134_SetRegister( pDevice, 0x50, (vfmt == NVP6134_STD_PAL) ? 0x84 : 0xC6 );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x7D : 0x89 );
	NVP6134_SetRegister( pDevice, 0x5C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x9E : 0x9E );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x80 : 0xC0 );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x09 : 0x09 );
	NVP6134_SetRegister( pDevice, 0xA4 + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x97 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x98 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x99 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x1B, (vfmt == NVP6134_STD_PAL) ? 0x08 : 0x08 );
	NVP6134_SetRegister( pDevice, 0x20, (vfmt == NVP6134_STD_PAL) ? 0x90 : 0x90 );
	NVP6134_SetRegister( pDevice, 0x24, (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x20 );
	NVP6134_SetRegister( pDevice, 0x25, (vfmt == NVP6134_STD_PAL) ? 0xDC : 0xDC );
	NVP6134_SetRegister( pDevice, 0x26, 0xF0 );
	NVP6134_SetRegister( pDevice, 0x29, 0x00 );
	NVP6134_SetRegister( pDevice, 0x2A, 0x52 );
	NVP6134_SetRegister( pDevice, 0x58, 0x03 );

	NVP6134_SetRegister( pDevice, 0x5F, 0x00 );
	NVP6134_SetRegister( pDevice, 0x75, 0x00 );
	NVP6134_SetRegister( pDevice, 0x84, 0x01 );
	NVP6134_SetRegister( pDevice, 0x86, 0x20 );
	NVP6134_SetRegister( pDevice, 0x90, (vfmt == NVP6134_STD_PAL) ? 0x01 : 0x01 );
	NVP6134_SetRegister( pDevice, 0x9B, 0x80 );		
	NVP6134_SetRegister( pDevice, 0xB5, 0x00 );
	NVP6134_SetRegister( pDevice, 0xB7, (vfmt == NVP6134_STD_PAL) ? 0xFF : 0xFF );
	NVP6134_SetRegister( pDevice, 0xB8, 0x38 );
	NVP6134_SetRegister( pDevice, 0xBB, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0x04 );
	NVP6134_SetRegister( pDevice, 0xD1, 0x20 );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0xAB : 0x2C );
	NVP6134_SetRegister( pDevice, 0x51 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x7D : 0xAF );
	NVP6134_SetRegister( pDevice, 0x52 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0xC3 : 0xCA );
	NVP6134_SetRegister( pDevice, 0x53 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x52 : 0x52 );
}

VOID NVP6134_SETCHN_AHD_1080P_NOVIDEO( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_AHD_1080P_NOVIDEO( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_COMMON_FHD( pDevice, i, vfmt );

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x8C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x40 : 0x40 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x08 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x23 + (i % 4) * 0x04, 0x41 );
	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), 0x10 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x03 : 0x02 );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x47, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0x04 );
	NVP6134_SetRegister( pDevice, 0x50, (vfmt == NVP6134_STD_PAL) ? 0x86 : 0x86 );	

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x97 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x98 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x99 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x58, 0x01 );
	NVP6134_SetRegister( pDevice, 0xB5, 0x00 );
	NVP6134_SetRegister( pDevice, 0xB7, (vfmt == NVP6134_STD_PAL) ? 0xF0 : 0xFF );
	NVP6134_SetRegister( pDevice, 0xB8, 0xB9 );
	NVP6134_SetRegister( pDevice, 0xBB, (vfmt == NVP6134_STD_PAL) ? 0xBB : 0x04 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x84, 0x01 );
	NVP6134_SetRegister( pDevice, 0x86, 0x30 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x24, 0x20 );
	NVP6134_SetRegister( pDevice, 0x25, 0xDC );
	NVP6134_SetRegister( pDevice, 0x27, 0x57 );
	NVP6134_SetRegister( pDevice, 0x5C, 0x00 );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x00 + (i % 4), 0x00 );
}

VOID NVP6134_SETCHN_AHD_1080P_NRT( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{	
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_AHD_1080P_NRT( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_AHD_1080P2530( pDevice, i, vfmt );

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x0A : 0x0A );
	NVP6134_SetRegister( pDevice, 0x8c + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x0A : 0x0A );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x89 : 0x80 );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x02 );
	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x09 : 0x09 );
	NVP6134_SetRegister( pDevice, 0xA4 + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x02 );
	NVP6134_SetRegister( pDevice, 0x29 + (i % 4) * 0x06, 0x3C );
	NVP6134_SetRegister( pDevice, 0x2C + (i % 4) * 0x06, 0x39 );
}

VOID NVP6134_SETCHN_EXC_1080P2530( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_EXC_1080P2530( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );					
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x55 : 0x55 );		
	NVP6134_SetRegister( pDevice, 0x8C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x44 : 0x44 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x03 : 0x02 );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x02 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x08 + (i % 4), 0x60 );                 
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x20 : 0x20 );

	NVP6134_SETCHN_COMMON_FHD( pDevice, i, vfmt );

	NVP6134_SETCHN_EXT_BSF( pDevice, i, vfmt );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x3C + (i % 4), 0x90 ); 
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x70 : 0x80 );
	NVP6134_SetRegister( pDevice, 0x5C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x9E : 0x9E );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0xBF : 0xBF );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x08 : 0x08 );
	NVP6134_SetRegister( pDevice, 0xA4 + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x97 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x49 : 0x39 );
	NVP6134_SetRegister( pDevice, 0x98 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x50 : 0x70 );
	NVP6134_SetRegister( pDevice, 0x99 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x02 : 0x01 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x47, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0xEE );
	NVP6134_SetRegister( pDevice, 0x50, (vfmt == NVP6134_STD_PAL) ? 0x84 : 0xC6 );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x20, (vfmt == NVP6134_STD_PAL) ? 0x90 : 0x90 );
	NVP6134_SetRegister( pDevice, 0x1B, (vfmt == NVP6134_STD_PAL) ? 0x08 : 0x08 );
	NVP6134_SetRegister( pDevice, 0x24, (vfmt == NVP6134_STD_PAL) ? 0x18 : 0x18 );
	NVP6134_SetRegister( pDevice, 0x25, (vfmt == NVP6134_STD_PAL) ? 0xDC : 0xDC );
	NVP6134_SetRegister( pDevice, 0x26, 0xD0 );
	NVP6134_SetRegister( pDevice, 0x29, 0x1F );
	NVP6134_SetRegister( pDevice, 0x2A, 0xD2 );
	NVP6134_SetRegister( pDevice, 0x5F, (vfmt == NVP6134_STD_PAL) ? 0x30 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x84, 0x01 );
	NVP6134_SetRegister( pDevice, 0x86, 0x40 );
	NVP6134_SetRegister( pDevice, 0x90, (vfmt == NVP6134_STD_PAL) ? 0x05 : 0x05 );
	NVP6134_SetRegister( pDevice, 0x9B, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x80 );
	NVP6134_SetRegister( pDevice, 0xB5, 0x00 );
	NVP6134_SetRegister( pDevice, 0xB7, 0xFF );
	NVP6134_SetRegister( pDevice, 0xBB, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0x04 );
	NVP6134_SetRegister( pDevice, 0xD1, (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x4C : 0x4B );
	NVP6134_SetRegister( pDevice, 0x51 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x4F : 0x4F );
	NVP6134_SetRegister( pDevice, 0x52 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0x04 );
	NVP6134_SetRegister( pDevice, 0x53 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x83 : 0x83 );
	
    NVP6134_SetRegister( pDevice, 0x8C + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
    NVP6134_SetRegister( pDevice, 0x8D + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x90 : 0x90 );
    NVP6134_SetRegister( pDevice, 0x8E + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x9C : 0x9C );
    NVP6134_SetRegister( pDevice, 0x8F + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x3D : 0x3D );
    NVP6134_SetRegister( pDevice, 0x90 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0xFF : 0xFF );
    NVP6134_SetRegister( pDevice, 0x91 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0xF7 : 0xF7 );
    NVP6134_SetRegister( pDevice, 0x92 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0x10 );
}

VOID NVP6134_SETCHN_EXT_1080P2530( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_EXT_1080P2530( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_COMMON_FHD( pDevice, i, vfmt );

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), ((i % 2) == 0) ? 0xF5 : 0x05 );
	NVP6134_SetRegister( pDevice, 0x8c + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x44 : 0x44);

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x08 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x03 : 0x02 );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x01 );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x47, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0x04 );
	NVP6134_SetRegister( pDevice, 0x50, (vfmt == NVP6134_STD_PAL) ? 0x84 : 0x84 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x10 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x60 : 0x60 );
	NVP6134_SetRegister( pDevice, 0x5C + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x9E : 0x9E );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0xBF : 0xBF );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x10 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x08 : 0x08 );
	NVP6134_SetRegister( pDevice, 0xA4 + (i % 4), 0x00 );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x0C + (i % 4), 0x00 );	
	NVP6134_SetRegister( pDevice, 0x10 + (i % 4), 0xA0 );	
	NVP6134_SetRegister( pDevice, 0x14 + (i % 4), 0x90 );
	NVP6134_SetRegister( pDevice, 0x18 + (i % 4), 0x20 );
	NVP6134_SetRegister( pDevice, 0x21 + (i % 4) * 0x04, 0x82 );
	NVP6134_SetRegister( pDevice, 0x3C + (i % 4), 0xB0 ); 
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), 0x00 ); 
	NVP6134_SetRegister( pDevice, 0x44 + (i % 4), 0x00 ); 
	NVP6134_SetRegister( pDevice, 0x48 + (i % 4), 0x00 ); 
	NVP6134_SetRegister( pDevice, 0x4C + (i % 4), 0x00 ); 
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4), 0x00 ); 	
												  	   
	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x8B : 0x8B );
	NVP6134_SetRegister( pDevice, 0x51 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x2E : 0x2E );
	NVP6134_SetRegister( pDevice, 0x52 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0xBA : 0xBA );
	NVP6134_SetRegister( pDevice, 0x53 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x48 : 0x48 );
	BYTE pn_set = NVP6134_GetRegister( pDevice, 0x44 ); SET_BIT( pn_set, (i % 4) );
	NVP6134_SetRegister( pDevice, 0x44, pn_set );
	NVP6134_SetRegister( pDevice, 0x97 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x98 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );
	NVP6134_SetRegister( pDevice, 0x99 + (i % 4) * 0x20, (vfmt == NVP6134_STD_PAL) ? 0x00 : 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x1B, (vfmt == NVP6134_STD_PAL) ? 0x08 : 0x08 );
	NVP6134_SetRegister( pDevice, 0x20, (vfmt == NVP6134_STD_PAL) ? 0x86 : 0x86 );
	NVP6134_SetRegister( pDevice, 0x24, (vfmt == NVP6134_STD_PAL) ? 0x18 : 0x18 );
	NVP6134_SetRegister( pDevice, 0x25, 0xCC );
	NVP6134_SetRegister( pDevice, 0x26, 0x90 );
	NVP6134_SetRegister( pDevice, 0x29, 0x00 );
	NVP6134_SetRegister( pDevice, 0x2A, 0xD2 );
	NVP6134_SetRegister( pDevice, 0x2B, 0xA8 );
	NVP6134_SetRegister( pDevice, 0x5F, 0x00 );
    NVP6134_SetRegister( pDevice, 0x6E, 0x10 );
	NVP6134_SetRegister( pDevice, 0x6F, 0x29 );  
	NVP6134_SetRegister( pDevice, 0x84, 0x01 );
	NVP6134_SetRegister( pDevice, 0x86, (vfmt == NVP6134_STD_PAL) ? 0x20 : 0x40 );
	NVP6134_SetRegister( pDevice, 0x90, (vfmt == NVP6134_STD_PAL) ? 0x05 : 0x05 );
	NVP6134_SetRegister( pDevice, 0x9B, 0x80 );
	NVP6134_SetRegister( pDevice, 0xB5, 0x00 );
	NVP6134_SetRegister( pDevice, 0xB7, 0xFF );
	NVP6134_SetRegister( pDevice, 0xBB, (vfmt == NVP6134_STD_PAL) ? 0x04 : 0x04 );
	NVP6134_SetRegister( pDevice, 0xD1, 0x00 );
	NVP6134_SetRegister( pDevice, 0xD4, 0x00 );
}

VOID NVP6134_SETCHN_COMMON_3M( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_COMMON_3M( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_COMMON_FHD( pDevice, i, vfmt );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x00, 0xC0 );
	NVP6134_SetRegister( pDevice, 0x01, 0x03 );
	NVP6134_SetRegister( pDevice, 0x58, 0x03 );
	NVP6134_SetRegister( pDevice, 0x59, 0x00 );
	NVP6134_SetRegister( pDevice, 0x5B, 0x03 );
	NVP6134_SetRegister( pDevice, 0x69, 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x11 );
	NVP6134_SetRegister( pDevice, 0x00 + (i % 4) * 0x20, 0x00 );	

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x0C + (i % 4), 0x00 );		
	NVP6134_SetRegister( pDevice, 0x10 + (i % 4), 0x8B );
	NVP6134_SetRegister( pDevice, 0x14 + (i % 4), 0x90 );
	NVP6134_SetRegister( pDevice, 0x18 + (i % 4), 0x20 );
	NVP6134_SetRegister( pDevice, 0x21 + (i % 4) * 0x04, 0x82 );
	NVP6134_SetRegister( pDevice, 0x3C + (i % 4), 0x85 );		
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), 0xFE );		
	NVP6134_SetRegister( pDevice, 0x44 + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x48 + (i % 4), 0x07 );
	NVP6134_SetRegister( pDevice, 0x4C + (i % 4), 0xFB );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4), 0xFB );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x20, 0x83 );
	NVP6134_SetRegister( pDevice, 0x27, 0x57 );
	NVP6134_SetRegister( pDevice, 0x24, 0x20 );
	NVP6134_SetRegister( pDevice, 0x2A, 0xD2 );     	
	NVP6134_SetRegister( pDevice, 0x2B, 0xA8 );
	NVP6134_SetRegister( pDevice, 0x29, 0x30 );
	NVP6134_SetRegister( pDevice, 0x47, 0xEE );
	NVP6134_SetRegister( pDevice, 0x50, 0x84 );
	NVP6134_SetRegister( pDevice, 0xB8, 0x38 );
	NVP6134_SetRegister( pDevice, 0xBB, 0x04 );
	NVP6134_SetRegister( pDevice, 0xD1, 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x02 );
	NVP6134_SetRegister( pDevice, 0x02 + (i % 4) * 0x07, 0x23 );
	NVP6134_SetRegister( pDevice, 0x28 + (i % 4) * 0x06, 0x11 );
	NVP6134_SetRegister( pDevice, 0x29 + (i % 4) * 0x06, 0x80 );
	NVP6134_SetRegister( pDevice, 0x2A + (i % 4) * 0x06, 0x40 );
	NVP6134_SetRegister( pDevice, 0x2B + (i % 4) * 0x06, 0x06 );
	NVP6134_SetRegister( pDevice, 0x2C + (i % 4) * 0x06, 0x3A );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x11 );
	NVP6134_SetRegister( pDevice, 0x00 + (i % 4) * 0x20, 0x00 );
}

VOID NVP6134_SETCHN_AHD_3M( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_AHD_3M( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);
	
	NVP6134_SETCHN_COMMON_3M( pDevice, i, vfmt );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x18 + (i % 4), 0x20 );  
	NVP6134_SetRegister( pDevice, 0x23 + (i % 4) * 0x04, 0x41 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), 0x5E );  
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), 0x80 ); 
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x03 : 0x02 );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x04 );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), 0x07 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), ((i % 2) == 0) ? 0xF5 : 0x05 );
	NVP6134_SetRegister( pDevice, 0x8C + (i % 4), 0x44 );
	BYTE ycmerge = NVP6134_GetRegister( pDevice, 0xED ); SET_BIT( ycmerge, (i % 4) );
	NVP6134_SetRegister( pDevice, 0xED, ycmerge );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x57, 0x00 );
	NVP6134_SetRegister( pDevice, 0x69, 0x10 );	
	NVP6134_SetRegister( pDevice, 0x6E, 0x10 );
	NVP6134_SetRegister( pDevice, 0x6F, 0x68 );
	NVP6134_SetRegister( pDevice, 0x90, 0x01 );
	NVP6134_SetRegister( pDevice, 0x24, (vfmt == NVP6134_STD_PAL) ? 0x20 : 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x06 : 0xEC );  
	NVP6134_SetRegister( pDevice, 0x51 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x3A : 0xC3 );
	NVP6134_SetRegister( pDevice, 0x52 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x6D : 0x67 );
	NVP6134_SetRegister( pDevice, 0x53 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x48 : 0x48 );
	BYTE pn_set = NVP6134_GetRegister( pDevice, 0x44 ); SET_BIT( pn_set, (i % 4) );
	NVP6134_SetRegister( pDevice, 0x44, pn_set );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x84, 0x01 );
	NVP6134_SetRegister( pDevice, 0x86, 0x30 );
	NVP6134_SetRegister( pDevice, 0x23, 0x80 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x02 );
	NVP6134_SetRegister( pDevice, 0x29 + (i % 4) * 0x06, 0x40 );
}

VOID NVP6134_SETCHN_AHD_3MNRT( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_AHD_3MNRT( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_COMMON_3M( pDevice, i, vfmt );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x23 + (i % 4) * 0x04, 0x41 );
	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), 0x10 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), 0x90 );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), 0x80 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), 0x04 );  	
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x04 );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), 0x10 );
	NVP6134_SetRegister( pDevice, 0x8e + (i % 4), 0x03 );
	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), 0x0A );
	NVP6134_SetRegister( pDevice, 0xA4 + (i % 4), 0x00 );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), 0x43 );
	NVP6134_SetRegister( pDevice, 0x8C + (i % 4), 0x40 );
	BYTE ycmerge = NVP6134_GetRegister( pDevice, 0xED ); CLE_BIT( ycmerge, (i % 4) );
	NVP6134_SetRegister( pDevice, 0xED, ycmerge );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x20, 0x82 );
	NVP6134_SetRegister( pDevice, 0x24, 0x20 );		
	NVP6134_SetRegister( pDevice, 0x6E, 0x10 );
	NVP6134_SetRegister( pDevice, 0x6F, 0x68 );
	NVP6134_SetRegister( pDevice, 0x84, 0x01 );		
	NVP6134_SetRegister( pDevice, 0x86, 0x20 );	
											 
	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x0C + (i % 4), 0x00 );	
	NVP6134_SetRegister( pDevice, 0x10 + (i % 4), 0x8B );	
	NVP6134_SetRegister( pDevice, 0x3C + (i % 4), 0x83 ); 
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), 0x00 ); 
	NVP6134_SetRegister( pDevice, 0x44 + (i % 4), 0x00 ); 
	NVP6134_SetRegister( pDevice, 0x48 + (i % 4), 0x05 ); 
	NVP6134_SetRegister( pDevice, 0x4C + (i % 4), 0xFA ); 
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4), 0xF9 ); 

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4) * 0x04, 0xA7 );  
	NVP6134_SetRegister( pDevice, 0x51 + (i % 4) * 0x04, 0x57 );
	NVP6134_SetRegister( pDevice, 0x52 + (i % 4) * 0x04, 0xCA );
	NVP6134_SetRegister( pDevice, 0x53 + (i % 4) * 0x04, 0x52 );
	BYTE pn_set = NVP6134_GetRegister( pDevice, 0x44 ); SET_BIT( pn_set, (i % 4) );
	NVP6134_SetRegister( pDevice, 0x44, pn_set );
}

VOID NVP6134_SETCHN_EXT_3MNRT( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{	
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_EXT_3MNRT( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_AHD_3MNRT( pDevice, i, vfmt );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), 0x80 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), 0x04 );  
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x04 );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), 0x10 );

	#ifdef  THD_3MNRT_HSCALER
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), 0x02 );
	#else
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), 0x10 );
	#endif 

	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), 0x00 );  
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), ((i % 2) == 0) ? 0xF5 : 0x05 );
	NVP6134_SetRegister( pDevice, 0x8C + (i % 4), 0x44 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x0C + (i % 4), 0x00 );	
	NVP6134_SetRegister( pDevice, 0x10 + (i % 4), 0x80 );
	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), 0x1F ); 
	NVP6134_SetRegister( pDevice, 0x34 + (i % 4), 0xA6 );
	NVP6134_SetRegister( pDevice, 0x3C + (i % 4), 0xA8 ); 
	NVP6134_SetRegister( pDevice, 0x40 + (i % 4), 0x04 ); 
	NVP6134_SetRegister( pDevice, 0x44 + (i % 4), 0xF8 ); 
	NVP6134_SetRegister( pDevice, 0x48 + (i % 4), 0x00 ); 
	NVP6134_SetRegister( pDevice, 0x4C + (i % 4), 0x00 ); 
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4), 0xF9 );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x20, 0x86 ); 
	NVP6134_SetRegister( pDevice, 0x23, 0x80 );
	NVP6134_SetRegister( pDevice, 0x23, 0x00 );
	NVP6134_SetRegister( pDevice, 0x24, 0x0E ); 
	NVP6134_SetRegister( pDevice, 0x25, 0xDA );
	NVP6134_SetRegister( pDevice, 0x26, 0x90 );
	NVP6134_SetRegister( pDevice, 0x57, 0x10 );
	NVP6134_SetRegister( pDevice, 0x6E, 0x10 );
	NVP6134_SetRegister( pDevice, 0x6F, 0x2C ); 
	NVP6134_SetRegister( pDevice, 0x90, 0x05 );
	NVP6134_SetRegister( pDevice, 0xD0, 0x00 );
	NVP6134_SetRegister( pDevice, 0xD1, 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4) * 0x04, 0x8B );  
	NVP6134_SetRegister( pDevice, 0x51 + (i % 4) * 0x04, 0x2E );
	NVP6134_SetRegister( pDevice, 0x52 + (i % 4) * 0x04, 0xBA );
	NVP6134_SetRegister( pDevice, 0x53 + (i % 4) * 0x04, 0x48 );
	BYTE pn_set = NVP6134_GetRegister( pDevice, 0x44 ); SET_BIT( pn_set, (i % 4) );
	NVP6134_SetRegister( pDevice, 0x44, pn_set );

	#ifdef THD_3MNRT_HSCALER
	NVP6134_SetRegister( pDevice, 0x98 + (i % 4) * 0x20, 0x00 );
	NVP6134_SetRegister( pDevice, 0x99 + (i % 4) * 0x20, 0x03 );
	NVP6134_SetRegister( pDevice, 0x9A + (i % 4) * 0x20, 0x10 );
	NVP6134_SetRegister( pDevice, 0x9B + (i % 4) * 0x20, 0x01 );
	NVP6134_SetRegister( pDevice, 0x9C + (i % 4) * 0x20, 0x77 );
	NVP6134_SetRegister( pDevice, 0x9D + (i % 4) * 0x20, 0xC8 );
	NVP6134_SetRegister( pDevice, 0x9E + (i % 4) * 0x20, 0x20 );
	NVP6134_SetRegister( pDevice, 0x97 + (i % 4) * 0x20, 0xE1 );
	#endif 

	NVP6134_SetRegister( pDevice, 0xFF, 0x11 );
	NVP6134_SetRegister( pDevice, 0x00 + (i % 4) * 0x20, 0x0F );
	NVP6134_SetRegister( pDevice, 0x01 + (i % 4) * 0x20, 0x00 );
	NVP6134_SetRegister( pDevice, 0x02 + (i % 4) * 0x20, 0xA0 );
	NVP6134_SetRegister( pDevice, 0x03 + (i % 4) * 0x20, 0x08 );
	NVP6134_SetRegister( pDevice, 0x04 + (i % 4) * 0x20, 0x00 );
	NVP6134_SetRegister( pDevice, 0x05 + (i % 4) * 0x20, 0x13 );
	NVP6134_SetRegister( pDevice, 0x06 + (i % 4) * 0x20, 0x88 );
	NVP6134_SetRegister( pDevice, 0x07 + (i % 4) * 0x20, 0x01 );
	NVP6134_SetRegister( pDevice, 0x08 + (i % 4) * 0x20, 0x04 );
	NVP6134_SetRegister( pDevice, 0x0A + (i % 4) * 0x20, 0x06 );
	NVP6134_SetRegister( pDevice, 0x0B + (i % 4) * 0x20, 0x00 );
	NVP6134_SetRegister( pDevice, 0x0C + (i % 4) * 0x20, 0x06 );
	NVP6134_SetRegister( pDevice, 0x0D + (i % 4) * 0x20, 0x72 );
	NVP6134_SetRegister( pDevice, 0x10 + (i % 4) * 0x20, 0x01 );
	NVP6134_SetRegister( pDevice, 0x11 + (i % 4) * 0x20, 0x2C );
	NVP6134_SetRegister( pDevice, 0x12 + (i % 4) * 0x20, 0x00 );
	NVP6134_SetRegister( pDevice, 0x13 + (i % 4) * 0x20, 0x00 );
	NVP6134_SetRegister( pDevice, 0x14 + (i % 4) * 0x20, 0x00 );
	NVP6134_SetRegister( pDevice, 0x15 + (i % 4) * 0x20, 0x20 );
}

VOID NVP6134_SETCHN_AHD_QHD( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{	
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_AHD_QHD( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_COMMON_3M( pDevice, i, vfmt );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x23 + (i % 4) * 0x04, 0x41 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), 0x2A );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), 0x80 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x0F : 0x0E );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), 0x08 );
	NVP6134_SetRegister( pDevice, 0xA4 + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), ((i % 2) == 0) ? 0xF5 : 0x05 );
	NVP6134_SetRegister( pDevice, 0x8C + (i % 4), 0x44 );
	BYTE ycmerge = NVP6134_GetRegister( pDevice, 0xED ); SET_BIT( ycmerge, (i % 4) );
	NVP6134_SetRegister( pDevice, 0xED, ycmerge );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x1B, 0x24 );
	NVP6134_SetRegister( pDevice, 0x24, 0x3F );
	NVP6134_SetRegister( pDevice, 0x47, 0xEE );
	NVP6134_SetRegister( pDevice, 0x50, 0xC6 );
	NVP6134_SetRegister( pDevice, 0x5F, 0x50 );
	NVP6134_SetRegister( pDevice, 0x69, 0x10 );
	NVP6134_SetRegister( pDevice, 0x6E, 0x10 );
	NVP6134_SetRegister( pDevice, 0x6F, 0x32 );
	NVP6134_SetRegister( pDevice, 0xB7, 0xFF );
	NVP6134_SetRegister( pDevice, 0xBB, 0x0A );
	NVP6134_SetRegister( pDevice, 0xD1, 0x40 );	

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x86 : 0x86 );  
	NVP6134_SetRegister( pDevice, 0x51 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0xB5 : 0xBE );
	NVP6134_SetRegister( pDevice, 0x52 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x6F : 0x6A );
	NVP6134_SetRegister( pDevice, 0x53 + (i % 4) * 0x04, (vfmt == NVP6134_STD_PAL) ? 0x48 : 0x48 );
	BYTE pn_set = NVP6134_GetRegister( pDevice, 0x44 ); SET_BIT( pn_set, (i % 4) );
	NVP6134_SetRegister( pDevice, 0x44, pn_set );

	NVP6134_SetRegister( pDevice, 0xFF, 0x02 );
	NVP6134_SetRegister( pDevice, 0x29 + (i % 4) * 0x06, 0x50 );
	NVP6134_SetRegister( pDevice, 0x2A + (i % 4) * 0x06, 0x3C );
	NVP6134_SetRegister( pDevice, 0x2C + (i % 4) * 0x06, 0x4A );
}

VOID NVP6134_SETCHN_AHD_QHD_NRT( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{	
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_AHD_QHD_NRT( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_AHD_QHD( pDevice, i, vfmt );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x2A, 0xD2 );
	NVP6134_SetRegister( pDevice, 0xD1, 0x2A );
	NVP6134_SetRegister( pDevice, 0xD4, 0x1F );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4) * 0x04, 0x2C ); 
	NVP6134_SetRegister( pDevice, 0x51 + (i % 4) * 0x04, 0xE7 );
	NVP6134_SetRegister( pDevice, 0x52 + (i % 4) * 0x04, 0xCF );
	NVP6134_SetRegister( pDevice, 0x53 + (i % 4) * 0x04, 0x52 );
	BYTE pn_set = NVP6134_GetRegister( pDevice, 0x44 ); SET_BIT( pn_set, (i % 4) );
	NVP6134_SetRegister( pDevice, 0x44, pn_set );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), 0x04 );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x04 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), 0x80 );	
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x8C + (i % 4), 0x40 );
	BYTE ycmerge = NVP6134_GetRegister( pDevice, 0xED ); CLE_BIT( ycmerge, (i % 4) );
	NVP6134_SetRegister( pDevice, 0xED, ycmerge );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4));
	NVP6134_SetRegister( pDevice, 0x23, 0x00 );
	NVP6134_SetRegister( pDevice, 0x24, 0x3F );
	NVP6134_SetRegister( pDevice, 0x57, 0x20 );
	NVP6134_SetRegister( pDevice, 0x5F, 0x50 );
	NVP6134_SetRegister( pDevice, 0x69, 0x00 );
	NVP6134_SetRegister( pDevice, 0xD1, 0x00 );
	NVP6134_SetRegister( pDevice, 0xB7, 0xF0 );
	NVP6134_SetRegister( pDevice, 0xBB, 0x06 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x11 );
	NVP6134_SetRegister( pDevice, 0x01 + (i % 4) * 0x20, 0x00 );
	NVP6134_SetRegister( pDevice, 0x02 + (i % 4) * 0x20, 0xEA );
	NVP6134_SetRegister( pDevice, 0x03 + (i % 4) * 0x20, 0x0A );
	NVP6134_SetRegister( pDevice, 0x04 + (i % 4) * 0x20, 0x00 );
	NVP6134_SetRegister( pDevice, 0x05 + (i % 4) * 0x20, 0x0C );
	NVP6134_SetRegister( pDevice, 0x06 + (i % 4) * 0x20, 0xE4 );
	NVP6134_SetRegister( pDevice, 0x07 + (i % 4) * 0x20, 0x01 );
	NVP6134_SetRegister( pDevice, 0x08 + (i % 4) * 0x20, 0x90 );
	NVP6134_SetRegister( pDevice, 0x0A + (i % 4) * 0x20, 0x05 );
	NVP6134_SetRegister( pDevice, 0x0B + (i % 4) * 0x20, 0xA0 );
	NVP6134_SetRegister( pDevice, 0x0C + (i % 4) * 0x20, 0x05 );
	NVP6134_SetRegister( pDevice, 0x0D + (i % 4) * 0x20, 0xDB );
	NVP6134_SetRegister( pDevice, 0x0E + (i % 4) * 0x20, 0x05 );
	NVP6134_SetRegister( pDevice, 0x0F + (i % 4) * 0x20, 0xD1 );
	NVP6134_SetRegister( pDevice, 0x10 + (i % 4) * 0x20, 0x00 );
	NVP6134_SetRegister( pDevice, 0x11 + (i % 4) * 0x20, 0xA0 );
	NVP6134_SetRegister( pDevice, 0x12 + (i % 4) * 0x20, 0x01 );
	NVP6134_SetRegister( pDevice, 0x13 + (i % 4) * 0x20, 0x2C );
	NVP6134_SetRegister( pDevice, 0x14 + (i % 4) * 0x20, 0x00 );
	NVP6134_SetRegister( pDevice, 0x15 + (i % 4) * 0x20, 0x30 );
	NVP6134_SetRegister( pDevice, 0x00 + (i % 4) * 0x20, 0x0F );

	NVP6134_SetRegister( pDevice, 0xFF, 0x02 );
	NVP6134_SetRegister( pDevice, 0x29 + (i % 4) * 0x06, 0xA0 );
}

VOID NVP6134_SETCHN_AHD_QHD_X( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{	
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_AHD_QHD_X( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_AHD_QHD( pDevice, i, vfmt );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), 0x90 );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), 0x80 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x0F : 0x0E );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), 0x03 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), 0x04 );
	NVP6134_SetRegister( pDevice, 0x8C + (i % 4), 0x44 );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x47, 0x04 );
	NVP6134_SetRegister( pDevice, 0x50, 0x84 );
	NVP6134_SetRegister( pDevice, 0x69, 0x10 );
}

VOID NVP6134_SETCHN_AHD_5MNRT( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{	
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_AHD_5MNRT( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_COMMON_3M( pDevice, i, vfmt );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 ) ;
	NVP6134_SetRegister( pDevice, 0x23 + (i % 4) * 0x04, 0x41 );
	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), 0x14 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), 0x80 );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), 0x80 );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x05 );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), 0x10 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), 0x01 );
	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), 0x08 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x8C + (i % 4), 0x44 );
	BYTE ycmerge = NVP6134_GetRegister( pDevice, 0xED ); CLE_BIT( ycmerge, (i % 4) );
	NVP6134_SetRegister( pDevice, 0xED, ycmerge );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x24, 0x0A );	
	NVP6134_SetRegister( pDevice, 0x47, 0x04 );
	NVP6134_SetRegister( pDevice, 0x50, 0x84 );
	NVP6134_SetRegister( pDevice, 0x69, 0x00 );
	NVP6134_SetRegister( pDevice, 0x6E, 0x10 );
	NVP6134_SetRegister( pDevice, 0x6F, 0x1C );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4) * 0x04, 0x5F );  
	NVP6134_SetRegister( pDevice, 0x51 + (i % 4) * 0x04, 0xE5 );
	NVP6134_SetRegister( pDevice, 0x52 + (i % 4) * 0x04, 0xD0 );
	NVP6134_SetRegister( pDevice, 0x53 + (i % 4) * 0x04, 0x52 );
	BYTE pn_set = NVP6134_GetRegister( pDevice, 0x44 ); SET_BIT( pn_set, (i % 4) );
	NVP6134_SetRegister( pDevice, 0x44, pn_set );

	NVP6134_SetRegister( pDevice, 0xFF, 0x02 );
	NVP6134_SetRegister( pDevice, 0x29 + (i % 4) * 0x06, 0x51 );
	NVP6134_SetRegister( pDevice, 0x2A + (i % 4) * 0x06, 0x51 );
	NVP6134_SetRegister( pDevice, 0x2C + (i % 4) * 0x06, 0x4B );
}

VOID NVP6134_SETCHN_AHD_5M_20P( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{	
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_AHD_5M_20P( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_COMMON_3M( pDevice, i, vfmt );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x23 + (i % 4) * 0x04, 0x41 );
	NVP6134_SetRegister( pDevice, 0x30 + (i % 4), 0x14 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), 0x80 );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), 0x80 );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x05 );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), 0x10 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), 0x07 );
	NVP6134_SetRegister( pDevice, 0xA0 + (i % 4), 0x06 );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), ((i % 2) == 0) ? 0xF5 : 0x05 );
	NVP6134_SetRegister( pDevice, 0x8C + (i % 4), 0x44 );
	BYTE ycmerge = NVP6134_GetRegister( pDevice, 0xED ); SET_BIT( ycmerge, (i % 4) );
	NVP6134_SetRegister( pDevice, 0xED, ycmerge );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x24, 0x08 );
	NVP6134_SetRegister( pDevice, 0x2A, 0xD2 );	
	NVP6134_SetRegister( pDevice, 0x47, 0xEE );  
	NVP6134_SetRegister( pDevice, 0x50, 0xC6 );  
	NVP6134_SetRegister( pDevice, 0x69, 0x10 );  
	NVP6134_SetRegister( pDevice, 0x6E, 0x10 );
	NVP6134_SetRegister( pDevice, 0x6F, 0x1C );	
	NVP6134_SetRegister( pDevice, 0xB7, 0xF0 );  
	NVP6134_SetRegister( pDevice, 0xB8, 0x38 );  
	NVP6134_SetRegister( pDevice, 0xBB, 0x0A );  

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4) * 0x04, 0x9B );  
	NVP6134_SetRegister( pDevice, 0x51 + (i % 4) * 0x04, 0x0E );
	NVP6134_SetRegister( pDevice, 0x52 + (i % 4) * 0x04, 0x77 );
	NVP6134_SetRegister( pDevice, 0x53 + (i % 4) * 0x04, 0x48 );
	BYTE pn_set = NVP6134_GetRegister( pDevice, 0x44 ); SET_BIT( pn_set, (i % 4) );
	NVP6134_SetRegister( pDevice, 0x44, pn_set );

	NVP6134_SetRegister( pDevice, 0xFF, 0x02 );
	NVP6134_SetRegister( pDevice, 0x29 + (i % 4) * 0x06, 0x51 );
	NVP6134_SetRegister( pDevice, 0x2A + (i % 4) * 0x06, 0x51 );
	NVP6134_SetRegister( pDevice, 0x2C + (i % 4) * 0x06, 0x4B );

	NVP6134_SetRegister( pDevice, 0xFF, 0x11 );
	NVP6134_SetRegister( pDevice, 0x00 + (i % 4) * 0x20, 0x0D );
	NVP6134_SetRegister( pDevice, 0x01 + (i % 4) * 0x20, 0x00 );
	NVP6134_SetRegister( pDevice, 0x02 + (i % 4) * 0x20, 0x86 );
	NVP6134_SetRegister( pDevice, 0x03 + (i % 4) * 0x20, 0x0A );
	NVP6134_SetRegister( pDevice, 0x04 + (i % 4) * 0x20, 0x20 );
	NVP6134_SetRegister( pDevice, 0x05 + (i % 4) * 0x20, 0x0E );
	NVP6134_SetRegister( pDevice, 0x06 + (i % 4) * 0x20, 0xA6 );
	NVP6134_SetRegister( pDevice, 0x07 + (i % 4) * 0x20, 0x01 );
	NVP6134_SetRegister( pDevice, 0x08 + (i % 4) * 0x20, 0x04 );
	NVP6134_SetRegister( pDevice, 0x10 + (i % 4) * 0x20, 0x02 );
	NVP6134_SetRegister( pDevice, 0x11 + (i % 4) * 0x20, 0x60 );
	NVP6134_SetRegister( pDevice, 0x12 + (i % 4) * 0x20, 0x01 );
	NVP6134_SetRegister( pDevice, 0x13 + (i % 4) * 0x20, 0xCC );
	NVP6134_SetRegister( pDevice, 0x14 + (i % 4) * 0x20, 0x00 );
	NVP6134_SetRegister( pDevice, 0x15 + (i % 4) * 0x20, 0x3C );
}

VOID NVP6134_SETCHN_EXT_5MNRT( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{	
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_EXT_5MNRT( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_AHD_5MNRT( pDevice, i, vfmt );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x58, 0x70 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), 0xF5 );  
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x05 );
	NVP6134_SetRegister( pDevice, 0x89 + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), 0x00 );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), ((i % 2) == 0) ? 0xF5 : 0x05 );
	NVP6134_SetRegister( pDevice, 0x8C + (i % 4), 0x44 );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x24, 0x20 );
	NVP6134_SetRegister( pDevice, 0x57, 0x10 );
	NVP6134_SetRegister( pDevice, 0x6E, 0x10 );
	NVP6134_SetRegister( pDevice, 0x6F, 0x32 );	
	NVP6134_SetRegister( pDevice, 0x90, 0x05 );
	NVP6134_SetRegister( pDevice, 0xD0, 0x00 );
	NVP6134_SetRegister( pDevice, 0xD1, 0x20 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x09 );
	NVP6134_SetRegister( pDevice, 0x50 + (i % 4) * 0x04, 0x8B );  
	NVP6134_SetRegister( pDevice, 0x51 + (i % 4) * 0x04, 0x2E );
	NVP6134_SetRegister( pDevice, 0x52 + (i % 4) * 0x04, 0xBA );
	NVP6134_SetRegister( pDevice, 0x53 + (i % 4) * 0x04, 0x48 );
	BYTE pn_set = NVP6134_GetRegister( pDevice, 0x44 ); SET_BIT( pn_set, (i % 4) );
	NVP6134_SetRegister( pDevice, 0x44, pn_set );

	NVP6134_SetRegister( pDevice, 0xFF, 0x11 );
	NVP6134_SetRegister( pDevice, 0x00 + (i % 4) * 0x20, 0x0F );
	NVP6134_SetRegister( pDevice, 0x01 + (i % 4) * 0x20, 0x00 );
	NVP6134_SetRegister( pDevice, 0x02 + (i % 4) * 0x20, 0xCE );
	NVP6134_SetRegister( pDevice, 0x03 + (i % 4) * 0x20, 0x0A );
	NVP6134_SetRegister( pDevice, 0x04 + (i % 4) * 0x20, 0x34 );
	NVP6134_SetRegister( pDevice, 0x05 + (i % 4) * 0x20, 0x17 );
	NVP6134_SetRegister( pDevice, 0x06 + (i % 4) * 0x20, 0x70 );
	NVP6134_SetRegister( pDevice, 0x07 + (i % 4) * 0x20, 0x01 );
	NVP6134_SetRegister( pDevice, 0x08 + (i % 4) * 0x20, 0x04 );
	NVP6134_SetRegister( pDevice, 0x0A + (i % 4) * 0x20, 0x07 );
	NVP6134_SetRegister( pDevice, 0x0B + (i % 4) * 0x20, 0x98 );
	NVP6134_SetRegister( pDevice, 0x0C + (i % 4) * 0x20, 0x07 );
	NVP6134_SetRegister( pDevice, 0x0D + (i % 4) * 0x20, 0xD0 ); 
	NVP6134_SetRegister( pDevice, 0x10 + (i % 4) * 0x20, 0x00 );
	NVP6134_SetRegister( pDevice, 0x11 + (i % 4) * 0x20, 0xC0 );
	NVP6134_SetRegister( pDevice, 0x12 + (i % 4) * 0x20, 0x00 );
	NVP6134_SetRegister( pDevice, 0x13 + (i % 4) * 0x20, 0x00 );
	NVP6134_SetRegister( pDevice, 0x14 + (i % 4) * 0x20, 0x00 );
	NVP6134_SetRegister( pDevice, 0x15 + (i % 4) * 0x20, 0x00 );
}

VOID NVP6134_SETCHN_AHD_8M_NRT( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{	
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_AHD_8M_NRT( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_COMMON_3M( pDevice, i, vfmt );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), 0x90 );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), 0x80 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), 0x03 );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x06 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), 0x03 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x8C + (i % 4), 0x40 );
	NVP6134_SetRegister( pDevice, 0xED, 0x00 );	

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x24, 0x0A );
	NVP6134_SetRegister( pDevice, 0x47, 0x04 );
	NVP6134_SetRegister( pDevice, 0x50, 0x84 );
	NVP6134_SetRegister( pDevice, 0x69, 0x00 );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x02 );
	NVP6134_SetRegister( pDevice, 0x29 + (i % 4) * 0x06, 0x78 );
	NVP6134_SetRegister( pDevice, 0x2A + (i % 4) * 0x06, 0x5A );
	NVP6134_SetRegister( pDevice, 0x2C + (i % 4) * 0x06, 0x72 );
}

VOID NVP6134_SETCHN_AHD_UHDX( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt ) // [HUENGPEI] [2017.02.05.16110301] 
{
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SETCHN_AHD_UHDX( %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt);

	NVP6134_SETCHN_COMMON_3M( pDevice, i, vfmt );

	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );
	NVP6134_SetRegister( pDevice, 0x58 + (i % 4), 0x90 );
	NVP6134_SetRegister( pDevice, 0x64 + (i % 4), 0x80 );
	NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x0D : 0x0C );
	NVP6134_SetRegister( pDevice, 0x85 + (i % 4), 0x00 );
	NVP6134_SetRegister( pDevice, 0x8E + (i % 4), 0x00 );

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );
	NVP6134_SetRegister( pDevice, 0x84 + (i % 4), 0x04 );
	NVP6134_SetRegister( pDevice, 0x8C + (i % 4), 0x44 );
	NVP6134_SetRegister( pDevice, 0xED, 0x0F );

	NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
	NVP6134_SetRegister( pDevice, 0x24, 0x0A );
	NVP6134_SetRegister( pDevice, 0x47, 0x04 );
	NVP6134_SetRegister( pDevice, 0x50, 0x84 );
	NVP6134_SetRegister( pDevice, 0x69, 0x10 );
	
	NVP6134_SetRegister( pDevice, 0xFF, 0x02 );
	NVP6134_SetRegister( pDevice, 0x29 + (i % 4) * 0x06, 0x3C );
	NVP6134_SetRegister( pDevice, 0x2A + (i % 4) * 0x06, 0x5A );
	NVP6134_SetRegister( pDevice, 0x2C + (i % 4) * 0x06, 0x36 );		
}

#endif

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

BYTE NVP6134_GET_FSCLOCK_STATUS( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i ) // [HUENGPEI] [2017.02.05.16110301] 
{
	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );

	BYTE n_fsc_lock = NVP6134_GetRegister( pDevice, 0xE8 + (i % 4) );

	BYTE n_lock = ((n_fsc_lock >> 1) & 0x01);
	
	return n_lock;
}

VOID NVP6134_RESET_FSCLOCK( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i ) // [HUENGPEI] [2017.02.05.16110301] 
{
	unsigned char n_acc_ref = 0;

	unsigned char n_check_cnt = 4;

	do {

		NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );

		n_acc_ref = NVP6134_GetRegister( pDevice, 0x27 );

		NVP6134_SetRegister( pDevice, 0x23, 0x80 );

		NVP6134_SetRegister( pDevice, 0x27, 0x10 );

		F6B9E557A4BA24ffd926B820B836289C8_100NS( 350000 );

		NVP6134_SetRegister( pDevice, 0x23, 0x00 );

		NVP6134_SetRegister( pDevice, 0x27, n_acc_ref );

		F6B9E557A4BA24ffd926B820B836289C8_100NS( 3000000 );
	}
	while( (NVP6134_GET_FSCLOCK_STATUS( pDevice, i ) == 0) && ((n_check_cnt--) > 0) );
}

VOID NVP6134_CVBS_SLICELEVEL_CON( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, UINT onoff ) // [HUENGPEI] [2017.02.05.16110301] 
{
	MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(g_pDevice[ pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE + i ]->m_pCustomSystemConfigProperty);
			
	NVP6134_SIGNAL_INFO * p_sg_info = (NVP6134_SIGNAL_INFO *)(&(p_sys_cfg->m_s_nvp6134_sg_info));
	
	if( p_sg_info->ch_mode_status[ i ] < NVP6134_VI_720P_2530 ) {
	
		NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );

		if( onoff == 1 ) {

			NVP6134_SetRegister( pDevice, 0x08, 0x70 );
		}
		else {

			NVP6134_SetRegister( pDevice, 0x08, 0x50 );
		}
	}
}

VOID NVP6134_GET_VIDEO_LOSS( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice ) // [HUENGPEI] [2017.02.05.16110301] 
{	
	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );

	BYTE RA8 = NVP6134_GetRegister( pDevice, 0xA8 ) & 0x0F;
    
	BYTE i = 0;
	for( i = 0 ; i < 4 ; i++ ) { // IF VIDEO SIGNAL IS LOSS, THEN CHANGE VALUE
    	
		MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(g_pDevice[ pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE + i ]->m_pCustomSystemConfigProperty);
			
		NVP6134_SIGNAL_INFO * p_sg_info = (NVP6134_SIGNAL_INFO *)(&(p_sys_cfg->m_s_nvp6134_sg_info));
	
		if( RA8 == (0x01 << (i % 4)) ) {
		
			NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );

			BYTE n_sync_width = NVP6134_GetRegister( pDevice, 0x84 );

			BYTE n_sync_slice = NVP6134_GetRegister( pDevice, 0x86 );

			if( (n_sync_width == 0) && 
				
				(n_sync_slice == 0) ) {

				NVP6134_SetRegister( pDevice, 0x84, 0x01 );

				NVP6134_SetRegister( pDevice, 0x86, 0x40 );
			}
			else {

				NVP6134_SetRegister( pDevice, 0x84, 0x00 );

				NVP6134_SetRegister( pDevice, 0x86, 0x00 );
			}

			NVP6134_CVBS_SLICELEVEL_CON( pDevice, i, 0 );
		}
		else {

			NVP6134_CVBS_SLICELEVEL_CON( pDevice, i, 1 );

			if( (NVP6134_GET_FSCLOCK_STATUS( pDevice, i ) == 0) && ((p_sg_info->ch_mode_status[ i ] == NVP6134_VI_EXT_1080P) || 
				
																	(p_sg_info->ch_mode_status[ i ] == NVP6134_VI_EXT_3M_NRT)) ) {
				NVP6134_RESET_FSCLOCK( pDevice, i );
			}
		}
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

INT NVP6134_SET_PORTMODE( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, BYTE portsel, BYTE portmode, BYTE chid )
{
	switch( portmode ) {

		case NVP6134_OUTMODE_1MUX_SD: {

			NVP6134_SetRegister( pDevice, 0xFF, 0x00 );

			NVP6134_SetRegister( pDevice, 0x56, 0x10 );

			NVP6134_SetRegister( pDevice, 0xFF, 0x01 );

			NVP6134_SetRegister( pDevice, 0xC0 + (portsel * 2), (chid << 4)| (chid) );

			NVP6134_SetRegister( pDevice, 0xC1 + (portsel * 2), (chid << 4)| (chid) );

			BYTE RC8 = NVP6134_GetRegister( pDevice, 0xC8 + (portsel / 2) ); RC8 &= ((portsel % 2) ? 0x0F : 0xF0 );

			NVP6134_SetRegister( pDevice, 0xC8 + (portsel / 2), RC8 );

			NVP6134_SetRegister( pDevice, 0xCC + (portsel * 1), 0x86 );

			break;
		}
		case NVP6134_OUTMODE_1MUX_HD: {

			NVP6134_SetRegister( pDevice, 0xFF, 0x00 );

			NVP6134_SetRegister( pDevice, 0x56, 0x10 );

			NVP6134_SetRegister( pDevice, 0xFF, 0x01 );

			NVP6134_SetRegister( pDevice, 0xC0 + (portsel * 2), (chid << 4)| (chid) );

			NVP6134_SetRegister( pDevice, 0xC1 + (portsel * 2), (chid << 4)| (chid) );

			BYTE RC8 = NVP6134_GetRegister( pDevice, 0xC8 + (portsel / 2) ); RC8 &= ((portsel % 2) ? 0x0F : 0xF0 );

			NVP6134_SetRegister( pDevice, 0xC8 + (portsel / 2), RC8 );

			NVP6134_SetRegister( pDevice, 0xCC + (portsel * 1), 0x16 );   

			break;
		}	
		case NVP6134_OUTMODE_1MUX_HD5060:

		case NVP6134_OUTMODE_1MUX_FHD:

		case NVP6134_OUTMODE_1MUX_4M_NRT: {

			NVP6134_SetRegister( pDevice, 0xFF, 0x00 );

			NVP6134_SetRegister( pDevice, 0x56, 0x10 );

			NVP6134_SetRegister( pDevice, 0xFF, 0x01 );

			NVP6134_SetRegister( pDevice, 0xC0 + (portsel * 2), (chid << 4)| (chid) );

			NVP6134_SetRegister( pDevice, 0xC1 + (portsel * 2), (chid << 4)| (chid) );

			BYTE RC8 = NVP6134_GetRegister( pDevice, 0xC8 + (portsel / 2) ); RC8 &= ((portsel % 2) ? 0x0F : 0xF0 );

			NVP6134_SetRegister( pDevice, 0xC8 + (portsel / 2), RC8 );
			
			NVP6134_SetRegister( pDevice, 0xCC + (portsel * 1), 0x46 );  

			break;
		}
		case NVP6134_OUTMODE_1MUX_3M_RT: {

			NVP6134_SetRegister( pDevice, 0xFF, 0x00 );

			NVP6134_SetRegister( pDevice, 0x56, 0x10 );

			NVP6134_SetRegister( pDevice, 0xFF, 0x01 );

			NVP6134_SetRegister( pDevice, 0xC0 + (portsel * 2), (chid << 4)| (chid) );

			NVP6134_SetRegister( pDevice, 0xC1 + (portsel * 2), (chid << 4)| (chid) );

			BYTE RC8 = NVP6134_GetRegister( pDevice, 0xC8 + (portsel / 2) ); RC8 &= ((portsel % 2) ? 0x0F : 0xF0 );

			NVP6134_SetRegister( pDevice, 0xC8 + (portsel / 2), RC8 );
			
			NVP6134_SetRegister( pDevice, 0xCC + (portsel * 1), 0x66 );  

			break;
		}
		default: {

			break;	
		}
  	}
	if(	portmode == NVP6134_OUTMODE_2MUX_MIX  ||

		portmode == NVP6134_OUTMODE_2MUX_SD	||

		portmode == NVP6134_OUTMODE_2MUX_HD_X ||

		portmode == NVP6134_OUTMODE_2MUX_FHD_X ) {
	
		NVP6134_SetRegister( pDevice, 0xFF, 0x01 );

		NVP6134_SetRegister( pDevice, 0xE4, 0x10 );  // ENABLE 2MIX CIF MODE

		NVP6134_SetRegister( pDevice, 0xE5, 0x10 );
	}
	else {

		NVP6134_SetRegister( pDevice, 0xFF, 0x01 );

		NVP6134_SetRegister( pDevice, 0xE4, 0x00 );  // DISABLE 2MIX CIF MODE

		NVP6134_SetRegister( pDevice, 0xE5, 0x00 );
	}
	if(	portmode==NVP6134_OUTMODE_2MUX_SD || 

		portmode==NVP6134_OUTMODE_4MUX_SD ) {
	
		NVP6134_SetRegister( pDevice, 0xFF, 0x01 );

		NVP6134_SetRegister( pDevice, 0xA0 + (portsel * 1), 0x20 );  // TM CLOCK MODE SEL MANUAL
	}
	else {
	
		NVP6134_SetRegister( pDevice, 0xFF, 0x01 );

		NVP6134_SetRegister( pDevice, 0xA0 + (portsel * 1), 0x00 ); // TM CLOCK MODE SEL AUTO
	}
	return 0;
}

INT NVP6134_SET_CHNMODE( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, UINT i, ULONG vfmt, ULONG chnmode ) // [HUENGPEI] [2016.11.15.16110301] 
{  
	MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(g_pDevice[ pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE + i ]->m_pCustomSystemConfigProperty);
			
	NVP6134_SIGNAL_INFO * p_sg_info = (NVP6134_SIGNAL_INFO *)(&(p_sys_cfg->m_s_nvp6134_sg_info));
	
	if( i >= 4 ) { F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SET_CHNMODE( %02X, %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt, chnmode); return -1; }	

	if( vfmt > NVP6134_STD_PAL ) { F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SET_CHNMODE( %02X, %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt, chnmode); return -1; }	

	if( chnmode >= NVP6134_VI_BUTT ) { F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] NVP6134_SET_CHNMODE( %02X, %02X, %02X ) ERROR!!\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, vfmt, chnmode); return -1; }

	if( chnmode < NVP6134_VI_BUTT )  {
				
		ULONG x = 0;

		ULONG y = 0;

		ULONG fps = 0;

		ULONG m = 0;

		ULONG interleaved = 0;

		NVP6134_SET_COMMON_VALUE( pDevice, i, chnmode );
		
		switch( chnmode ) {
		case NVP6134_VI_720H:		   NVP6134_SETCHN_720H(              pDevice, i, vfmt ); x =  720; y = (vfmt == NVP6134_STD_PAL) ?  288 :  240; fps = (vfmt == NVP6134_STD_PAL) ? 50 : 60; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 1; break;
		case NVP6134_VI_960H:		   NVP6134_SETCHN_960H(              pDevice, i, vfmt ); x =  960; y = (vfmt == NVP6134_STD_PAL) ?  288 :  240; fps = (vfmt == NVP6134_STD_PAL) ? 50 : 60; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 1; break;
		case NVP6134_VI_1280H:		   NVP6134_SETCHN_1280H(             pDevice, i, vfmt ); x = 1280; y = (vfmt == NVP6134_STD_PAL) ?  288 :  240; fps = (vfmt == NVP6134_STD_PAL) ? 50 : 60; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 1; break;
		case NVP6134_VI_1440H:		   NVP6134_SETCHN_1440H(             pDevice, i, vfmt ); x = 1440; y = (vfmt == NVP6134_STD_PAL) ?  288 :  240; fps = (vfmt == NVP6134_STD_PAL) ? 50 : 60; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 1; break;
		case NVP6134_VI_1920H:		   NVP6134_SETCHN_1920H(             pDevice, i, vfmt ); x = 1920; y = (vfmt == NVP6134_STD_PAL) ?  288 :  240; fps = (vfmt == NVP6134_STD_PAL) ? 50 : 60; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 1; break;	
		case NVP6134_VI_960H2EX:	   NVP6134_SETCHN_3840H(             pDevice, i, vfmt ); x = 3840; y = (vfmt == NVP6134_STD_PAL) ?  288 :  240; fps = (vfmt == NVP6134_STD_PAL) ? 50 : 60; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 1; break;
		
		case NVP6134_VI_720P_2530:	   NVP6134_SETCHN_AHD_720P(          pDevice, i, vfmt ); x = 1280; y = (vfmt == NVP6134_STD_PAL) ?  720 :  720; fps = (vfmt == NVP6134_STD_PAL) ? 25 : 30; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 0; break;
		case NVP6134_VI_EXC_720P:	   NVP6134_SETCHN_EXC_720P(          pDevice, i, vfmt ); x = 1280; y = (vfmt == NVP6134_STD_PAL) ?  720 :  720; fps = (vfmt == NVP6134_STD_PAL) ? 25 : 30; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 0; break;
		case NVP6134_VI_EXT_720PA:	   NVP6134_SETCHN_EXTA_720P(         pDevice, i, vfmt ); x = 1280; y = (vfmt == NVP6134_STD_PAL) ?  720 :  720; fps = (vfmt == NVP6134_STD_PAL) ? 25 : 30; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 0; break;
		case NVP6134_VI_EXT_720PB:	   NVP6134_SETCHN_EXTB_720P(         pDevice, i, vfmt ); x = 1280; y = (vfmt == NVP6134_STD_PAL) ?  720 :  720; fps = (vfmt == NVP6134_STD_PAL) ? 25 : 30; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 0; break;
		
		case NVP6134_VI_HDEX:		   NVP6134_SETCHN_AHD_720PEX(        pDevice, i, vfmt ); x = 2560; y = (vfmt == NVP6134_STD_PAL) ?  720 :  720; fps = (vfmt == NVP6134_STD_PAL) ? 25 : 30; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 0; break;
		case NVP6134_VI_EXC_HDEX:	   NVP6134_SETCHN_EXC_720PEX(        pDevice, i, vfmt ); x = 2560; y = (vfmt == NVP6134_STD_PAL) ?  720 :  720; fps = (vfmt == NVP6134_STD_PAL) ? 25 : 30; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 0; break;
		case NVP6134_VI_EXT_HDAEX:	   NVP6134_SETCHN_EXTA_720PEX(       pDevice, i, vfmt ); x = 2560; y = (vfmt == NVP6134_STD_PAL) ?  720 :  720; fps = (vfmt == NVP6134_STD_PAL) ? 25 : 30; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 0; break;
		case NVP6134_VI_EXT_HDBEX:	   NVP6134_SETCHN_EXTB_720PEX(       pDevice, i, vfmt ); x = 2560; y = (vfmt == NVP6134_STD_PAL) ?  720 :  720; fps = (vfmt == NVP6134_STD_PAL) ? 25 : 30; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 0; break;
		
		case NVP6134_VI_720P_5060:	   NVP6134_SETCHN_AHD_720P5060(      pDevice, i, vfmt ); x = 1280; y = (vfmt == NVP6134_STD_PAL) ?  720 :  720; fps = (vfmt == NVP6134_STD_PAL) ? 50 : 60; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 0; break;	
		case NVP6134_VI_EXC_720PRT:	   NVP6134_SETCHN_EXC_720P5060(      pDevice, i, vfmt ); x = 1280; y = (vfmt == NVP6134_STD_PAL) ?  720 :  720; fps = (vfmt == NVP6134_STD_PAL) ? 50 : 60; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 0; break;
		case NVP6134_VI_EXT_720PRT:	   NVP6134_SETCHN_EXT_720P5060(      pDevice, i, vfmt ); x = 1280; y = (vfmt == NVP6134_STD_PAL) ?  720 :  720; fps = (vfmt == NVP6134_STD_PAL) ? 50 : 60; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 0; break;	

		case NVP6134_VI_1080P_2530:	   NVP6134_SETCHN_AHD_1080P2530(     pDevice, i, vfmt ); x = 1920; y = (vfmt == NVP6134_STD_PAL) ? 1080 : 1080; fps = (vfmt == NVP6134_STD_PAL) ? 25 : 30; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 0; break;
		case NVP6134_VI_EXC_1080P:	   NVP6134_SETCHN_EXC_1080P2530(     pDevice, i, vfmt ); x = 1920; y = (vfmt == NVP6134_STD_PAL) ? 1080 : 1080; fps = (vfmt == NVP6134_STD_PAL) ? 25 : 30; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 0; break;	
		case NVP6134_VI_EXT_1080P:	   NVP6134_SETCHN_EXT_1080P2530(     pDevice, i, vfmt ); x = 1920; y = (vfmt == NVP6134_STD_PAL) ? 1080 : 1080; fps = (vfmt == NVP6134_STD_PAL) ? 25 : 30; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 0; break;
		case NVP6134_VI_1080P_NRT:	   NVP6134_SETCHN_AHD_1080P_NRT(     pDevice, i, vfmt ); x = 1920; y = (vfmt == NVP6134_STD_PAL) ? 1080 : 1080; fps = (vfmt == NVP6134_STD_PAL) ? 25 : 30; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 0; break;

		case NVP6134_VI_3M:			   NVP6134_SETCHN_AHD_3M(            pDevice, i, vfmt ); x = 2048; y = (vfmt == NVP6134_STD_PAL) ? 1536 : 1536; fps = (vfmt == NVP6134_STD_PAL) ? 25 : 30; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 0; break;
		case NVP6134_VI_3M_NRT:		   NVP6134_SETCHN_AHD_3MNRT(         pDevice, i, vfmt ); x = 2048; y = (vfmt == NVP6134_STD_PAL) ? 1536 : 1536; fps = (vfmt == NVP6134_STD_PAL) ? 25 : 30; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 0; break;
		case NVP6134_VI_EXT_3M_NRT:    NVP6134_SETCHN_EXT_3MNRT(         pDevice, i, vfmt ); x = 2048; y = (vfmt == NVP6134_STD_PAL) ? 1536 : 1536; fps = (vfmt == NVP6134_STD_PAL) ? 25 : 30; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 0; break;

		case NVP6134_VI_4M:			   NVP6134_SETCHN_AHD_QHD(           pDevice, i, vfmt ); x = 2560; y = (vfmt == NVP6134_STD_PAL) ? 1440 : 1440; fps = (vfmt == NVP6134_STD_PAL) ? 25 : 30; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 0; break;
		case NVP6134_VI_4M_NRT:		   NVP6134_SETCHN_AHD_QHD_NRT(       pDevice, i, vfmt ); x = 2560; y = (vfmt == NVP6134_STD_PAL) ? 1440 : 1440; fps = (vfmt == NVP6134_STD_PAL) ? 25 : 30; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 0; break;

		case NVP6134_VI_5M_NRT: 	   NVP6134_SETCHN_AHD_5MNRT(         pDevice, i, vfmt ); x = 2592; y = (vfmt == NVP6134_STD_PAL) ? 1944 : 1944; fps = (vfmt == NVP6134_STD_PAL) ? 25 : 30; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 0; break;
		case NVP6134_VI_5M_20P: 	   NVP6134_SETCHN_AHD_5M_20P(        pDevice, i, vfmt ); x = 2592; y = (vfmt == NVP6134_STD_PAL) ? 1944 : 1944; fps = (vfmt == NVP6134_STD_PAL) ? 25 : 30; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 0; break;
		case NVP6134_VI_EXT_5M_NRT:    NVP6134_SETCHN_EXT_5MNRT(         pDevice, i, vfmt ); x = 2592; y = (vfmt == NVP6134_STD_PAL) ? 1944 : 1944; fps = (vfmt == NVP6134_STD_PAL) ? 25 : 30; m = (vfmt == NVP6134_STD_PAL) ? 0 : 1; interleaved = 0; break;

		case NVP6134_VI_1080P_NOVIDEO: NVP6134_SETCHN_AHD_1080P_NOVIDEO( pDevice, i, vfmt ); break;
		default:                       NVP6134_SETCHN_AHD_1080P_NOVIDEO( pDevice, i, vfmt ); break;
		}
		p_sg_info->ch_vfmt_status[ i ] = vfmt;

		p_sg_info->ch_mode_status[ i ] = chnmode;

		if( NVP6134_VI_1080P_NOVIDEO != p_sg_info->ch_mode_status[ i ] ) { 

		//	ACP_EACH_SETTING( i ); // INITALIZE ACP PROTOCOL EACH MODE [ACP.TODO]

		//	EQ_INIT_EACH_FORMAT( i, chnmode, vfmt ); // SET EQ CONFIGURATION [EQ.TODO]
		}
		NVP6134_SetRegister( pDevice, 0xFF, 0x09 );

		NVP6134_SetRegister( pDevice, 0x40 + (i % 4), 0x61 );

        F6B9E557A4BA24ffd926B820B836289C8_100NS( 350000 );

		if( p_sg_info->ch_mode_status[ i ] < NVP6134_VI_720P_2530 ) {

			NVP6134_SetRegister( pDevice, 0x40 + (i % 4), 0x60 ); // FOR COMET SETTING
		}
		else {

			NVP6134_SetRegister( pDevice, 0x40 + (i % 4), 0x00 ); 
		}
	}
	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );

	NVP6134_SetRegister( pDevice, 0x00 + (i % 4), 0x00 );

	return 0;
}

VOID NVP6134_SYSTEM_INIT( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice ) // [HUENGPEI] [2017.02.05.16110301] 
{
	NVP6134_SetRegister( pDevice, 0xFF, 0x00 );

	NVP6134_SetRegister( pDevice, 0x80, 0x0F );

	NVP6134_SetRegister( pDevice, 0xFF, 0x01 );

	NVP6134_SetRegister( pDevice, 0xCA, 0xFF ); // NVP6134 HAS 4 PORTS
}

VOID NVP6134_COMMON_INIT( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice ) // [HUENGPEI] [2017.02.05.16110301] 
{
	NVP6134_SYSTEM_INIT( pDevice );

	BYTE i = 0;
	for( i = 0 ; i < 4 ; i++ ) {

		NVP6134_SetRegister( pDevice, 0xFF, 0x03 + ((i % 4) / 2) );

		NVP6134_SetRegister( pDevice, 0x6B + (i % 2) * 0x80, 0x00 );

	//	INIT_ACP( i ) [ACP.TODO]
	}
	NVP6134_SET_CHNMODE( pDevice, 0, NVP6134_STD_PAL, NVP6134_VI_1080P_NOVIDEO );

	NVP6134_SET_CHNMODE( pDevice, 1, NVP6134_STD_PAL, NVP6134_VI_1080P_NOVIDEO );

	NVP6134_SET_CHNMODE( pDevice, 2, NVP6134_STD_PAL, NVP6134_VI_1080P_NOVIDEO );

	NVP6134_SET_CHNMODE( pDevice, 3, NVP6134_STD_PAL, NVP6134_VI_1080P_NOVIDEO );
	
	NVP6134_SET_PORTMODE( pDevice, 0, NVP6134_OUTMODE_1MUX_FHD, 0 );  

	NVP6134_SET_PORTMODE( pDevice, 1, NVP6134_OUTMODE_1MUX_FHD, 1 );

	NVP6134_SET_PORTMODE( pDevice, 2, NVP6134_OUTMODE_1MUX_FHD, 2 );

	NVP6134_SET_PORTMODE( pDevice, 3, NVP6134_OUTMODE_1MUX_FHD, 3 );

//	AUDIO_INIT( 1, 0, 16, 0, 0 );
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

unsigned char NVP6134_VFMT_CONVERT( unsigned char vdsts, unsigned char g_ck_fmt )
{
	unsigned char ret = 0x00; // NOT DETECTS

	switch( vdsts ) {

	case 0x00: ret = 0x01; break; // CVBS NTSC
	case 0x10: ret = 0x02; break; // CVBS PAL
	case 0x20: ret = 0x04; break; // 720P NTSC
	case 0x21: ret = 0x08; break; // 720P PAL
	case 0x22: ret = 0x51; break; // 720P@RT NTSC
	case 0x23: ret = 0x52; break; // 720P@RT PAL
	case 0x30: ret = 0x40; break; // 1080P NTSC
	case 0x31: ret = 0x80; break; // 1080P PAL
	case 0x2B: ret = 0x11; break; // HD EXC  @ 30P
	case 0x2C: ret = 0x12; break; // HD EXC  @ 25P
	case 0x25: ret = 0x31; break; // HD EXT  @ 30A
	case 0x26: ret = 0x32; break; // HD EXT  @ 24A
	case 0x29: ret = 0x34; break; // HD EXT  @ 30B
	case 0x2A: ret = 0x38; break; // HD EXT  @ 25B
	case 0x2D: ret = 0x51; break; // HD EXC  @ 60P
	case 0x2E: ret = 0x52; break; // HD EXC  @ 50P
	case 0x27: ret = 0x54; break; // HD EXT  @ 60
	case 0x28: ret = 0x58; break; // HD EXT  @ 50
	case 0x35: ret = 0x71; break; // FHD EXC @ 30P
	case 0x36: ret = 0x72; break; // FHD EXC @ 25P
	case 0x33: ret = 0x74; break; // FHD EXT @ 30P
	case 0x34: ret = 0x78; break; // FHD EXT @ 25P
 // case 0x3F: ret = 0x44; break; // FHD NRT @ 30P
	case 0x40: ret = 0x81; break; // QHD AHD @ 30P
	case 0x41: ret = 0x82; break; // QHD AHD @ 25P
	case 0x4F: ret = 0x83; break; // QHD AHD @ NRT-15P
	case 0xA0: ret = 0xA0; break; // 5M AHD @ 12.5P
	case 0xA1: ret = 0xA1; break; // 5M 20P
	case 0xA2: ret = 0xA2; break; // EXT @ 5M @ 12.5P
	case 0x03: ret = 0x90; break; // AHD @ 3M NRT-18P
	case 0x04: ret = 0x90; break; // AHD @ 3M NRT-18P
	case 0x64: ret = 0x93; break; // EXT @ 3M NRT-18P
	case 0xFF: ret = 0x00; break; // NOT DETECTS
	case 0x01:
	case 0x02: {
		
		if( (g_ck_fmt >> 4) == 0x02) {
			
			ret = 0x91;	// AHD @ 3M RT-30P
		}
		else {
			
			ret = 0x92;	// AHD @ 3M RT-25P
		}
		break;
	}
	}
	return ret;
}

unsigned char NVP6134_TRANS_AHD_TO_CHD( unsigned char vfmt )
{
	unsigned char format;

	// MAPPING VIDEO TYPE BETWEEN AHD AND CHD
	// 
	if( vfmt == 0x04 ) {

		format = 0x11; // MAPPING AHD 720P NTSC TO HD EXC @ 30P
	}
	else if( vfmt == 0x08 ) {
	
		format = 0x12; // MAPPING AHD 720P PAL  TO HD EXC @ 25P
	}
	else if( vfmt == 0x10 ) {
	
		format = 0x51; // MAPPING AHD 720P @ RT NTSC TO HD EXC @ 60P
	}
	else if( vfmt == 0x20 ) {
	
		format = 0x52; // MAPPING AHD 720P @ RT PAL  TO HD EXC @ 50P
	}
	else if( vfmt == 0x40 ) {
	
		format = 0x71; // MAPPING AHD 1080P NTSC TO FHD EXC @ 30P
	}
	else if( vfmt == 0x80 ) {
	
		format = 0x72; // MAPPING AHD 1080P PAL  TO FHD EXC @ 25P
	}
	else {

		format = vfmt;
	}
	return format;
}

BOOL NVP6134_IS_AHD_MODE( unsigned char vfmt )
{
	if( vfmt == 0x04 || vfmt == 0x08 || 
		
		vfmt == 0x10 || vfmt == 0x20 || vfmt == 0x40 || vfmt == 0x80 ) {
	
		return TRUE;
	}
	return FALSE;
}

/*
VOID NVP6134_ACP_RT2NRT( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, unsigned char i, unsigned char vfmt )
{
	MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(g_pDevice[ pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE ]->m_pCustomSystemConfigProperty);
			
	NVP6134_SIGNAL_INFO * p_sg_info = (NVP6134_SIGNAL_INFO *)(&(p_sys_cfg->m_s_nvp6134_sg_info));
	
	if( p_sg_info->ch_mode_status[ i ] == NVP6134_VI_3M ) {

		NVP6134_SetRegister( pDevice, 0xFF, 0x00 );

		NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x03 : 0x02 );

		acp_isp_write( pDevice, i, 0xB101, 0x00 );

		F6B9E557A4BA24ffd926B820B836289C8_100NS( 3000000 );
	}
	else if( p_sg_info->ch_mode_status[ i ] == NVP6134_VI_4M ) {
	
		NVP6134_SetRegister( pDevice, 0xFF, 0x00 );

		NVP6134_SetRegister( pDevice, 0x81 + (i % 4), (vfmt == NVP6134_STD_PAL) ? 0x0F : 0x0E );

		acp_isp_write( pDevice, i, 0xB101, 0x00 );

		F6B9E557A4BA24ffd926B820B836289C8_100NS( 3000000 );
	}
	else if( p_sg_info->ch_mode_status[ i ] == NVP6134_VI_5M_20P ) {
	
		acp_isp_write( pDevice, i, 0xB101, 0x00 );

		F6B9E557A4BA24ffd926B820B836289C8_100NS( 3000000 );
	}
}

VOID NVP6134_ACP_NRT2RT( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, unsigned char i )
{
	MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(g_pDevice[ pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE ]->m_pCustomSystemConfigProperty);
			
	NVP6134_SIGNAL_INFO * p_sg_info = (NVP6134_SIGNAL_INFO *)(&(p_sys_cfg->m_s_nvp6134_sg_info));
	
	if(	p_sg_info->ch_mode_status[ i ] == NVP6134_VI_3M_NRT ||

		p_sg_info->ch_mode_status[ i ] == NVP6134_VI_4M_NRT ||

		p_sg_info->ch_mode_status[ i ] == NVP6134_VI_5M_NRT ) {

		acp_isp_write( pDevice, i, 0xB100, 0x00 );

		F6B9E557A4BA24ffd926B820B836289C8_100NS( 3000000 );
	}
}
*/

BYTE NVP6134_VIDEO_FMT_DEBOUNCE( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, unsigned char chs, unsigned char value )
{
	BYTE tmp = 0;
	
	BYTE buf[ 3 ] = { 0, 0, 0 };

	BYTE R5C = 0;

	BYTE RF2 = 0;

	BYTE RF3 = 0;

	BYTE RF4 = 0;

	BYTE RF5 = 0;
	
	BYTE j = 0;
	for( j = 0 ; j < 3 ; j++ ) {
	
		NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (chs % 4) );

		tmp = NVP6134_GetRegister( pDevice, 0xF0 );

		RF4 = NVP6134_GetRegister( pDevice, 0xF4 );

		RF5 = NVP6134_GetRegister( pDevice, 0xF5 );
	
		RF2 = 0;

		if( tmp == 0x6F ) { // AHD 3M DETECTION
		
			tmp = NVP6134_GetRegister( pDevice, 0xF3 );

			RF2 = NVP6134_GetRegister( pDevice, 0xF2 );
		}
		else if( (RF5 == 0x06) && ((RF4 == 0x30) || (RF4 == 0x31)) ) {
		
			tmp = 0x64; // EXT 3M @ 18P		
		}
		else if( (RF5 == 0x07) && ((RF4 == 0xD0) || (RF4 == 0xD1)) ) {
		
			tmp = 0xA2; // EXT 5M @ 12.5P
		}
		if( tmp == 0x7F ) { // AHD 5M DETECTION
		
			RF2 = NVP6134_GetRegister( pDevice, 0xF2 );

			RF3 = NVP6134_GetRegister( pDevice, 0xF3 );

			if( RF3 == 0x04 ) {

				tmp = 0xA0; // 5M @ 12.5P
			}
			else if ( RF3 == 0x02 ) {
				
				tmp = 0xA1; // 5M @ 20P
			}
		}
		buf[ j ] = NVP6134_VFMT_CONVERT( tmp, RF2 );
		
		NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (chs % 4) );

		R5C = NVP6134_GetRegister( pDevice, 0x5C );

		if(	(R5C == 0x20) || (R5C == 0x21) || 
			
			(R5C == 0x22) || (R5C == 0x23) || 
			
			(R5C == 0x30) || (R5C == 0x31) ) {
					
			buf[ j ] = NVP6134_VFMT_CONVERT( R5C, RF2 );
		}
		else {

			if( NVP6134_IS_AHD_MODE( buf[ j ] ) ) {
			
				buf[ j ] = NVP6134_TRANS_AHD_TO_CHD( buf[ j ] );
			}
		}
		F6B9E557A4BA24ffd926B820B836289C8_100NS( 400000 );
	}

	tmp = value;

    if( (tmp == buf[ 0 ]) && 
		
		(tmp == buf[ 1 ]) &&
		
		(tmp == buf[ 2 ]) ) {

		return tmp;
	}
	else {

		return buf[ 2 ];
	}
}

VOID NVP6134_FORMAT_DETECTION( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice )
{
	MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(g_pDevice[ pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE ]->m_pCustomSystemConfigProperty);
			
	NVP6134_SIGNAL_INFO * p_sg_info = (NVP6134_SIGNAL_INFO *)(&(p_sys_cfg->m_s_nvp6134_sg_info));
	
	BYTE RF0 = 0; 

	BYTE R5C = 0;

	BYTE RF2 = 0;

	BYTE RF3 = 0;

	BYTE RF4 = 0;

	BYTE RF5 = 0;

	BYTE vfmt = 0x00;

	BYTE i = 0;
	for( i = 0 ; i < 4 ; i++ ) {
	
		MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(g_pDevice[ pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE + i ]->m_pCustomSystemConfigProperty);
			
		F42A18AF66EFF459eA332CA253FFF8A65 * g_p_device = g_pDevice[ pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE + i ];
			
		if( g_p_device->m_pLinkDevice == NULL ) { // 1ST ATTACHED

			CC7AF56407504E059A58F55D48A142C1( pDevice, TRUE, TRUE );
		}
		g_p_device->m_pLinkDevice = pDevice;

		g_p_device->m_nLinkNum = i;

		NVP6134_SetRegister( pDevice, 0xFF, 0x05 + ( i % 4) );

		RF0 = NVP6134_GetRegister( pDevice, 0xF0 );

		RF4 = NVP6134_GetRegister( pDevice, 0xF4 );

		RF5 = NVP6134_GetRegister( pDevice, 0xF5 );

		if( RF0 == 0x6F ) { // AHD 3M DETECTION
		
			RF0 = NVP6134_GetRegister( pDevice, 0xF3 );

			RF2 = NVP6134_GetRegister( pDevice, 0xF2 );
		}
		else if( (RF5 == 0x06) && ((RF4 == 0x30) || (RF4 == 0x31)) ) {
		
			RF0 = 0x64; // EXT 3M @ 18P		
		}
		else if( (RF5 == 0x07) && ((RF4 == 0xD0) || (RF4 == 0xD1)) ) {
		
			RF0 = 0xA2; // EXT 5M @ 12.5P
		}
		if( RF0 == 0x7F ) { // AHD 5M DETECTION
		
			RF2 = NVP6134_GetRegister( pDevice, 0xF2 );

			RF3 = NVP6134_GetRegister( pDevice, 0xF3 );

			if( RF3 == 0x04 ) {

				RF0 = 0xA0; // 5M @ 12.5P
			}
			else if ( RF3 == 0x02 ) {
				
				RF0 = 0xA1; // 5M @ 20P
			}
		}
		vfmt = NVP6134_VFMT_CONVERT( RF0, RF2 );		

		NVP6134_SetRegister( pDevice, 0xFF, 0x05 + (i % 4) );
		
		R5C = NVP6134_GetRegister( pDevice, 0x5C );

		if(	(R5C == 0x20) || (R5C == 0x21) || 
			
			(R5C == 0x22) || (R5C == 0x23) || 
			
			(R5C == 0x30) || (R5C == 0x31) ) {
	
			vfmt = NVP6134_VFMT_CONVERT( R5C, RF2 );
		}
		else {
		
			if( NVP6134_IS_AHD_MODE( vfmt ) ) {

				vfmt = NVP6134_TRANS_AHD_TO_CHD( vfmt );
			}		
		}
		if( p_sg_info->getvideofmt[ i ] != vfmt ) {

			vfmt = NVP6134_VIDEO_FMT_DEBOUNCE( pDevice, i, vfmt );

			p_sg_info->getvideofmt[ i ] = vfmt;
		}

	//	ch_video_fmt[i] = vfmt;
		
		// WHEN DETECTS EXT720P VER-A, SWITCH TO EXT720P VER-B
		//
		#if 1

		if( p_sg_info->getvideofmt[ i ] == 0x31 || 
			
			p_sg_info->getvideofmt[ i ] == 0x32 ) {

			F6B9E557A4BA24ffd926B820B836289C8_100NS( 10000000 );

			NVP6134_SET_CHNMODE( pDevice, i, (((p_sg_info->getvideofmt[ i ] & 0x03) % 2) == 0) ? NVP6134_STD_PAL : NVP6134_STD_NTSC, NVP6134_VI_EXT_720PA );
			
			F6B9E557A4BA24ffd926B820B836289C8_100NS( 1000000 );

		//	nvp6134_coax_command( i, EXT_CMD_VER_SWITCH );

			F6B9E557A4BA24ffd926B820B836289C8_100NS( 1000000 );

			NVP6134_SET_CHNMODE( pDevice, i, (((p_sg_info->getvideofmt[ i ] & 0x03) % 2) == 0) ? NVP6134_STD_PAL : NVP6134_STD_NTSC, NVP6134_VI_1080P_NOVIDEO );

			p_sg_info->getvideofmt[ i ] = 0x00; // EXTA SWITCH TO EXTB
		}
		#endif

		#ifdef _3M_RT2NRT_AUTO_ //MATICALLY SWITCH AHD 3M REALTIME TO NON-REALTIME
		
		if( (vfmt == 0x91) || 
			
			(vfmt == 0x92) ) {
		
			NVP6134_ACP_RT2NRT( pDevice, i, (vfmt & 0x02) / 2 );
		}
		#endif

		#ifdef _3M_NRT2RT_AUTO_ //MATICALLY SWITCH AHD 3M NON-REALTIME TO REALTIME
		
		if( (vfmt == 0x90) ) {

			NVP6134_ACP_NRT2RT( pDevice, i );
		}
		#endif
	}
}
