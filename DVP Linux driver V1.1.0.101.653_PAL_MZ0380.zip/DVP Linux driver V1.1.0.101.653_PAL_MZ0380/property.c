#include "LINUXV4L2.h"
#include "property.h"
#include "tw6805.h"
#include "cx2581.h"
#include "sa7160.h"
#include "sl6010.h"
#include "tw5864.h"
#include "fh8735.h"
#include "mz0380.h"
#include "pl330b.h"

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static LONGLONG xxxxx[ 4 ] = { 0, 0, 0, 0 };

static LONGLONG ooooo[ 4 ] = { 0, 0, 0, 0 };

BOOLEAN update_video_time_stamp( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, F301FA49098CE4d9eB95F22BBD388E837 * pVideo, F170997530C6943659ECE8DEC21301F66 * pVideoBuffer )
{
	//FH8735_SYS_CFG * p_sys_cfg = (FH8735_SYS_CFG *)(pDevice->m_pCustomSystemConfigProperty);

	#ifdef AME_SA7160

	SA7160_SYS_CFG * p_sys_cfg = (SA7160_SYS_CFG *)(pDevice->m_pCustomSystemConfigProperty);
	
	#endif

	#ifdef AME_FH8735

	FH8735_SYS_CFG * p_sys_cfg = (FH8735_SYS_CFG *)(pDevice->m_pCustomSystemConfigProperty);
	
	#endif

	#ifdef AME_MZ0380

	MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(pDevice->m_pCustomSystemConfigProperty);
	
	#endif

	#if defined(AME_PL330B) || defined(AME_PL330A)
	
	PL330B_SYS_CFG * p_sys_cfg = (PL330B_SYS_CFG *)(pDevice->m_pCustomSystemConfigProperty);
	
	#endif


		LONGLONG o_ts = pVideo->m_nLastReferenceClockTime; // �W���u��ɶ�

		//LONGLONG e_ts = pDevice->m_pKsMasterReferenceClock->GetTime(); // �����u��ɶ� //100ns
		LONGLONG e_ts = pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_sec * 10000000 + pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_usec * 10; // �����u��ɶ�
		
		#ifdef Medxchange
		//drawback 66ms
		//e_ts -= 660000;
		#endif

		LONGLONG d_ts  = e_ts - o_ts;

		ULONG base_fps = 0;

		LONGLONG input_fps = 0;

		BOOL     is_1st = FALSE;

		ULONG    m = p_sys_cfg->n_input_video_resolution_fps_m;

		if( d_ts >= ( 166666 - 10000) && d_ts <= ( 166666 + 10000) && m == 0 ) { base_fps = 60000; } // 60.000FPS (166666)

		if( d_ts >= ( 166833 - 10000) && d_ts <= ( 166833 + 10000) && m == 1 ) { base_fps = 59940; } // 59.940FPS (166833)

		if( d_ts >= ( 200000 - 10000) && d_ts <= ( 200000 +  4167) && m == 0 ) { base_fps = 50000; } // 50.000FPS (200000)
		
		if( d_ts >= ( 208333 -  4166) && d_ts <= ( 208333 + 10000) && m == 0 ) { base_fps = 48000; } // 48.000FPS (208333)

		if( d_ts >= ( 208542 - 10000) && d_ts <= ( 208542 + 10000) && m == 1 ) { base_fps = 47952; } // 47.952FPS (208542)

		if( d_ts >= ( 333333 - 10000) && d_ts <= ( 333333 + 10000) && m == 0 ) { base_fps = 30000; } // 30.000FPS (333333)

		if( d_ts >= ( 333667 - 10000) && d_ts <= ( 333667 + 10000) && m == 1 ) { base_fps = 29970; } // 29.970FPS (333667)

		if( d_ts >= ( 400000 - 10000) && d_ts <= ( 400000 +  8333) && m == 0 ) { base_fps = 25000; } // 25.000FPS (400000)

		if( d_ts >= ( 416666 -  8333) && d_ts <= ( 416666 + 10000) && m == 0 ) { base_fps = 24000; } // 24.000FPS (416666)

		if( d_ts >= ( 417083 - 10000) && d_ts <= ( 417083 + 10000) && m == 1 ) { base_fps = 23976; } // 23.976FPS (417083)

		if( d_ts >= ( 500000 - 10000) && d_ts <= ( 500000 + 10000) && m == 0 ) { base_fps = 20000; } // 20.000FPS (500000)

		if( d_ts >= ( 500500 - 10000) && d_ts <= ( 500500 + 10000) && m == 1 ) { base_fps = 19980; } // 19.980FPS (500500)

		if( d_ts >= ( 600000 - 10000) && d_ts <= ( 600000 + 10000) && m == 0 ) { base_fps = 16666; } // 16.666FPS (600000)

		if( d_ts >= ( 666666 - 10000) && d_ts <= ( 666666 + 10000) && m == 0 ) { base_fps = 15000; } // 15.000FPS (666666)

		if( d_ts >= ( 667557 - 10000) && d_ts <= ( 667557 + 10000) && m == 1 ) { base_fps = 14985; } // 14.980FPS (667557)

		if( d_ts >= ( 800000 - 10000) && d_ts <= ( 800000 + 10000) && m == 0 ) { base_fps = 12500; } // 12.500FPS (800000)

		if( d_ts >= (1333333 - 10000) && d_ts <= (1333333 + 10000) && m == 0 ) { base_fps =  7500; } // 7.500FPS (1333333)

		if( d_ts >= (1334668 - 10000) && d_ts <= (1334668 + 10000) && m == 1 ) { base_fps =  7492; } // 7.492FPS (1334668)

		if( d_ts >= (1600000 - 10000) && d_ts <= (1600000 + 10000) && m == 0 ) { base_fps =  6250; } // 6.250FPS (1600000)

		{	if( pDevice->m_nCustomAnalogVideoInterleavedProperty == 1 ) {

				//input_fps = (pDevice->m_nCustomAnalogVideoFrameRateProperty / 2) * 1000;
				//temporary use, must fine tune
				//already down
				if( pVideo->F03DD48A54B1D4ffeB64170AA03AEFC6E == 0x00000001 )
				{
					input_fps = (pDevice->m_nCustomAnalogVideoAvgFrameRateProperty[ 0 ] / 1) * 1000;
				}
				else
				{
					input_fps = (pDevice->m_nCustomEncoderVideoAvgFrameRateProperty[ 0 ] / 1) * 1000;
				}
			}
			else {

				//input_fps = (pDevice->m_nCustomAnalogVideoFrameRateProperty / 1) * 1000;
	
				if( pVideo->F03DD48A54B1D4ffeB64170AA03AEFC6E == 0x00000001 )
				{
					input_fps = (pDevice->m_nCustomAnalogVideoAvgFrameRateProperty[ 0 ] / 1) * 1000;
				}
				else
				{
					input_fps = (pDevice->m_nCustomEncoderVideoAvgFrameRateProperty[ 0 ] / 1) * 1000;
				}
			}
			if( p_sys_cfg->n_output_video_resolution_fps_1_2 == 1 ) {

				input_fps >>= 1;
			}
			if( input_fps > 0 ) {

				if( base_fps > input_fps ) {

					base_fps = 0;
				}
			}
		}
		if( base_fps != 0 ) {

			if( pVideo->m_nLastPresentationTimeFps == 0 ) {

				pVideo->m_nLastPresentationTimeFps = base_fps;

				pVideo->m_nLastPresentationTimeFpsCounts = 1;
			}
			else if( pVideo->m_nLastPresentationTimeFps != base_fps ) {
				
				if( pVideo->m_nLastPresentationTimeFpsCounts == 1 ) {

					pVideo->m_nLastPresentationTimeFps = base_fps;

					pVideo->m_nLastPresentationTimeFpsCounts = 1;
				}
				else {

					base_fps = pVideo->m_nLastPresentationTimeFps;

					if( pVideo->m_nLastPresentationTimeFpsCounts > 1 ) {

						pVideo->m_nLastPresentationTimeFpsCounts--;
					}
				}
			}
			else {

				if( pVideo->m_nLastPresentationTimeFpsCounts < 5 ) {

					pVideo->m_nLastPresentationTimeFpsCounts++;
				}
			}
		}
		if( base_fps == 0 && 
			
			pVideo->m_nLastPresentationTimeFpsCounts >= 2 ) {

			base_fps = pVideo->m_nLastPresentationTimeFps;

			if( base_fps != 0 ) {

				if( pVideo->m_nLastPresentationTimeFpsCounts < 5 ) {

					pVideo->m_nLastPresentationTimeFpsCounts++;
				}
			}
		}	
		if( base_fps == 0 ) {

			if( pDevice->m_nCustomAnalogVideoInterleavedProperty == 1 ) {

				//base_fps = (pDevice->m_nCustomAnalogVideoFrameRateProperty / 2) * 1000;

				//already down
				if( pVideo->F03DD48A54B1D4ffeB64170AA03AEFC6E == 0x00000001 )
				{
					base_fps = (pDevice->m_nCustomAnalogVideoAvgFrameRateProperty[ 0 ] / 1) * 1000;
				}
				else
				{
					base_fps = (pDevice->m_nCustomEncoderVideoAvgFrameRateProperty[ 0 ] / 1) * 1000;
				}
			}
			else {

				//base_fps = (pDevice->m_nCustomAnalogVideoFrameRateProperty / 1) * 1000;
				//base_fps = (pDevice->m_nCustomAnalogVideoAvgFrameRateProperty[ 0 ] / 1) * 1000;
				if( pVideo->F03DD48A54B1D4ffeB64170AA03AEFC6E == 0x00000001 )
				{
					base_fps = (pDevice->m_nCustomAnalogVideoAvgFrameRateProperty[ 0 ] / 1) * 1000;
				}
				else
				{
					base_fps = (pDevice->m_nCustomEncoderVideoAvgFrameRateProperty[ 0 ] / 1) * 1000;
				}
			}
			if( p_sys_cfg->n_output_video_resolution_fps_1_2 == 1 ) {

				base_fps >>= 1;
			}
			if( m == 1 ) {

				base_fps *= 1000;

				//base_fps /= 1001;
				LONGLONG base_fps_temp = base_fps;
				do_div(base_fps_temp, 1001);
				base_fps = base_fps_temp;
			}
		}
		if( base_fps == 0 ) {

			if( pDevice->FD314ADAD9404496b842EBFC396E875CB & SUPPORTED_ANALOG_VIDEO_STANDARDS_60HZ ) {

				if( pDevice->m_nCustomAnalogVideoInterleavedProperty == 1 ) {

					base_fps = 30000;
				}
				else {
					
					base_fps = 60000;
				}
			}
			else {

				if( pDevice->m_nCustomAnalogVideoInterleavedProperty == 1 ) {

					base_fps = 25000;
				}
				else {
					
					base_fps = 50000;
				}
			}
			if( p_sys_cfg->n_output_video_resolution_fps_1_2 == 1 ) {

				base_fps >>= 1;
			}
			if( m == 1 ) {

				base_fps *= 1000;

				//base_fps /= 1001; 
				LONGLONG base_fps_temp = base_fps;
				do_div(base_fps_temp, 1001);
				base_fps = base_fps_temp;
			}
		}

#ifdef FH8735_DEBUG_TIMESTAMP

//		if( TRUE ) {
//
//			static LONGLONG old = 0;
//
//			AMEBDAD_PRINT( ("%lld %lld (%lld) (%lld) (%lld) (%lld)\n", old, e_ts, e_ts - old, base_fps, pDevice->m_nLastPresentationTimeFps, pDevice->m_nLastPresentationTimeFpsCounts) );
//
//			old = e_ts;
//		}
#endif
		//LONGLONG base = 10000000000 / base_fps; // ��Ʀ�

		//LONGLONG FF7E121E5F6A1461dA967001C1404EB52 = (1000000000000000000 / base_fps) - (base * 100000000); // �p���I��
		
		//get time period(100ns) per frame

		LONGLONG a_temp = 10000000000;
		LONGLONG b_temp = 1000000000000000000;
		
		do_div(a_temp, base_fps);

		LONGLONG base = a_temp;
		
		do_div( b_temp, base_fps);

		LONGLONG FF7E121E5F6A1461dA967001C1404EB52 = b_temp - (base * 100000000); // �p���I��

		d_ts = base;

		if( o_ts == 0 ) { // �Ĥ@��

			F966EAAB748564259849CBD3F3D6C48A7( KERN_INFO, "[%02d] o_ts == 0\n", (int)(pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE));

			o_ts = e_ts; 

			d_ts = 0;
		
			FF7E121E5F6A1461dA967001C1404EB52 = 0;

			is_1st = TRUE;

			pVideo->m_nLastPresentationTime = e_ts;

			pVideo->m_nLastPresentationTimeMultipler = 0;
		}
		else {

			pVideo->m_nLastPresentationTimeMultipler += (LONG)(FF7E121E5F6A1461dA967001C1404EB52);

			if( pVideo->m_nLastPresentationTimeMultipler >= 100000000 ) {

				pVideo->m_nLastPresentationTimeMultipler -= 100000000;

				d_ts += 1;
			}
		}
		//pDevice->PresentationTime.Time = pDevice->m_nLastPresentationTime + d_ts; // �p��X�z�Q��

		pVideo->m_nNowPresentationTime = pVideo->m_nLastPresentationTime + d_ts; // �p��X�z�Q��

		//pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_sec = (pVideo->m_nNowPresentationTime) / 10000000;
		//pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_usec = (pVideo->m_nNowPresentationTime) % 10000000;
		
		LONGLONG m_nNowPresentationTime_temp = pVideo->m_nNowPresentationTime;
		pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_usec = do_div(m_nNowPresentationTime_temp, 10000000);
		pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_sec = m_nNowPresentationTime_temp;
		
		pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_usec /= 10;
		
		//LONGLONG d_o = (pDevice->PresentationTime.Time > e_ts) ?
		//
		//			   (pDevice->PresentationTime.Time - e_ts) :
		//
		//			   (e_ts - pDevice->PresentationTime.Time); // �p��X�~�t��
		
		LONGLONG d_o = (pVideo->m_nNowPresentationTime > e_ts) ?
		
					   (pVideo->m_nNowPresentationTime - e_ts) :
		
					   (e_ts - pVideo->m_nNowPresentationTime); // �p��X�~�t��


		if( d_o > (base >> 1) ) { // �~�t�W�L 1 MS, �n�ե� half frame

			if( pVideo->m_nLastPresentationTimeFpsErrors >= 100 ||
				
				d_o > 1000000 ) {

				pVideo->m_nLastPresentationTimeFpsErrors = 0;	

#ifdef FH8735_DEBUG_TIMESTAMP
//this will slow down system				

				//F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "TS.DEBUG.VIDEO.%d( RESET#1, d_o = %lld, last.ts = %lld, calc.ts = %lld, e_ts = %lld, errors = %lld )", 0, d_o, pDevice->m_nLastPresentationTime, pDevice->PresentationTime.Time, e_ts, pDevice->m_nLastPresentationTimeFpsErrors);
				//F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "TS.DEBUG.VIDEO.%d( RESET#1, d_o = %lld, last.ts = %lld, calc.ts = %lld, e_ts = %lld, errors = %lld )\n", 0, d_o, pVideo->m_nLastPresentationTime, pVideo->m_nNowPresentationTime, e_ts, pVideo->m_nLastPresentationTimeFpsErrors);
				
				//F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "TS.DEBUG.H264( RESET#1, d_o = %lld, last.ts = %lld, calc.ts = %lld, e_ts = %lld )", d_o, pVideo->m_nLastPresentationTime, pVideo->m_nNowPresentationTime, e_ts);
				//pDevice->m_nDebugOn = 1;

				if( pVideo->F03DD48A54B1D4ffeB64170AA03AEFC6E == 0x00000001 )
				{
					F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] TS.DEBUG.PREWIEW( RESET#1, d_o = %lld) (100ns)", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, d_o);
				}
				else
				{
					F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] TS.DEBUG.H264( RESET#1, d_o = %lld) (100ns)", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, d_o);
				}

#endif
				//pDevice->PresentationTime.Time = e_ts;
				//pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_sec = (e_ts) / 10000000;
				//pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_usec = (e_ts) % 10000000;
				LONGLONG e_ts_temp = e_ts;
				pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_usec = do_div(e_ts_temp, 10000000);
				pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_sec = (e_ts_temp);
				
				pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_usec /= 10;

				pVideo->m_nLastPresentationTimeMultipler = 0;
			}
			else {

				pVideo->m_nLastPresentationTimeFpsErrors++;
			}
		}
		else {

			pVideo->m_nLastPresentationTimeFpsErrors = 0;
		}
		/*		
		if( pDevice->m_nAnalogVideoDecoderStatusProperty == 0 ) {

			//pVideo->PresentationTime.Time = e_ts;
			//pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_sec = (e_ts) / 10000000;
			//pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_usec = (e_ts) % 10000000;

			LONGLONG e_ts_temp = e_ts;
			pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_usec = do_div(e_ts_temp, 10000000);
			pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_sec = (e_ts_temp);
			
			pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_usec /= 10;

			pVideo->m_nLastPresentationTimeMultipler = 0;

			pVideo->m_nLastPresentationTimeFpsErrors = 0;
		}
		*/

		//if( pDevice->PresentationTime.Time <= pDevice->m_nLastPresentationTime &&
		if( ( (pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_sec * 10000000) + (pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_usec * 10) ) <= pVideo->m_nLastPresentationTime &&
			
			is_1st == FALSE ) {

#ifdef FH8735_DEBUG_TIMESTAMP

			//F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "TS.DEBUG.VIDEO.%d( RESET#2, last.ts = %lld, calc.ts = %lld )\n", 0, pVideo->m_nLastPresentationTime, pVideo->m_nNowPresentationTime);
			if( pVideo->F03DD48A54B1D4ffeB64170AA03AEFC6E == 0x00000001 )
			{
				F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] TS.DEBUG.PREVIEW( RESET#2, last.ts = %lld, calc.ts = %lld )", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, pVideo->m_nLastPresentationTime, e_ts);
			}
			else
			{
				F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] TS.DEBUG.H264( RESET#2, last.ts = %lld, calc.ts = %lld )", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, pVideo->m_nLastPresentationTime, e_ts);
			}
#endif
			if( e_ts > pVideo->m_nLastPresentationTime ) {

				//pDevice->PresentationTime.Time = e_ts;
				//pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_sec = (e_ts) / 10000000;
				//pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_usec = (e_ts) % 10000000;
				
				LONGLONG e_ts_temp = e_ts;
				pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_usec = do_div(e_ts_temp, 10000000);
				pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_sec = (e_ts_temp);
				pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_usec /= 10;
			}
			else {

				//pDevice->PresentationTime.Time = pDevice->m_nLastPresentationTime + 10000;
				//pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_sec = (pVideo->m_nLastPresentationTime + 10000) / 10000000;
				//pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_usec = (pVideo->m_nLastPresentationTime + 10000) % 10000000;
				
				LONGLONG m_nLastPresentationTime_temp = pVideo->m_nLastPresentationTime + 10000;
				pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_usec = do_div(m_nLastPresentationTime_temp, 10000000);
				pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_sec = (m_nLastPresentationTime_temp);

				pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_usec /= 10;
			}
			pVideo->m_nLastPresentationTimeMultipler = 0;

			pVideo->m_nLastPresentationTimeFpsErrors = 0;
		}
		//pDevice->m_nLastPresentationTime = pDevice->PresentationTime.Time;
		pVideo->m_nLastPresentationTime = pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_sec * 10000000 + pVideoBuffer->F6A821C5E7AA043f999FB3C51DB94DD2B.ts.tv_usec * 10;

		pVideo->m_nLastReferenceClockTime = e_ts;

		//pDevice->Duration = 10000000000 / base_fps;

#ifdef FH8735_DEBUG_TIMESTAMP

		if( is_1st ) {

			ooooo[ 0 ] = e_ts;

			xxxxx[ 0 ] = 0;
		}
		if( (xxxxx[ 0 ]++ % 500) == 0 ) {

			LONGLONG ttttt = e_ts - ooooo[ 0 ];

			ttttt /= xxxxx[ 0 ];

			F966EAAB748564259849CBD3F3D6C48A7( KERN_INFO, "video.%d %lld | (%lld) (%lld) (%lld) (%lld) | ----> (%lld) | (m = %d)\n", 0,
				
				(pVideo->m_nNowPresentationTime), // �p��ɶ�
				
				(xxxxx[ 0 ] * 10000000000) / base_fps,  // �z�Q�ɶ�
				
				(e_ts),  // ��ڮɶ�
				
				(pVideo->m_nNowPresentationTime - ((xxxxx[ 0 ] * 10000000000) / base_fps)), // �z�Q�~�t
				
				(pVideo->m_nNowPresentationTime - e_ts), // ��ڻ~�t
				
				//(pDevice->Duration),
				
				ttttt, 
				
				m  );
		}
#endif

	return TRUE;
}
