#ifndef PROPERTY_H
#define PROPERTY_H

extern UINT FADD02C9C13B14f83989880EFACB8D8DC                    [ 64 ][ 4 ];

extern UINT F3A66BD0F0BCB4afcAD006E378E671B9A                      [ 64 ][ 4 ];

extern UINT F925442591E22492f9239C6028CE3DD94                    [ 64 ][ 4 ];

extern UINT F42BAA55A84E847faA4D0C0565699845E                           [ 64 ][ 4 ];

extern UINT F1D56E1ED762E4b99BB2BD370DFE317D1                     [ 64 ][ 4 ];

extern UINT FF41F97A51B484aaa8170BEE8828CFCF0                     [ 64 ];

extern UINT F9CA17C2FDE5B4c94B2594B65842E7387                          [ 64 ];

extern UINT FC9D92723A8E44565883875F77CA4E561                   [ 64 ];


extern UINT F5DCAF3AAB0BA4f659145B0B8C7EB74F6                    [ 64 ];

extern UINT F24FF8C85BBB142d68BD24A8AEE14C2A0                   [ 64 ];

extern UINT F9245F416BCD64da6857AA7F60AC69BDC                   [ 64 ];

extern UINT FB5061B6847674d5cAA4512F2524B22CA [ 64 ];

extern UINT FB4585649D2BE488f8DAB3BE4ACEC1C0C[ 64 ];


extern UINT FCF4231953179448dA85C9CE2854BDAB0							  [ 64 ];

extern UINT FAB3E37A5903246ce815D399EE1B19200							  [ 64 ];

extern UINT F9C0567FC340549ddAF206705D1028554							  [ 64 ];

extern CHAR  FE2D83A80F4E94ef188507C175ABF3840 							  [ 64 ][ 64 + 1 ];


extern UINT g_n_gpio_direction                               [ 64 ];

extern UINT g_n_gpio_data                                    [ 64 ];

BOOLEAN update_video_time_stamp( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, F301FA49098CE4d9eB95F22BBD388E837 * pVideo, F170997530C6943659ECE8DEC21301F66 * pVideoBuffer );

//below is from kernel 3.2


#endif

