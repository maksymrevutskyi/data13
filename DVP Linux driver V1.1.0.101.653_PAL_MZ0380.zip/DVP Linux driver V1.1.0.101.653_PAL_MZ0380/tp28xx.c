#include "LINUXV4L2.h"
#include "tp2834.h"
#include "mz0380.h"

extern F42A18AF66EFF459eA332CA253FFF8A65 * g_pDevice[ 128 ];

static const unsigned char TP2834_CLK_ADDR[ 4 ] = { 0xFA, 0xFA, 0xFB, 0xFB }; // { CH.01, CH.02, CH.03, CH.04 }
static const unsigned char TP2834_CLK_AND [ 4 ] = { 0xF8, 0x8F, 0xF8, 0x8F };
static const unsigned char TP2834_CLK_MODE[ 4 ] = { 0x01, 0x10, 0x01, 0x10 };

static const unsigned char TP2834_SYS_MODE[ 5 ] = { 0x01, 0x02, 0x04, 0x08, 0x0F }; // { CH.01, CH.02, CH.03, CH.04, CH.ALL }
static const unsigned char TP2834_SYS_AND [ 5 ] = { 0xFE, 0xFD, 0xFB, 0xF7, 0xF0 };

unsigned char TP2834_TBL_6M10_RASTER   [ ] = { 0x13, 0xEC, 0x80, 0xB0, 0x08, 0x7C, 0x00, 0x0E, 0xA6 }; // 6M@10

unsigned char TP2834_TBL_5M_RASTER     [ ] = { 0x13, 0x1F, 0x20, 0x34, 0x98, 0x7A, 0x00, 0x0B, 0x9A };

unsigned char TP2834_TBL_QHD30_RASTER  [ ] = { 0x23, 0x1D, 0x04, 0x38, 0xA0, 0x5A, 0x00, 0x0C, 0xE2 }; // 2560 (A00) X 1440 (5A0) @30

unsigned char TP2834_TBL_QHD25_RASTER  [ ] = { 0x23, 0x1d, 0x04, 0x38, 0xa0, 0x5a, 0x00, 0x0f, 0x76 }; // 2560 (A00) X 1440 (5A0) @25

unsigned char TP2834_TBL_QHD15_RASTER  [ ] = { 0x13, 0x0F, 0x00, 0x32, 0xA0, 0x5A, 0x00, 0x0C, 0xE4 }; // 2560 (A00) X 1440 (5A0) @15

unsigned char TP2834_TBL_4M30_RASTER   [ ] = { 0x13, 0x0F, 0x00, 0x32, 0xA0, 0x55, 0x00, 0x06, 0x72 }; // 4M@30

unsigned char TP2834_TBL_4M25_RASTER   [ ] = { 0x13, 0x20, 0x00, 0x20, 0xA0, 0x55, 0x00, 0x07, 0xBC }; // 4M@25

unsigned char TP2834_TBL_4M_RASTER     [ ] = { 0x13, 0x1F, 0x80, 0x7D, 0xF0, 0x5A, 0x00, 0x0B, 0xB8 }; // 4M@15

unsigned char TP2834_TBL_4M12_RASTER   [ ] = { 0x23, 0x34, 0x80, 0x8C, 0xF0, 0x5A, 0x00, 0x0C, 0xE4 }; // 4M@12

unsigned char TP2834_TBL_3M_RASTER     [ ] = { 0x13, 0x6C, 0x00, 0x2C, 0x00, 0x68, 0x00, 0x09, 0xC4 }; // 2048 (800) X 1536 (600)

unsigned char TP2834_TBL_3M20_RASTER   [ ] = { 0x03, 0xA0, 0x00, 0x6E, 0x00, 0x68, 0x00, 0x08, 0xCA }; // 2048 (800) X 1536 (600) @20P

unsigned char TP2834_TBL_1080P30_RASTER[ ] = { 0x03, 0xD3, 0x80, 0x29, 0x38, 0x47, 0x00, 0x08, 0x98 }; // 1920 (780) X 1080 (438) @30P

unsigned char TP2834_TBL_1080P25_RASTER[ ] = { 0x03, 0xD3, 0x80, 0x29, 0x38, 0x47, 0x00, 0x0A, 0x50 }; // 1920 (780) X 1080 (438) @25P

unsigned char TP2834_TBL_720P60_RASTER [ ] = { 0x13, 0x16, 0x00, 0x19, 0xD0, 0x25, 0x00, 0x06, 0x72 }; // 1280 (500) X  720 (2D0) @60P

unsigned char TP2834_TBL_720P50_RASTER [ ] = { 0x13, 0x16, 0x00, 0x19, 0xD0, 0x25, 0x00, 0x07, 0xBC }; // 1280 (500) X  720 (2D0) @50P

unsigned char TP2834_TBL_720P30_RASTER [ ] = { 0x13, 0x16, 0x00, 0x19, 0xD0, 0x25, 0x00, 0x0C, 0xE4 }; // 1280 (500) X  720 (2D0) @30P

unsigned char TP2834_TBL_720P25_RASTER [ ] = { 0x13, 0x16, 0x00, 0x19, 0xD0, 0x25, 0x00, 0x0F, 0x78 }; // 1280 (500) X  720 (2D0) @25P

#if 0

unsigned char TP2834_TBL_NTSC_RASTER   [ ] = { 0x13, 0x4E, 0xBC, 0x15, 0xF0, 0x07, 0x00, 0x09, 0x38 }; // 1980 (7BC) X  240 (0F0) @60I

unsigned char TP2834_TBL_PAL_RASTER    [ ] = { 0x13, 0x5F, 0xBC, 0x17, 0x20, 0x17, 0x00, 0x09, 0x48 }; // 1980 (7BC) X  288 (120) @50I

#else

unsigned char TP2834_TBL_NTSC_RASTER   [ ] = { 0x13, 0x3E, (0xC0 - 0x10), 0x12, 0xF0, 0x07, 0x00, 0x09, 0x38 }; // 1984 - 16 (780) X  240 (0F0) @60I

unsigned char TP2834_TBL_PAL_RASTER    [ ] = { 0x13, 0x5E, (0xC0 - 0x30), 0x16, 0x20, 0x17, 0x00, 0x09, 0x48 }; // 1984 - 48 (780) X  288 (120) @50I

#endif

BYTE E337333B92284BE3A3A414AA44ED9827( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, BYTE nIndex )
{
	#ifdef AME_MZ0380

		return E6FB1249C1F642A38BC0228741149CD8( pDevice, 0, 0x88, nIndex );

	#endif

	return 0x00;
}

BOOL E2AC4F78FF95428CA3FD05CF4E898465( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, BYTE nIndex, BYTE nValue )
{
	#ifdef AME_MZ0380

		return DBF051EEA3B648B49859145F02FA268C( pDevice, 0, 0x88, nIndex, nValue );

	#endif

	return TRUE;
}

BOOL E2AC4F78FF95428CA3FD05CF4E898465s( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, BYTE nIndex, BYTE * pValues, ULONG nSize )
{
	BOOL returns = TRUE;

	#ifdef AME_MZ0380
	BYTE i = 0;
	for( i = 0 ; i < nSize ; i++ ) {

		returns = DBF051EEA3B648B49859145F02FA268C( pDevice, 0, 0x88, nIndex + i, pValues[ i ] );

		if( returns == FALSE ) {

			break;
		}
	}
	#endif

	return returns;
}

VOID TP28XX_SET_REG_PAGE( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, BYTE chs ) // [HUENGPEI] [2018.01.30.V73.FULL] -----> tp2802_set_reg_page
{
	switch( chs ) {

	case TP2834_REG_PAGE_VIN_01:  E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x00 ); break; // VIN.1

	case TP2834_REG_PAGE_VIN_02:  E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x01 ); break; // VIN.2

	case TP2834_REG_PAGE_VIN_03:  E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x02 ); break; // VIN.3

	case TP2834_REG_PAGE_VIN_04:  E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x03 ); break; // VIN.4

	case TP2834_REG_PAGE_VIN_ALL: E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x04 ); break; // VIN.ALL

	case TP2834_REG_PAGE_AIN:     E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x40 ); break; // AIN

	case TP2834_REG_PAGE_DATA:    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x10 ); break; // DATA ( PTZ )

	default:                      E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x04 ); break; // VIN.ALL
	}
}

VOID TP28XX_RESET_DEFAULT( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, ULONG i ) // [HUENGPEI] [2018.01.30.V73.FULL]
{
	MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(pDevice->m_pCustomSystemConfigProperty);
	
	if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ||  // PRODUCT_TP2826C
		
		p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { // PRODUCT_TP2827C

		return TP2827C_RESET_DEFAULT( pDevice, i );
	}
	else if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826 ||  // PRODUCT_TP2826
		
			 p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827 ) { // PRODUCT_TP2827

		return TP2826_RESET_DEFAULT( pDevice, i );
	}
	else { // PRODUCT_TP2834
		
		return TP2834_RESET_DEFAULT( pDevice, i );
	}
}

VOID TP28XX_CHANNELID( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice ) // [HUENGPEI] [2018.01.30.V73.FULL]
{
	// SDR_1CH
	//
	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x00 );
	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x34, 0x10 );
	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x01 );
	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x34, 0x11 );
	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x02 );
	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x34, 0x10 );
	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x03 );
	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x34, 0x11 );
}

VOID TP28XX_MANUAL_AGC( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, ULONG chs ) // [HUENGPEI] [2018.01.30.V73.FULL] -----> tp2802_manual_agc
{
	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x2F, 0x02 );

	ULONG agc = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x04 );

	agc +=  E337333B92284BE3A3A414AA44ED9827( pDevice, 0x04 );

	agc +=  E337333B92284BE3A3A414AA44ED9827( pDevice, 0x04 );

	agc +=  E337333B92284BE3A3A414AA44ED9827( pDevice, 0x04 );

	agc &=  0x03F0;

	agc >>= 1;

	if( agc > 0x01FF ) { agc = 0x01FF; }
		
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: AGC = %d (START)\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, agc);
	
	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x08, (BYTE)(agc & 0xFF) );

	ULONG tmp = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x06 );

    tmp &= 0xF9;

    tmp |= (agc >> 7) & (0x02);

    tmp |= 0x04;

	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x06, (BYTE)(tmp) );
}

VOID TP28XX_EGAIN( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, ULONG chs, ULONG CGAIN_STD ) // [HUENGPEI] [2018.01.30.V73.FULL] -----> tp283x_egain
{
    unsigned int tmp;

    unsigned int retry = 30;

	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x2F, 0x06 );

	ULONG cgain = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x04 );

	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: CGAIN = %d (START)\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, cgain);
	
    if( cgain < CGAIN_STD ) {

        while( retry ) {

            retry--;

			tmp =  E337333B92284BE3A3A414AA44ED9827( pDevice, 0x07 );

            tmp &= 0x3F;

			ULONG diff = (CGAIN_STD > cgain) ? (CGAIN_STD - cgain) :(cgain - CGAIN_STD);

            while( diff ) {

                if( tmp ) {
				
					tmp--;
				}
                else {
				
					break;
				}
                cgain++;

				diff = (CGAIN_STD > cgain) ? (CGAIN_STD - cgain) :(cgain - CGAIN_STD);
            }
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x07, 0x80 | tmp );

            if( 0 == tmp ) {
			
				break;
			}
			F6B9E557A4BA24ffd926B820B836289C8_100NS( 400000 );

			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x2F, 0x06 );

			cgain = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x04 );

			F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: CGAIN = %d (START)\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, cgain);

            if( cgain > (CGAIN_STD + 1) ) {

				tmp =  E337333B92284BE3A3A414AA44ED9827( pDevice, 0x07 );

				tmp &= 0x3F;

				tmp += 0x02;

                if( tmp > 0x3F ) { 
				
					tmp = 0x3F;
				}
				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x07, 0x80 | tmp );

                if( 0x3F == tmp ) {
				
					break;
				}
                F6B9E557A4BA24ffd926B820B836289C8_100NS( 400000 );

                cgain = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x04 );
            }
			diff = (CGAIN_STD > cgain) ? (CGAIN_STD - cgain) :(cgain - CGAIN_STD);

            if( diff < 2 ) { 
			
				break; 
			}
        }
    }
}

BYTE TP28XX_READ_EGAIN( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice ) // [HUENGPEI] [2018.01.30.V73.FULL] -----> tp28xx_read_egain
{
	BYTE gain = 0x00;

	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x2F, 0x00 );

	gain = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x04 );

	return gain;
}

VOID DA74E1188CA14BBDBC150CE97DAB3620( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice ) // [HUENGPEI] [2018.01.30.V73.FULL] -----> tp2802_comm_init
{	
	MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(pDevice->m_pCustomSystemConfigProperty);

	// TP2802_MODULE_INIT
	//
	{	// PAGE RESET
		// 
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x00 );

		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x4D, 0x00 );

		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x4E, 0x00 );

        // PLL RESET
		//
        BYTE R44 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x44 );

        E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x44, R44 | 0x40 );

        F6B9E557A4BA24ffd926B820B836289C8_100NS( 100000 );

        E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x44, R44 );

		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ||
			
			p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ||
			
			p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ||
			
			p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) {

			// TP2816_PLL_RESET
			//
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x45, 0xC9 );

			ULONG i = 0;
			for( i = 0 ; i < 6; i++ ) {
			
				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x44, 0x47 );

				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x42, 0x0C );

				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x44, 0x07 );

				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x42, 0x00 );

				F6B9E557A4BA24ffd926B820B836289C8_100NS( 10000 );

				BYTE R01 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x01 );

				if( R01 != 0x08 ) {
					
					break;
				}
			}
		}
	}
		
	// TP2802_COMM_INIT
	//
	if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ||  // PRODUCT_TP2826C
		
		p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { // PRODUCT_TP2827C

		TP28XX_SET_REG_PAGE( pDevice, TP2834_REG_PAGE_VIN_ALL );

	//	TP2827C_RESET_DEFAULT( pDevice, TP2834_REG_PAGE_VIN_ALL );
		
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { // PRODUCT_TP2826C

			TP2826C_OUTPUT( pDevice, TP2834_1080P25 ); // MUX OUTPUT, DEFAULT = TP2834_1080P25
		}
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { // PRODUCT_TP2827C

			TP2827C_OUTPUT( pDevice, TP2834_1080P25 ); // MUX OUTPUT, DEFAULT = TP2834_1080P25
		}
        E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x02, 0xC8 ); // BT1120/BT656 

		if( pDevice->m_nCustomAnalogVideoPinTopologyProperty == 0 ) { TP2834_SET_VIDEO_MODE( pDevice, TP2834_1080P25, TP2834_REG_PAGE_VIN_ALL, TP2834_STD_TVI ); }

		if( pDevice->m_nCustomAnalogVideoPinTopologyProperty == 1 ) { TP2834_SET_VIDEO_MODE( pDevice, TP2834_1080P25, TP2834_REG_PAGE_VIN_ALL, TP2834_STD_HDA ); }

		if( pDevice->m_nCustomAnalogVideoPinTopologyProperty == 2 ) { TP2834_SET_VIDEO_MODE( pDevice, TP2834_1080P25, TP2834_REG_PAGE_VIN_ALL, TP2834_STD_HDC ); }

		if( pDevice->m_nCustomAnalogVideoPinTopologyProperty >= 3 ) { TP2834_SET_VIDEO_MODE( pDevice, TP2834_1080P25, TP2834_REG_PAGE_VIN_ALL, TP2834_STD_TVI ); }

        TP2827C_PTZ_INIT( pDevice, TP2834_PTZ_RX_ACP1 );

        TP28XX_CHANNELID( pDevice );

	//	TP2834_AUDIO_DATASET( pDevice );
	}		
	else if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826 ||  // PRODUCT_TP2826
		
			 p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827 ) { // PRODUCT_TP2827

		TP28XX_SET_REG_PAGE( pDevice, TP2834_REG_PAGE_VIN_ALL );

		TP2826_RESET_DEFAULT( pDevice, TP2834_REG_PAGE_VIN_ALL );
		
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826 ) { // PRODUCT_TP2826

			TP2826_OUTPUT( pDevice, TP2834_1080P25 ); // MUX OUTPUT, DEFAULT = TP2834_1080P25
		}
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827 ) { // PRODUCT_TP2827

			TP2827_OUTPUT( pDevice, TP2834_1080P25 ); // MUX OUTPUT, DEFAULT = TP2834_1080P25
		}
        E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x02, 0xC8 ); // BT1120/BT656 

		if( pDevice->m_nCustomAnalogVideoPinTopologyProperty == 0 ) { TP2834_SET_VIDEO_MODE( pDevice, TP2834_1080P25, TP2834_REG_PAGE_VIN_ALL, TP2834_STD_TVI ); }

		if( pDevice->m_nCustomAnalogVideoPinTopologyProperty == 1 ) { TP2834_SET_VIDEO_MODE( pDevice, TP2834_1080P25, TP2834_REG_PAGE_VIN_ALL, TP2834_STD_HDA ); }

		if( pDevice->m_nCustomAnalogVideoPinTopologyProperty == 2 ) { TP2834_SET_VIDEO_MODE( pDevice, TP2834_1080P25, TP2834_REG_PAGE_VIN_ALL, TP2834_STD_HDC ); }

		if( pDevice->m_nCustomAnalogVideoPinTopologyProperty >= 3 ) { TP2834_SET_VIDEO_MODE( pDevice, TP2834_1080P25, TP2834_REG_PAGE_VIN_ALL, TP2834_STD_TVI ); }

        TP2826_PTZ_INIT( pDevice );

        TP28XX_CHANNELID( pDevice );

	//	TP2834_AUDIO_DATASET( pDevice );
	}
	else { // PRODUCT_TP2834

		TP28XX_SET_REG_PAGE( pDevice, TP2834_REG_PAGE_VIN_ALL );

		TP2834_RESET_DEFAULT( pDevice, TP2834_REG_PAGE_VIN_ALL );

		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x02, 0xC8 ); // BT1120/BT656 

		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x2A, 0x34 ); // BLUE SCREEN

		if( pDevice->m_nCustomAnalogVideoPinTopologyProperty == 0 ) { TP2834_SET_VIDEO_MODE( pDevice, TP2834_1080P25, TP2834_REG_PAGE_VIN_ALL, TP2834_STD_TVI ); }

		if( pDevice->m_nCustomAnalogVideoPinTopologyProperty == 1 ) { TP2834_SET_VIDEO_MODE( pDevice, TP2834_1080P25, TP2834_REG_PAGE_VIN_ALL, TP2834_STD_HDA ); }

		if( pDevice->m_nCustomAnalogVideoPinTopologyProperty == 2 ) { TP2834_SET_VIDEO_MODE( pDevice, TP2834_1080P25, TP2834_REG_PAGE_VIN_ALL, TP2834_STD_HDC ); }

		if( pDevice->m_nCustomAnalogVideoPinTopologyProperty >= 3 ) { TP2834_SET_VIDEO_MODE( pDevice, TP2834_1080P25, TP2834_REG_PAGE_VIN_ALL, TP2834_STD_TVI ); }

		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x4D, 0x0F );

		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x4E, 0x0F );

		TP2834_OUTPUT( pDevice, TP2834_1080P25 ); // MUX OUTPUT, DEFAULT = TP2834_1080P25

		TP28XX_CHANNELID( pDevice );

		TP2834_PTZ_INIT( pDevice );

	//	TP2834_AUDIO_DATASET( pDevice );

		// ADC RESET
		//
		{	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, TP2834_REG_PAGE_VIN_ALL );

			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x3B, 0x33 );

			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x3B, 0x03 );
		}

		// SOFT RESET
		// 
		{	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, TP2834_REG_PAGE_VIN_ALL );

			BYTE R06 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x06 ); R06 |= 0x80;
    
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x06, R06 );
		}
	}
}

LONG TP2834_SET_VIDEO_MODE( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, BYTE mode, BYTE chs, BYTE std ) // -----> tp2802_set_video_mode
{
	MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(pDevice->m_pCustomSystemConfigProperty);
	
	LONG returns = 0;

	if( TP2834_STD_HDA_DEFAULT == std ) { std = TP2834_STD_HDA; }

    TP28XX_SET_REG_PAGE( pDevice, chs );

//	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, 0x05 );

    switch( mode ) {

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    case TP2834_HALF1080P25: { // [HUENGPEI] [2018.01.30.V73.FULL]

		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: TP2834_SET_VIDEO_MODE( STD = %02X, MODE = TP2834_HALF1080P25 )\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, std);
	
	//	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, 0x45 );
	}
    case TP2834_1080P25: { // [HUENGPEI] [2018.01.30.V73.FULL]

		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: TP2834_SET_VIDEO_MODE( STD = %02X, MODE = TP2834_1080P25 )\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, std);

		if( p_sys_cfg->n_is_techpoint_support >= PRODUCT_TP2822 ) { E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, 0x05 ); }

		E2AC4F78FF95428CA3FD05CF4E898465s( pDevice, 0x15, TP2834_TBL_1080P25_RASTER, 9 );

		BYTE R02 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x02 ); R02 &= 0xF8;
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x02, R02 );

		BYTE RF5 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0xF5 ); RF5 &= TP2834_SYS_AND[ chs ];
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0xF5, RF5 );
		
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) {  E2FF27BDFED74FF28B27580A274B5954( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) {  TP2826_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) {  TP2826_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2827C_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_V1_DATASET( pDevice ); }

		if( TP2834_STD_HDA == std || TP2834_STD_HDA_DEFAULT == std ) {
			
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) {    F3239D73625F40B781275AB950E90D2A( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) {  TP2826_A1080P25_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) {  TP2826_A1080P25_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2827C_A1080P25_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_A1080P25_DATASET( pDevice ); }
		}
		else if( TP2834_STD_HDC == std || TP2834_STD_HDC_DEFAULT == std ) {
			
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) { D8DCD1F9AD064027A10452C04868A97C( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) { TP2826_C1080P25_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) { TP2826_C1080P25_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2826_C1080P25_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2826_C1080P25_DATASET( pDevice ); }

			if( TP2834_STD_HDC == std ) { // POSITION ADJUST
            
				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x15, 0x13 );
				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x16, 0x84 );

				if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ||			
					p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ||			
					p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ||				
					p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) {
						                        
					E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x15, 0x13 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x16, 0x60 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x17, 0x80 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x18, 0x29 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x19, 0x38 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x1A, 0x47 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x1C, 0x09 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x1D, 0x60 );
				}
			}
		}
        TP28XX_SYSCLK_V1( pDevice, chs );

        break;
	}

    case TP2834_HALF1080P30: { // [HUENGPEI] [2018.01.30.V73.FULL]

		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: TP2834_SET_VIDEO_MODE( STD = %02X, MODE = TP2834_HALF1080P30 )\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, std);

	//	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, 0x45 );
	}  
	case TP2834_1080P30: { // [HUENGPEI] [2018.01.30.V73.FULL]
		
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: TP2834_SET_VIDEO_MODE( STD = %02X, MODE = TP2834_1080P30 )\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, std);
		
		if( p_sys_cfg->n_is_techpoint_support >= PRODUCT_TP2822 ) { E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, 0x05 ); }

		E2AC4F78FF95428CA3FD05CF4E898465s( pDevice, 0x15, TP2834_TBL_1080P30_RASTER, 9 );

		BYTE R02 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x02 ); R02 &= 0xF8;
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x02, R02 );

		BYTE RF5 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0xF5 ); RF5 &= TP2834_SYS_AND[ chs ];
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0xF5, RF5 );
		
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) {  E2FF27BDFED74FF28B27580A274B5954( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) {  TP2826_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) {  TP2826_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2827C_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_V1_DATASET( pDevice ); }

		if( TP2834_STD_HDA == std || TP2834_STD_HDA_DEFAULT == std ) {
			
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) {    EC1A6FEC82B94C82B77E0C402F0AEDAD( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) {  TP2826_A1080P30_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) {  TP2826_A1080P30_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2827C_A1080P30_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_A1080P30_DATASET( pDevice ); }
		}
		else if( TP2834_STD_HDC == std || TP2834_STD_HDC_DEFAULT == std ) {
			
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) { EE19446D035244E483A5E46A97E5D59F( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) { TP2826_C1080P30_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) { TP2826_C1080P30_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2826_C1080P30_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2826_C1080P30_DATASET( pDevice ); }

			if( TP2834_STD_HDC == std ) { // POSITION ADJUST
            
				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x15, 0x13 );
				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x16, 0x44 );				
				
				if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ||				
					p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ||				
					p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ||				
					p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) {
						                        
					E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x15, 0x13 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x16, 0x60 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x17, 0x80 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x18, 0x29 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x19, 0x38 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x1A, 0x47 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x1C, 0x09 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x1D, 0x60 );
				}
			}
		}
        TP28XX_SYSCLK_V1( pDevice, chs );

        break;
	}
 	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    case TP2834_HALF720P25: { // [HUENGPEI] [2018.01.30.V73.FULL]

		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: TP2834_SET_VIDEO_MODE( STD = %02X, MODE = TP2834_HALF720P25 )\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, std);

	//	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, 0x45 );
	}  
	case TP2834_720P25: { // [HUENGPEI] [2018.01.30.V73.FULL]

		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: TP2834_SET_VIDEO_MODE( STD = %02X, MODE = TP2834_720P25 )\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, std);

		if( p_sys_cfg->n_is_techpoint_support >= PRODUCT_TP2822 ) { E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, 0x05 ); }

		E2AC4F78FF95428CA3FD05CF4E898465s( pDevice, 0x15, TP2834_TBL_720P25_RASTER, 9 );
			
		BYTE R02 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x02 ); R02 &= 0xF8; R02 |= 0x02;
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x02, R02 );

		BYTE RF5 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0xF5 ); RF5 &= TP2834_SYS_AND[ chs ];
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0xF5, RF5 );
		
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) { E2FF27BDFED74FF28B27580A274B5954( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) { TP2826_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) { TP2826_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2826_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2826_V1_DATASET( pDevice ); }

        TP28XX_SYSCLK_V1( pDevice, chs );

        break;
	}

    case TP2834_HALF720P30: { // [HUENGPEI] [2018.01.30.V73.FULL]

		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: TP2834_SET_VIDEO_MODE( STD = %02X, MODE = TP2834_HALF720P30 )\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, std);

	//	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, 0x45 );
	}  
	case TP2834_720P30: { // [HUENGPEI] [2018.01.30.V73.FULL]

		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: TP2834_SET_VIDEO_MODE( STD = %02X, MODE = TP2834_720P30 )\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, std);

		if( p_sys_cfg->n_is_techpoint_support >= PRODUCT_TP2822 ) { E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, 0x05 ); }

		E2AC4F78FF95428CA3FD05CF4E898465s( pDevice, 0x15, TP2834_TBL_720P30_RASTER, 9 );
			
		BYTE R02 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x02 ); R02 &= 0xF8; R02 |= 0x02;
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x02, R02 );

		BYTE RF5 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0xF5 ); RF5 &= TP2834_SYS_AND[ chs ];
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0xF5, RF5 );
		
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) { E2FF27BDFED74FF28B27580A274B5954( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) { TP2826_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) { TP2826_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2826_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2826_V1_DATASET( pDevice ); }

        TP28XX_SYSCLK_V1( pDevice, chs );

        break;
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    case TP2834_HALF720P50: { // [HUENGPEI] [2018.01.30.V73.FULL]

		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: TP2834_SET_VIDEO_MODE( STD = %02X, MODE = TP2834_HALF720P50 )\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, std);

	//	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, 0x45 );
	}  
	case TP2834_720P50: { // [HUENGPEI] [2018.01.30.V73.FULL]

		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: TP2834_SET_VIDEO_MODE( STD = %02X, MODE = TP2834_720P50 )\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, std);
	
		if( p_sys_cfg->n_is_techpoint_support >= PRODUCT_TP2822 ) { E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, 0x05 ); }

		E2AC4F78FF95428CA3FD05CF4E898465s( pDevice, 0x15, TP2834_TBL_720P50_RASTER, 9 );

		BYTE R02 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x02 ); R02 &= 0xF8; R02 |= 0x02;
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x02, R02 );

		BYTE RF5 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0xF5 ); RF5 &= TP2834_SYS_AND[ chs ];
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0xF5, RF5 );
		
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) {  E2FF27BDFED74FF28B27580A274B5954( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) {  TP2826_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) {  TP2826_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2827C_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_V1_DATASET( pDevice ); }
		
		if( TP2834_STD_HDA == std || TP2834_STD_HDA_DEFAULT == std ) {

			;
		}
		else if( TP2834_STD_HDC == std || TP2834_STD_HDC_DEFAULT == std ) {
			
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) { C01CF1A557124A2DBA1A07DE30F643BB( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) { TP2826_C720P50_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) { TP2826_C720P50_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2826_C720P50_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2826_C720P50_DATASET( pDevice ); }

			if( TP2834_STD_HDC == std ) { // POSITION ADJUST
            
				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x16, 0x40 );		
				
				if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ||				
					p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ||				
					p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ||				
					p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) {
						                        
					E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x15, 0x13 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x16, 0x0A );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x17, 0x00 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x18, 0x19 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x19, 0xD0 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x1A, 0x25 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x1C, 0x06 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x1D, 0x7A );
				}
			}
		}
        TP28XX_SYSCLK_V1( pDevice, chs );

        break;
	}

    case TP2834_HALF720P60: { // [HUENGPEI] [2018.01.30.V73.FULL]

		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: TP2834_SET_VIDEO_MODE( STD = %02X, MODE = TP2834_HALF720P60 )\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, std);

	//	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, 0x45 );
	}  
	case TP2834_720P60: { // [HUENGPEI] [2018.01.30.V73.FULL]

		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: TP2834_SET_VIDEO_MODE( STD = %02X, MODE = TP2834_720P60 )\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, std);
			
		if( p_sys_cfg->n_is_techpoint_support >= PRODUCT_TP2822 ) { E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, 0x05 ); }

		E2AC4F78FF95428CA3FD05CF4E898465s( pDevice, 0x15, TP2834_TBL_720P60_RASTER, 9 );

		BYTE R02 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x02 ); R02 &= 0xF8; R02 |= 0x02;
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x02, R02 );

		BYTE RF5 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0xF5 ); RF5 &= TP2834_SYS_AND[ chs ];
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0xF5, RF5 );
		
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) {  E2FF27BDFED74FF28B27580A274B5954( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) {  TP2826_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) {  TP2826_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2827C_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_V1_DATASET( pDevice ); }
		
		if( TP2834_STD_HDA == std || TP2834_STD_HDA_DEFAULT == std ) {
			
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) { TP2834_A720P60_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) { TP2826_A720P60_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) { TP2826_A720P60_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2826_A720P60_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2826_A720P60_DATASET( pDevice ); }
		}
		else if( TP2834_STD_HDC == std || TP2834_STD_HDC_DEFAULT == std ) {
			
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) { C08CDE54992346DBA2DE442475D38661( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) { TP2826_C720P60_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) { TP2826_C720P60_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2826_C720P60_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2826_C720P60_DATASET( pDevice ); }

			if( TP2834_STD_HDC == std ) { // POSITION ADJUST
            
				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x16, 0x02 );	
				
				if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ||				
					p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ||				
					p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ||				
					p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) {
						                        
					E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x15, 0x13 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x16, 0x08 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x17, 0x00 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x18, 0x19 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x19, 0xD0 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x1A, 0x25 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x1C, 0x06 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x1D, 0x72 );
				}
			}
		}
        TP28XX_SYSCLK_V1( pDevice, chs );

        break;
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    case TP2834_720P25V2: { // [HUENGPEI] [2018.01.30.V73.FULL]

		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: TP2834_SET_VIDEO_MODE( STD = %02X, MODE = TP2834_720P25V2 )\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, std);
		
		if( p_sys_cfg->n_is_techpoint_support >= PRODUCT_TP2822 ) { E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, 0x25 ); }

		E2AC4F78FF95428CA3FD05CF4E898465s( pDevice, 0x15, TP2834_TBL_720P50_RASTER, 9 );
		
		BYTE R02 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x02 ); R02 &= 0xF8; R02 |= 0x02;
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x02, R02 );

		BYTE RF5 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0xF5 ); RF5 |= TP2834_SYS_MODE[ chs ];
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0xF5, RF5 );
		
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) {  EAB107EAE6114B51BD3F0FB4DA2AC69F( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) {  TP2826_V2_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) {  TP2826_V2_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2827C_V2_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_V2_DATASET( pDevice ); }

		if( TP2834_STD_HDA == std || TP2834_STD_HDA_DEFAULT == std ) {
			
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) {    A4A06B2DEF35482E9369B8A444050AE9( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) {  TP2826_A720P25_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) {  TP2826_A720P25_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2827C_A720P25_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_A720P25_DATASET( pDevice ); }
		}
		else if( TP2834_STD_HDC == std || TP2834_STD_HDC_DEFAULT == std ) {
			
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) { EC79937CD24E45669B4577A220279B39( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) { TP2826_C720P25_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) { TP2826_C720P25_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2826_C720P25_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2826_C720P25_DATASET( pDevice ); }

			if( TP2834_STD_HDC == std ) { // POSITION ADJUST
            
				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x16, 0x40 );

				if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ||				
					p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ||				
					p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ||				
					p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) {
						                        
					E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x15, 0x13 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x16, 0x0A );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x17, 0x00 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x18, 0x19 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x19, 0xD0 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x1A, 0x25 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x1C, 0x06 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x1D, 0x7A );
				}
			}
		}
        TP28XX_SYSCLK_V2( pDevice, chs );

        break;
	}
    case TP2834_720P30V2: { // [HUENGPEI] [2018.01.30.V73.FULL]

		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: TP2834_SET_VIDEO_MODE( STD = %02X, MODE = TP2834_720P30V2 )\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, std);
				
		if( p_sys_cfg->n_is_techpoint_support >= PRODUCT_TP2822 ) { E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, 0x25 ); }

		E2AC4F78FF95428CA3FD05CF4E898465s( pDevice, 0x15, TP2834_TBL_720P60_RASTER, 9 );
		
		BYTE R02 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x02 ); R02 &= 0xF8; R02 |= 0x02;
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x02, R02 );

		BYTE RF5 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0xF5 ); RF5 |= TP2834_SYS_MODE[ chs ];
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0xF5, RF5 );
		
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) {  EAB107EAE6114B51BD3F0FB4DA2AC69F( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) {  TP2826_V2_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) {  TP2826_V2_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2827C_V2_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_V2_DATASET( pDevice ); }

		if( TP2834_STD_HDA == std || TP2834_STD_HDA_DEFAULT == std ) {
			
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) {    ADF318917EFF4756BA46113402285685( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) {  TP2826_A720P30_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) {  TP2826_A720P30_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2827C_A720P30_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_A720P30_DATASET( pDevice ); }
		}
		else if( TP2834_STD_HDC == std || TP2834_STD_HDC_DEFAULT == std ) {
			
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) { DF4D6828C6594BFAAC9003C3922B6FEA( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) { TP2826_C720P30_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) { TP2826_C720P30_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2826_C720P30_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2826_C720P30_DATASET( pDevice ); }

			if( TP2834_STD_HDC == std ) { // POSITION ADJUST
            
				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x16, 0x02 );		
				
				if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ||				
					p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ||				
					p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ||				
					p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) {
						                        
					E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x15, 0x13 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x16, 0x08 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x17, 0x00 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x18, 0x19 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x19, 0xD0 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x1A, 0x25 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x1C, 0x06 );
                    E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x1D, 0x72 );
				}
			}
		}
        TP28XX_SYSCLK_V2( pDevice, chs );

        break;
	}
    case TP2834_PAL: { // [HUENGPEI] [2018.01.30.V73.FULL]

		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: TP2834_SET_VIDEO_MODE( STD = %02X, MODE = TP2834_PAL )\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, std);

		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, 0x25 );

		E2AC4F78FF95428CA3FD05CF4E898465s( pDevice, 0x15, TP2834_TBL_PAL_RASTER, 9 );
		
		BYTE R02 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x02 ); R02 &= 0xF8; R02 |= 0x07;
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x02, R02 );

		BYTE RF5 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0xF5 ); RF5 |= TP2834_SYS_MODE[ chs ];
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0xF5, RF5 );
		
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) {  E3E73C5B263E44A49538C0F5CC087474( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) {  TP2826_PAL_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) {  TP2826_PAL_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2827C_PAL_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_PAL_DATASET( pDevice ); }

        TP28XX_SYSCLK_V2( pDevice, chs );

        break;
	}
    case TP2834_NTSC: { // [HUENGPEI] [2018.01.30.V73.FULL]

		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: TP2834_SET_VIDEO_MODE( STD = %02X, MODE = TP2834_NTSC )\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, std);

		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, 0x25 );

		E2AC4F78FF95428CA3FD05CF4E898465s( pDevice, 0x15, TP2834_TBL_NTSC_RASTER, 9 );
		
		BYTE R02 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x02 ); R02 &= 0xF8; R02 |= 0x07;
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x02, R02 );

		BYTE RF5 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0xF5 ); RF5 |= TP2834_SYS_MODE[ chs ];
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0xF5, RF5 );
		
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) {  E805C3C2C1EE4BB5A7B9FB984AE9A893( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) {  TP2826_NTSC_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) {  TP2826_NTSC_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2827C_NTSC_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_NTSC_DATASET( pDevice ); }

        TP28XX_SYSCLK_V2( pDevice, chs );

        break;
    }
    case TP2834_3M18: { // [HUENGPEI] [2018.01.30.V73.FULL]
		
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: TP2834_SET_VIDEO_MODE( STD = %02X, MODE = TP2834_3M18 )\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, std);
		
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, 0x16 );

		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x36, 0x30 );
		
		E2AC4F78FF95428CA3FD05CF4E898465s( pDevice, 0x15, TP2834_TBL_3M_RASTER, 9 );
		
		BYTE R02 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x02 ); R02 &= 0xF8;
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x02, R02 );
		
		BYTE RF5 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0xF5 ); RF5 &= TP2834_SYS_AND[ chs ];
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0xF5, RF5 );
		
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) {  E2FF27BDFED74FF28B27580A274B5954( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) {  TP2826_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) {  TP2826_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2827C_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_V1_DATASET( pDevice ); }

        TP28XX_SYSCLK_V1( pDevice, chs );

        break;
	}
    case TP2834_3M20: { // [HUENGPEI] [2018.01.30.V73.FULL]
		
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: TP2834_SET_VIDEO_MODE( STD = %02X, MODE = TP2834_3M20 )\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, std);
		
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, 0x16 );

		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x36, 0x72 );
		
		E2AC4F78FF95428CA3FD05CF4E898465s( pDevice, 0x15, TP2834_TBL_3M20_RASTER, 9 );
		
		BYTE R02 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x02 ); R02 &= 0xF8;
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x02, R02 );
		
		BYTE RF5 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0xF5 ); RF5 &= TP2834_SYS_AND[ chs ];
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0xF5, RF5 );
		
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) {  E2FF27BDFED74FF28B27580A274B5954( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) {  TP2826_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) {  TP2826_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2827C_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_V1_DATASET( pDevice ); }
		
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x2D, 0x26 );

        TP28XX_SYSCLK_V1( pDevice, chs );

        break;
	}
    case TP2834_4M12: { // [HUENGPEI] [2018.01.30.V73.FULL]
		
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: TP2834_SET_VIDEO_MODE( STD = %02X, MODE = TP2834_4M12 )\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, std);
		
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, 0x17 );

		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x36, 0x08 );
		
		E2AC4F78FF95428CA3FD05CF4E898465s( pDevice, 0x15, TP2834_TBL_4M12_RASTER, 9 );
		
		BYTE R02 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x02 ); R02 &= 0xF8;
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x02, R02 );
		
		BYTE RF5 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0xF5 ); RF5 &= TP2834_SYS_AND[ chs ];
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0xF5, RF5 );
		
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) {  E2FF27BDFED74FF28B27580A274B5954( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) {  TP2826_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) {  TP2826_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2827C_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_V1_DATASET( pDevice ); }

        TP28XX_SYSCLK_V1( pDevice, chs );

        break;
	}
    case TP2834_4M15: { // [HUENGPEI] [2018.01.30.V73.FULL]
		
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: TP2834_SET_VIDEO_MODE( STD = %02X, MODE = TP2834_4M15 )\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, std);
		
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, 0x16 );

		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x36, 0x72 );
		
		E2AC4F78FF95428CA3FD05CF4E898465s( pDevice, 0x15, TP2834_TBL_4M_RASTER, 9 );
		
		BYTE R02 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x02 ); R02 &= 0xF8;
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x02, R02 );
		
		BYTE RF5 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0xF5 ); RF5 &= TP2834_SYS_AND[ chs ];
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0xF5, RF5 );
		
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) {  E2FF27BDFED74FF28B27580A274B5954( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) {  TP2826_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) {  TP2826_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2827C_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_V1_DATASET( pDevice ); }

        TP28XX_SYSCLK_V1( pDevice, chs );

        break;
	}
    case TP2834_QHD15: { // [HUENGPEI] [2018.01.30.V73.FULL]
		
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: TP2834_SET_VIDEO_MODE( STD = %02X, MODE = TP2834_QHD15 )\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, std);
		
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, 0x15 );

		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x36, 0xDC );
		
		E2AC4F78FF95428CA3FD05CF4E898465s( pDevice, 0x15, TP2834_TBL_QHD15_RASTER, 9 );
		
		BYTE R02 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x02 ); R02 &= 0xF8;
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x02, R02 );
		
		BYTE RF5 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0xF5 ); RF5 &= TP2834_SYS_AND[ chs ];
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0xF5, RF5 );
		
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834  ) {  E2FF27BDFED74FF28B27580A274B5954( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) {  TP2826_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) {  TP2826_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2827C_V1_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_V1_DATASET( pDevice ); }

		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826 ||
			
			p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827 ) {

			TP2827_AQHDP15_DATASET( pDevice );
		}
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ||
			
			p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) {

			TP2827C_AQHDP15_DATASET( pDevice );
		}
        TP28XX_SYSCLK_V1( pDevice, chs );

        break;
	}
    case TP2834_QHD25: { // [HUENGPEI] [2018.01.30.V73.FULL]
		
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: TP2834_SET_VIDEO_MODE( STD = %02X, MODE = TP2834_QHD25 )\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, std);
		
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, 0x15 );

		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x36, 0xDC );
		
		BYTE R02 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x02 ); R02 &= 0xF8;
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x02, R02 );
		
		BYTE RF5 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0xF5 ); RF5 &= TP2834_SYS_AND[ chs ];
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0xF5, RF5 );
		
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) { E2AC4F78FF95428CA3FD05CF4E898465s( pDevice, 0x15, TP2834_TBL_QHD25_RASTER, 9 ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) { E2AC4F78FF95428CA3FD05CF4E898465s( pDevice, 0x15, TP2834_TBL_QHD25_RASTER, 9 ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { E2AC4F78FF95428CA3FD05CF4E898465s( pDevice, 0x15, TP2834_TBL_QHD25_RASTER, 9 ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { E2AC4F78FF95428CA3FD05CF4E898465s( pDevice, 0x15, TP2834_TBL_QHD25_RASTER, 9 ); }
				
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) {  TP2827_QHDP30_25_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) {  TP2827_QHDP30_25_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2827C_QHDP30_25_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_QHDP30_25_DATASET( pDevice ); }

		if( TP2834_STD_HDA == std || TP2834_STD_HDA_DEFAULT == std ) {
			
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) {  TP2827_AQHDP25_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) {  TP2827_AQHDP25_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_AQHDP25_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_AQHDP25_DATASET( pDevice ); }
		}
		else if( TP2834_STD_HDC == std || TP2834_STD_HDC_DEFAULT == std ) {
			
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) {  TP2827_CQHDP25_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) {  TP2827_CQHDP25_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_CQHDP25_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_CQHDP25_DATASET( pDevice ); }
		}
        TP28XX_SYSCLK_V3( pDevice, chs );

        break;
	}
    case TP2834_QHD30: { // [HUENGPEI] [2018.01.30.V73.FULL]
		
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: TP2834_SET_VIDEO_MODE( STD = %02X, MODE = TP2834_QHD30 )\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, std);
		
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, 0x15 );

		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x36, 0xDC );
		
		BYTE R02 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x02 ); R02 &= 0xF8;
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x02, R02 );
		
		BYTE RF5 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0xF5 ); RF5 &= TP2834_SYS_AND[ chs ];
    
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0xF5, RF5 );
		
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) { E2AC4F78FF95428CA3FD05CF4E898465s( pDevice, 0x15, TP2834_TBL_QHD30_RASTER, 9 ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) { E2AC4F78FF95428CA3FD05CF4E898465s( pDevice, 0x15, TP2834_TBL_QHD30_RASTER, 9 ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { E2AC4F78FF95428CA3FD05CF4E898465s( pDevice, 0x15, TP2834_TBL_QHD30_RASTER, 9 ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { E2AC4F78FF95428CA3FD05CF4E898465s( pDevice, 0x15, TP2834_TBL_QHD30_RASTER, 9 ); }
				
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) {  TP2827_QHDP30_25_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) {  TP2827_QHDP30_25_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { TP2827C_QHDP30_25_DATASET( pDevice ); }
		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_QHDP30_25_DATASET( pDevice ); }

		if( TP2834_STD_HDA == std || TP2834_STD_HDA_DEFAULT == std ) {
			
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) {  TP2827_AQHDP30_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) {  TP2827_AQHDP30_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_AQHDP30_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_AQHDP30_DATASET( pDevice ); }
		}
		else if( TP2834_STD_HDC == std || TP2834_STD_HDC_DEFAULT == std ) {
			
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ) {  TP2827_CQHDP30_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ) {  TP2827_CQHDP30_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_CQHDP30_DATASET( pDevice ); }
			if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { TP2827C_CQHDP30_DATASET( pDevice ); }
		}
        TP28XX_SYSCLK_V3( pDevice, chs );

        break;
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    default: {

        returns = -1;
    
		break;
	}
	}

	if( mode & TP2834_FLAG_HALF_MODE ) {

		BYTE R35 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x35 );

		R35 |= 0x40;

		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, R35 );
	}
    return returns;
}

VOID TP2834_FORMAT_DETECTION( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice )
{
	MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(pDevice->m_pCustomSystemConfigProperty);

	#define TP2834_INCREASE_COUNT( v ) { if( (v) < 0xFFFFFFFF ) { (v)++; } }

	ULONG n_techpoint_product = p_sys_cfg->n_is_techpoint_support;

	BYTE counts = 4;
	
	if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834 ||   // PRODUCT_TP2834
		
		p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827 ||   // PRODUCT_TP2827
		
		p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { // PRODUCT_TP2827C

		counts = 4;
	}
	else { // PRODUCT_TP2826 & PRODUCT_TP2826C

		counts = 2;
	}
	BYTE i = 0;
	for( i = 0 ; i < counts ; i++ ) {

		if( g_pDevice[ pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE + i ] ) {

			#ifdef AME_MZ0380

			if( i >=1 )
			{
				if( g_pDevice[ pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE + i ]->iManufacturer == 0xC2 || g_pDevice[ pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE + i ]->iManufacturer == 0x52 )
				{
					NULL; //SC5C0 TVI N4
				}
				else
				{
					break; //SC5C0 TVI N1 MC
				}
			}

			MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(g_pDevice[ pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE + i ]->m_pCustomSystemConfigProperty);
			
			F42A18AF66EFF459eA332CA253FFF8A65 * g_p_device = g_pDevice[ pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE + i ];
			
			if( g_p_device->m_pLinkDevice == NULL ) { // 1ST ATTACHED

				CC7AF56407504E059A58F55D48A142C1( pDevice, TRUE, TRUE );
			}
			g_p_device->m_pLinkDevice = pDevice;

			g_p_device->m_nLinkNum = i;

			if( p_sys_cfg ) {
			
				TP2834_SIGNAL_INFO * p_sg_info = &(p_sys_cfg->m_s_tp2834_sg_info);

				BYTE  R01 = 0x00;

				BYTE  R03 = 0x00;
				
				ULONG x = 0;

				ULONG y = 0;

				ULONG fps = 0;

				ULONG m = 0;

				ULONG interleaved = 0;

				TP28XX_SET_REG_PAGE( pDevice, i );

				R01 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x01 );

				R03 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x03 );

				F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: R01 = %02X, R03 = %02X, counts = %d\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, R01, R03, p_sg_info->count[ i ]);
	
				if( TP2834_FLAG_LOSS & R01 ) {
			
					if( p_sg_info->state[ i ] != TP2834_SIGNAL_UNPLUG ) {

						p_sg_info->state[ i ] = TP2834_SIGNAL_UNPLUG;

						p_sg_info->mode[ i ] = TP2834_INVALID_FORMAT;

						p_sg_info->count[ i ] = 0;
					}
					else {

						p_sg_info->mode[ i ] = TP2834_INVALID_FORMAT;
					}
					if( p_sg_info->count[ i ] == 0 ) { //

						if( g_p_device->m_nCustomAnalogVideoPinTopologyProperty == 0 ) { TP2834_SET_VIDEO_MODE( pDevice, TP2834_1080P25, i, TP2834_STD_TVI ); }
					
						if( g_p_device->m_nCustomAnalogVideoPinTopologyProperty == 1 ) { TP2834_SET_VIDEO_MODE( pDevice, TP2834_1080P25, i, TP2834_STD_HDA ); }
					
						if( g_p_device->m_nCustomAnalogVideoPinTopologyProperty == 2 ) { TP2834_SET_VIDEO_MODE( pDevice, TP2834_1080P25, i, TP2834_STD_HDC ); }
					
						if( g_p_device->m_nCustomAnalogVideoPinTopologyProperty >= 3 ) { TP2834_SET_VIDEO_MODE( pDevice, TP2834_1080P25, i, TP2834_STD_TVI ); } // SCAN

						TP28XX_RESET_DEFAULT( pDevice, i );
					}
					TP2834_INCREASE_COUNT( p_sg_info->count[ i ] );
				}
				else {
					
					ULONG mask = TP2834_FLAG_HV_LOCKED;

					if( p_sg_info->mode[ i ] == TP2834_NTSC ||
						
						p_sg_info->mode[ i ] == TP2834_PAL ) {

						mask = TP2834_FLAG_H_LOCKED;
					}
					else {

						mask = TP2834_FLAG_HV_LOCKED;
					}
					if( (mask & R01) == mask ) {

						if( p_sg_info->state[ i ] != TP2834_SIGNAL_LOCKED ) {

							p_sg_info->state[ i ] = TP2834_SIGNAL_LOCKED;

							p_sg_info->mode[ i ] = TP2834_INVALID_FORMAT;

							p_sg_info->count[ i ] = 0;
						}
						TP2834_INCREASE_COUNT( p_sg_info->count[ i ] );
					}
					else {

						if( p_sg_info->state[ i ] != TP2834_SIGNAL_UNLOCK ) {

							p_sg_info->state[ i ] = TP2834_SIGNAL_UNLOCK;

							p_sg_info->mode[ i ] = TP2834_INVALID_FORMAT;

							p_sg_info->count[ i ] = 0;
						}
						if( p_sg_info->count[ i ] > 3  ) {

							p_sg_info->count[ i ] = 0;
						}
						if( p_sg_info->count[ i ] == 0 ) { //
							
							TP28XX_RESET_DEFAULT( pDevice, i );
						}
						TP2834_INCREASE_COUNT( p_sg_info->count[ i ] );
					}
					if( p_sg_info->state[ i ] == TP2834_SIGNAL_LOCKED ||
						
						p_sg_info->state[ i ] == TP2834_SIGNAL_UNLOCK ) {

						ULONG n_tvi_version = (R03 & 0x08) ? 2 : 1;

						ULONG n_backup_count = p_sg_info->count[ i ];

						ULONG n_backup_mode = p_sg_info->mode[ i ];

						switch( R03 & 0x07 ) {

						case 0: x = 1280; y =  720; fps = 60; m = 1; p_sg_info->mode[ i ] = TP2834_720P60;  break;

						case 1: x = 1280; y =  720; fps = 50; m = 0; p_sg_info->mode[ i ] = TP2834_720P50;  break;

						case 2: x = 1920; y = 1080; fps = 30; m = 1; p_sg_info->mode[ i ] = TP2834_1080P30; break;

						case 3: x = 1920; y = 1080; fps = 25; m = 0; p_sg_info->mode[ i ] = TP2834_1080P25; break;

						case 4: x = 1280; y =  720; fps = 30; m = 1; p_sg_info->mode[ i ] = TP2834_720P30;  break;

						case 5: x = 1280; y =  720; fps = 25; m = 0; p_sg_info->mode[ i ] = TP2834_720P25;  break;

						case 6: 
#if 0
								if( p_sg_info->mode[ i ] != TP2834_PAL &&
										
									p_sg_info->mode[ i ] != TP2834_NTSC ) { // �q��L�T�����L��

									x = 1984 - 48; y = 576; fps = 25; m = 0; p_sg_info->mode[ i ] = TP2834_PAL;

									p_sg_info->count[ i ] = 1;
								}
								else if( p_sg_info->state[ i ] == TP2834_SIGNAL_UNLOCK &&
									
										 p_sg_info->count[ i ] >= 5 ) {

									if( p_sg_info->mode[ i ] != TP2834_PAL ) {

										x = 1984 - 48; y = 576; fps = 25; m = 0; p_sg_info->mode[ i ] = TP2834_PAL;

										p_sg_info->count[ i ] = 1;
									}
									else {

										x = 1984 - 16; y = 480; fps = 30; m = 1; p_sg_info->mode[ i ] = TP2834_NTSC;

										p_sg_info->count[ i ] = 1;
									}
								}
#else													
								if( R01 & 0x04 ) {
							
									if( p_sg_info->mode[ i ] != TP2834_PAL ) {

										p_sg_info->count[ i ] = 1;
									}
								//	x = 1984 - 48; y = 576; fps = 25; m = 0; p_sg_info->mode[ i ] = TP2834_PAL; // 1936
									
									x = 960; y = 576; fps = 25; m = 0; p_sg_info->mode[ i ] = TP2834_PAL; // 1936 -> 960
								}
								else {

									if( p_sg_info->mode[ i ] != TP2834_NTSC ) {

										p_sg_info->count[ i ] = 1;
									}
								//	x = 1984 - 16; y = 480; fps = 30; m = 1; p_sg_info->mode[ i ] = TP2834_NTSC; 
								
									x = 960; y = 480; fps = 30; m = 1; p_sg_info->mode[ i ] = TP2834_NTSC; // 1968 -> 960
								}
#endif
								break ;

						case 7:
							
							if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ||

								p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ||

								p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ||

								p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { 
									
								E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x2F, 0x09 );

								BYTE R04 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x04 );

								if( R04 == 0x4E ) {

									x = 2048; y = 1536; fps = 30; m = 1; p_sg_info->mode[ i ] = TP2834_3M18; // [3M+]
								}
								else {

									p_sg_info->mode[ i ] = TP2834_INVALID_FORMAT;
								}
							}
							else {

								p_sg_info->mode[ i ] = TP2834_INVALID_FORMAT;
							}
							break ;

						default: 
							
							p_sg_info->mode[ i ] = TP2834_INVALID_FORMAT;
								
							break ;
						}
						if( (R01 & 0x02) == 0x00 ) { // INTERLEAVED

							interleaved = 1;

							y >>= 1;

							fps <<= 1;
						}
						if( g_p_device->m_nCustomAnalogVideoPinTopologyProperty == 1 ||  // TP2834_STD_HDA
							
							g_p_device->m_nCustomAnalogVideoPinTopologyProperty == 2 ) { // TP2834_STD_HDC
							
							if( (p_sg_info->mode[ i ] == TP2834_720P25) ) { p_sg_info->mode[ i ] = TP2834_720P25V2; }

							if( (p_sg_info->mode[ i ] == TP2834_720P30) ) { p_sg_info->mode[ i ] = TP2834_720P30V2; }
						}
						else if( g_p_device->m_nCustomAnalogVideoPinTopologyProperty >= 3 && p_sg_info->std[ i ] != TP2834_STD_TVI ) { //.SCAN
							
							if( (p_sg_info->mode[ i ] == TP2834_720P25) ) { p_sg_info->mode[ i ] = TP2834_720P25V2; }

							if( (p_sg_info->mode[ i ] == TP2834_720P30) ) { p_sg_info->mode[ i ] = TP2834_720P30V2; }
						}
						else { // TP2834_STD_TVI
										
							if( (p_sg_info->mode[ i ] == TP2834_720P25) && (n_tvi_version == 2) ) { p_sg_info->mode[ i ] = TP2834_720P25V2; }

							if( (p_sg_info->mode[ i ] == TP2834_720P30) && (n_tvi_version == 2) ) { p_sg_info->mode[ i ] = TP2834_720P30V2; }
						}
						if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ||

							p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ||

							p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ||

							p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { 

							if( p_sg_info->state[ i ] == TP2834_SIGNAL_UNLOCK ) {

								p_sg_info->qhd[ i ] = !p_sg_info->qhd[ i ];
							}
							if( p_sg_info->qhd[ i ] == TRUE ) {

								if( p_sg_info->mode[ i ] == TP2834_720P30V2 ) {
	
									x = 2560; y = 1440; fps = 30; m = 1; p_sg_info->mode[ i ] = TP2834_QHD15; // [3M+]
								}
							}
							else {

								;
							}
							if( n_backup_mode != p_sg_info->mode[ i ] ) {

								p_sg_info->count[ i ] = 1;
							}
						}
						
						// [2017.07.19]
						//
						if( p_sg_info->mode[ i ] == TP2834_NTSC ||

							p_sg_info->mode[ i ] == TP2834_PAL ) {

							p_sys_cfg->n_input_video_signal_changed_counts = 0;
						}
						else if( n_backup_mode != p_sg_info->mode[ i ] ||

								 n_backup_count != p_sg_info->count[ i ] ) {

							if( p_sys_cfg->n_input_video_signal_changed_counts++ < 3 ) {

								p_sg_info->count[ i ] = n_backup_count;

								p_sg_info->mode[ i ] = n_backup_mode;

								continue ;
							}
						}
						else {

							p_sys_cfg->n_input_video_signal_changed_counts = 0;
						}

						if( p_sg_info->mode[ i ] != TP2834_INVALID_FORMAT ) {

							#define TP2834_EQ_COUNT 10

							if( p_sg_info->count[ i ] == 1 ) {

								if( g_p_device->m_nCustomAnalogVideoPinTopologyProperty == 0 ) { TP2834_SET_VIDEO_MODE( pDevice, (BYTE)(p_sg_info->mode[ i ]), (BYTE)(i), TP2834_STD_TVI ); }

								if( g_p_device->m_nCustomAnalogVideoPinTopologyProperty == 1 ) { TP2834_SET_VIDEO_MODE( pDevice, (BYTE)(p_sg_info->mode[ i ]), (BYTE)(i), TP2834_STD_HDA ); }

								if( g_p_device->m_nCustomAnalogVideoPinTopologyProperty == 2 ) { TP2834_SET_VIDEO_MODE( pDevice, (BYTE)(p_sg_info->mode[ i ]), (BYTE)(i), TP2834_STD_HDC ); }
								
								if( g_p_device->m_nCustomAnalogVideoPinTopologyProperty >= 3 ) { TP2834_SET_VIDEO_MODE( pDevice, (BYTE)(p_sg_info->mode[ i ]), (BYTE)(i), TP2834_STD_TVI ); }
								
								if( n_techpoint_product == PRODUCT_TP2826  ||  // PRODUCT_TP2826

									n_techpoint_product == PRODUCT_TP2826C ||  // PRODUCT_TP2826C

									n_techpoint_product == PRODUCT_TP2827  ||  // PRODUCT_TP2827

									n_techpoint_product == PRODUCT_TP2827C ) { // PRODUCT_TP2827C
								
									BYTE R26 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x26 ); R26 |= 0x01;

									E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x26, R26 );
								}
								else { // PRODUCT_TP2834
									
									BYTE R26 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x26 ); R26 &=0xFC; R26 |= 0x02;

									E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x26, R26 );
								}
								if( g_p_device->m_nCustomAnalogVideoPinTopologyProperty >= 3 ) {

									p_sg_info->std[ i ] = TP2834_STD_TVI;

									pDevice->m_nCustomAnalogVideoPinTopologyPropertyEx = 0;
								}
								{   BYTE R35 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x35 );

									if( n_techpoint_product == PRODUCT_TP2826  ||  // PRODUCT_TP2826

										n_techpoint_product == PRODUCT_TP2826C ||  // PRODUCT_TP2826C

										n_techpoint_product == PRODUCT_TP2827  ||  // PRODUCT_TP2827

										n_techpoint_product == PRODUCT_TP2827C ) { // PRODUCT_TP2827C
								
										E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0xA7, 0x00 );
									}
									else { // PRODUCT_TP2834

										BYTE RB9 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0xB9 );

										E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0xB9, RB9 & TP2834_SYS_AND[ i ] );

										E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0xB9, RB9 | TP2834_SYS_MODE[ i ] );
									}
								}
							}
							else if( p_sg_info->count[ i ] < 2 ) {

								if( n_techpoint_product == PRODUCT_TP2826  ||  // PRODUCT_TP2826

									n_techpoint_product == PRODUCT_TP2826C ||  // PRODUCT_TP2826C

									n_techpoint_product == PRODUCT_TP2827  ||  // PRODUCT_TP2827

									n_techpoint_product == PRODUCT_TP2827C ) { // PRODUCT_TP2827C
										
									E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0xA7, 0x03 );
								}
							}
							else if( p_sg_info->count[ i ] < (TP2834_EQ_COUNT - 3) ) {

								if( g_p_device->m_nCustomAnalogVideoPinTopologyProperty >= 3 ) {				

									if( p_sg_info->mode[ i ] == TP2834_NTSC ||
						
										p_sg_info->mode[ i ] == TP2834_PAL ) {

										; // NOTHING TO DO
									}
									else if( (R01 & 0x64) == 0x60 && p_sg_info->std[ i ] == TP2834_STD_TVI ) { // �L�k���� EQ �N���зǥi�ण��

										BYTE RX2 = 0x00;

										BYTE R01 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x01 ) & 0x11;
																
										if( n_techpoint_product == PRODUCT_TP2826  ||  // PRODUCT_TP2826

											n_techpoint_product == PRODUCT_TP2826C ||  // PRODUCT_TP2826C

											n_techpoint_product == PRODUCT_TP2827  ||  // PRODUCT_TP2827

											n_techpoint_product == PRODUCT_TP2827C ) { // PRODUCT_TP2827C

											RX2 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x94 );
										}
										else { // PRODUCT_TP2834

											RX2 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x94 + (10 * i) );
										}
										if( RX2 == 0xFF ) {

											p_sg_info->std[ i ] = TP2834_STD_HDC;
									
											pDevice->m_nCustomAnalogVideoPinTopologyPropertyEx = 2;

											F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: AUTO.SCAN.RX2 = %02X, R01 = %02X, COUNT = %02X -> TP2834_STD_HDC\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, RX2, R01, p_sg_info->count[ i ]);
										}
										else if( RX2 == 0x00 ) {
										
										//	p_sg_info->std[ i ] = TP2834_STD_HDC_DEFAULT;

											if( 0x10 == (0x11 & R01) ) {

												p_sg_info->std[ i ] = TP2834_STD_HDC;
									
												pDevice->m_nCustomAnalogVideoPinTopologyPropertyEx = 2;
											}
											else {

												p_sg_info->std[ i ] = TP2834_STD_HDA;
									
												pDevice->m_nCustomAnalogVideoPinTopologyPropertyEx = 1;
											}
											F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: AUTO.SCAN.RX2 = %02X, R01 = %02X, COUNT = %02X -> TP2834_STD_HDC_DEFAULT\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, RX2, R01, p_sg_info->count[ i ]);
										}
										else {
										
											p_sg_info->std[ i ] = TP2834_STD_HDA;
									
											pDevice->m_nCustomAnalogVideoPinTopologyPropertyEx = 1;
									
											F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: AUTO.SCAN.RX2 = %02X, R01 = %02X, COUNT = %02X -> TP2834_STD_HDA\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, RX2, R01, p_sg_info->count[ i ]);
										}
										if( p_sg_info->std[ i ] != TP2834_STD_TVI ) {

											TP2834_SET_VIDEO_MODE( pDevice, (BYTE)(p_sg_info->mode[ i ]), (BYTE)(i), (BYTE)(p_sg_info->std[ i ]) );
										}
									}
								}
							}
							else if( p_sg_info->count[ i ] < TP2834_EQ_COUNT ) { // < 10
							
								p_sg_info->gain[ i ][ 3 ] = p_sg_info->gain[ i ][ 2 ];

								p_sg_info->gain[ i ][ 2 ] = p_sg_info->gain[ i ][ 1 ];

								p_sg_info->gain[ i ][ 1 ] = p_sg_info->gain[ i ][ 0 ];

								p_sg_info->gain[ i ][ 0 ] = TP28XX_READ_EGAIN( pDevice );

							//	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: EQ = %d COUNT = %02X\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, p_sg_info->gain[ i ][ 0 ], p_sg_info->count[ i ]);
							}
							else if( p_sg_info->count[ i ] < (TP2834_EQ_COUNT + TP2834_EQ_COUNT) ) { // < 20
							
								p_sg_info->gain[ i ][ 3 ] = p_sg_info->gain[ i ][ 2 ];

								p_sg_info->gain[ i ][ 2 ] = p_sg_info->gain[ i ][ 1 ];

								p_sg_info->gain[ i ][ 1 ] = p_sg_info->gain[ i ][ 0 ];

								p_sg_info->gain[ i ][ 0 ] = TP28XX_READ_EGAIN( pDevice );

							//	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: EQ = %d COUNT = %02X\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, p_sg_info->gain[ i ][ 0 ], p_sg_info->count[ i ]);

								ULONG abs3 = (p_sg_info->gain[ i ][ 3 ] > p_sg_info->gain[ i ][ 0 ]) ? (p_sg_info->gain[ i ][ 3 ] - p_sg_info->gain[ i ][ 0 ]) : (p_sg_info->gain[ i ][ 0 ] - p_sg_info->gain[ i ][ 3 ]);
								
								ULONG abs2 = (p_sg_info->gain[ i ][ 2 ] > p_sg_info->gain[ i ][ 0 ]) ? (p_sg_info->gain[ i ][ 2 ] - p_sg_info->gain[ i ][ 0 ]) : (p_sg_info->gain[ i ][ 0 ] - p_sg_info->gain[ i ][ 2 ]);
								
								ULONG abs1 = (p_sg_info->gain[ i ][ 1 ] > p_sg_info->gain[ i ][ 0 ]) ? (p_sg_info->gain[ i ][ 1 ] - p_sg_info->gain[ i ][ 0 ]) : (p_sg_info->gain[ i ][ 0 ] - p_sg_info->gain[ i ][ 1 ]);
								
								if( abs3 < 0x02 && 

									abs2 < 0x02 && 

									abs1 < 0x02 ) {

									F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: EQ STABLE COUNT = %02X\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, p_sg_info->count[ i ]);

									p_sg_info->count[ i ] = (TP2834_EQ_COUNT + TP2834_EQ_COUNT) - (1); // EXIT WHEN EQ STABLE
								}
							}
							else if( p_sg_info->count[ i ] == (TP2834_EQ_COUNT + TP2834_EQ_COUNT) ) { // == 20
							
								BYTE R04 = TP28XX_READ_EGAIN( pDevice );

								if( g_p_device->m_nCustomAnalogVideoPinTopologyProperty == 1 ||  // TP2834_STD_HDA
									
									g_p_device->m_nCustomAnalogVideoPinTopologyProperty == 2 ) { // TP2834_STD_HDC
								
									E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x07, 0x80 | (R04 / 4) ); // MODE
								}
								else if( g_p_device->m_nCustomAnalogVideoPinTopologyProperty >= 3 && p_sg_info->std[ i ] != TP2834_STD_TVI ) { //.SCAN

									E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x07, 0x80 | (R04 / 4) ); // MODE
								}
								else { // TP2834_STD_TVI
								
									if( n_techpoint_product == PRODUCT_TP2834 ) { // PRODUCT_TP2834

										if( p_sg_info->mode[ i ] & TP2834_FLAG_MEGA_MODE ) {
								
											E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x07, 0x80 | (R04 / 3) ); // MODE
										}
									}
								}
							}
							else if( p_sg_info->count[ i ] == (TP2834_EQ_COUNT + TP2834_EQ_COUNT + 1) ) { // == 21
							
//								if( g_p_device->m_nCustomAnalogVideoPinTopologyProperty >= 3 ) {
//
//									if( p_sg_info->std[ i ] == TP2834_STD_HDC_DEFAULT ) {
//
//										E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x2F, 0x0C );
//
//										BYTE R01 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x01 );
//
//                                      if( 0x10 == (0x11 & R01) ) {
//
//                                          p_sg_info->std[ i ] = TP2834_STD_HDC;
//
//											F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: AUTO.SCAN.R01 = %02X COUNT = %02X TP2834_STD_HDC_DEFAULT -> TP2834_STD_HDC\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, R01, p_sg_info->count[ i ]);
//                                      }
//                                      else {
//
//                                          p_sg_info->std[ i ] = TP2834_STD_HDA;
//
//											F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: AUTO.SCAN.R01 = %02X COUNT = %02X TP2834_STD_HDC_DEFAULT -> TP2834_STD_HDA\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, R01, p_sg_info->count[ i ]);
//                                      }
//										TP2834_SET_VIDEO_MODE( pDevice, (BYTE)(p_sg_info->mode[ i ]), (BYTE)(i), (BYTE)(p_sg_info->std[ i ]) );
//									}
//								}
									
								if( g_p_device->m_nCustomAnalogVideoPinTopologyProperty == 1 ||  // TP2834_STD_HDA
									
									g_p_device->m_nCustomAnalogVideoPinTopologyProperty == 2 ) { // TP2834_STD_HDC
								
									if( n_techpoint_product == PRODUCT_TP2834 ) { // PRODUCT_TP2834

										TP28XX_MANUAL_AGC( pDevice, i );
									}
									TP28XX_EGAIN( pDevice, i, 0x0C );
								}
								else if( g_p_device->m_nCustomAnalogVideoPinTopologyProperty >= 3 && p_sg_info->std[ i ] != TP2834_STD_TVI ) { //.SCAN
								
									if( n_techpoint_product == PRODUCT_TP2834 ) { // PRODUCT_TP2834

										TP28XX_MANUAL_AGC( pDevice, i );
									}
									TP28XX_EGAIN( pDevice, i, 0x0C );
								}
								else { // TP2834_STD_TVI 

									if( n_techpoint_product == PRODUCT_TP2834 ) { // PRODUCT_TP2834

										if( p_sg_info->mode[ i ] & TP2834_FLAG_MEGA_MODE ) {

											TP28XX_EGAIN( pDevice, i, 0x16 );
										}
									}
								}
							}
						}
					}
				//	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: STATE = %02X, COUNT = %02X\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, p_sg_info->state[ i ], p_sg_info->count[ i ]);
				}
				
				if( x != 0 && y != 0 && p_sg_info->state[ i ] == TP2834_SIGNAL_LOCKED ) {

					if( p_sys_cfg->n_input_video_resolution_cx != x ||

						p_sys_cfg->n_input_video_resolution_cy != y ||

						p_sys_cfg->n_input_video_resolution_fps != fps ||

						p_sys_cfg->n_input_video_resolution_fps_m != m ) {

						p_sys_cfg->n_input_video_resolution_cx = x;

						p_sys_cfg->n_input_video_resolution_cy = y;

						p_sys_cfg->n_input_video_resolution_fps = fps;

						p_sys_cfg->n_input_video_resolution_fps_m = m;

						if( p_sys_cfg->n_input_video_resolution_cy == 240 ||

							p_sys_cfg->n_input_video_resolution_cy == 288 ||

							p_sys_cfg->n_input_video_resolution_cy == 540 ) {

							p_sys_cfg->n_input_video_resolution_interleaved = 1;
						}
						else {

							p_sys_cfg->n_input_video_resolution_interleaved = 0;
						}
						p_sys_cfg->b_input_video_signal_changed = TRUE;

						p_sys_cfg->n_input_audio_sampling_frequency = 48000;

						p_sys_cfg->n_input_video_resolution_color_colorimetry = (y == 240 || y == 288) ? 1 : 2;

						p_sys_cfg->n_input_video_resolution_color_range = 1;
	
						p_sys_cfg->n_input_video_resolution_color_type = 1;

						p_sys_cfg->b_input_video_resolution_external_sync = FALSE;
					}
					F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "TP2834_TVI_MODE_DETECT( %d x CH%d x %d x %d x %d )\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, i, (ULONG)(x), (ULONG)(y), fps);

					if( p_sys_cfg->n_input_video_resolution_fps > 50 ) {

						g_p_device->FD314ADAD9404496b842EBFC396E875CB = V4L2_STD_NTSC_M;
					}
					else if( p_sys_cfg->n_input_video_resolution_fps > 30 ) {

						g_p_device->FD314ADAD9404496b842EBFC396E875CB = V4L2_STD_PAL_B;
					}
					else if( p_sys_cfg->n_input_video_resolution_fps > 25 ) {

						g_p_device->FD314ADAD9404496b842EBFC396E875CB = V4L2_STD_NTSC_M;
					}
					else {

						g_p_device->FD314ADAD9404496b842EBFC396E875CB = V4L2_STD_PAL_B;
					}
					g_p_device->m_nCustomAnalogVideoResolutionProperty = (p_sys_cfg->n_input_video_resolution_cx << 16) |

																		 (p_sys_cfg->n_input_video_resolution_cy <<  0);

					g_p_device->m_nCustomAnalogVideoFrameRateProperty = (p_sys_cfg->n_input_video_resolution_fps);

					g_p_device->m_nCustomAnalogVideoInterleavedProperty = (p_sys_cfg->n_input_video_resolution_interleaved);
					
					g_p_device->m_nCustomAnalogAudioSampleFrequencyProperty = 48000;

					g_p_device->m_nAnalogVideoDecoderStatusProperty = 1;

					g_p_device->m_nAnalogCopyProtMacrovisionProperty = 0;
						
					g_p_device->m_nCustomAnalogVideoSdiSingalStatusProperty = 0x00000000;
				}
				else {

					p_sys_cfg->n_input_video_resolution_cx = 0;

					p_sys_cfg->n_input_video_resolution_cy = 0;

					p_sys_cfg->n_input_video_resolution_fps = 0;

					p_sys_cfg->n_input_video_resolution_fps_m = 0;

					p_sys_cfg->n_input_video_resolution_color_colorimetry = 0;

					p_sys_cfg->n_input_video_resolution_color_range = 0;
	
					p_sys_cfg->n_input_video_resolution_color_type = 0;

					p_sys_cfg->b_input_video_resolution_external_sync = FALSE;

					g_p_device->m_nCustomAnalogVideoResolutionProperty = 0;

					g_p_device->m_nCustomAnalogVideoFrameRateProperty = 0;

					g_p_device->m_nCustomAnalogVideoInterleavedProperty = 0;

					g_p_device->m_nCustomAnalogAudioSampleFrequencyProperty = 0;

					g_p_device->m_nAnalogVideoDecoderStatusProperty = 0;
					
					g_p_device->m_nAnalogCopyProtMacrovisionProperty = 0;

					g_p_device->m_nCustomAnalogVideoSdiSingalStatusProperty = 0x00000000;
				}
			}
			#endif
		}
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// PTZ
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
ULONG TP28XX_PTZ_CONVERT_HDA_ACPV1DATA( BYTE data ) // [HUENGPEI] [2018.01.30.V73.FULL] -----> ConvertACPV1Data
{
	ULONG tmp = 0;

	ULONG i = 0;
	for( i = 0 ; i < 8 ; i++ ) {

		tmp <<= 3;

		if( 0x01 & data ) { 
			
			tmp |= 0x06; 
		}
		else {
			
			tmp |= 0x04;
		}
		data >>= 1;
	}
	return tmp;
}

VOID TP28XX_PTZ_SET_HDC_DATA( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, BYTE nIndex, ULONG nValue ) // [HUENGPEI] [2018.01.30.V73.FULL] -----> HDC_SetData
{
	BYTE data = 0;

	BYTE crc = 0;

    if( nValue > 0xFF ) {

        E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 0, 0x07 );
        E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 1, 0xFF );
        E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 2, 0xFF );
        E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 3, 0xFF );
        E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 4, 0xFC );
    }
    else {

		ULONG i = 0 ;
        for( i = 0 ; i < 8 ; i++ ) {
       
            data >>= 1;

            if( 0x80 & nValue ) {
				
				data |= 0x80; 
				
				crc += 0x80;
			}
            nValue <<= 1;
		}
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 0, 0x06 );
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 1, data );
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 2, 0x7F | crc );
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 3, 0xFF );
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 4, 0xFC );
    }
}

VOID TP28XX_PTZ_SET_HDC_QHD_DATA( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, BYTE nIndex, ULONG nValue ) // [HUENGPEI] [2018.01.30.V73.FULL] -----> HDC_QHD_SetData
{	
	BYTE data = 0;

	BYTE crc = 0;

	if( nValue > 0xFF ) {

        E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 0, 0x00 );
        E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 1, 0x03 );
        E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 2, 0xFF );
        E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 3, 0xFF );
        E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 4, 0xFC );
    }
    else {

		ULONG i = 0;
        for( i = 0 ; i < 8 ; i++ ) {
       
            data >>= 1;

            if( 0x80 & nValue ) {
				
				data |= 0x80; 
				
				crc += 0x80;
			}
            nValue <<= 1;
		}
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 0, 0x00 );
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 1, 0x02 );
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 2, data );
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 3, 0x7F | crc );
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 4, 0xFC );
    }
}

VOID TP28XX_PTZ_SET_HDA_ACPV1DATA( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, BYTE nIndex, BYTE nValue ) // [HUENGPEI] [2018.01.30.V73.FULL] -----> HDA_SetACPV1Data 
{
	ULONG n_ptz_pelco = 0;

	ULONG i = 0;
	for( i = 0 ; i < 8 ; i++ ) {
    
		n_ptz_pelco <<= 3;

		if( 0x01 & nValue ) {
			
			n_ptz_pelco |= 0x06;
		}
		else {
			
			n_ptz_pelco |= 0x04;
		}
		nValue >>= 1;
	}
	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 0, (BYTE)((n_ptz_pelco >> 16) & 0xFF) );

	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 1, (BYTE)((n_ptz_pelco >>  8) & 0xFF) );

	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 2, (BYTE)((n_ptz_pelco >>  0) & 0xFF) );
}

VOID TP28XX_PTZ_SET_HDA_ACPV2DATA( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, BYTE nIndex, BYTE nValue ) // [HUENGPEI] [2018.01.30.V73.FULL] -----> HDA_SetACPV2Data
{
	ULONG n_ptz_pelco = 0;

	ULONG i = 0;
	for( i = 0 ; i < 8 ; i++ ) {
    
		n_ptz_pelco <<= 3;

		if( 0x80 & nValue ) {
			
			n_ptz_pelco |= 0x06;
		}
		else {
			
			n_ptz_pelco |= 0x04;
		}
		nValue <<= 1;
	}
	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 0, (BYTE)((n_ptz_pelco >> 16) & 0xFF) );

	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 1, (BYTE)((n_ptz_pelco >>  8) & 0xFF) );

	E2AC4F78FF95428CA3FD05CF4E898465( pDevice, nIndex + 2, (BYTE)((n_ptz_pelco >>  0) & 0xFF) );
}

BYTE TP28XX_PTZ_REVERSE_BYTE( BYTE nValue ) // [HUENGPEI] [2018.01.30.V73.FULL] -----> ReverseByte
{
	static const unsigned char BITREVERSETABLE256[ ] = {

		0x00, 0x80, 0x40, 0xC0, 0x20, 0xA0, 0x60, 0xE0, 0x10, 0x90, 0x50, 0xD0, 0x30, 0xB0, 0x70, 0xF0,
		0x08, 0x88, 0x48, 0xC8, 0x28, 0xA8, 0x68, 0xE8, 0x18, 0x98, 0x58, 0xD8, 0x38, 0xB8, 0x78, 0xF8,
		0x04, 0x84, 0x44, 0xC4, 0x24, 0xA4, 0x64, 0xE4, 0x14, 0x94, 0x54, 0xD4, 0x34, 0xB4, 0x74, 0xF4,
		0x0C, 0x8C, 0x4C, 0xCC, 0x2C, 0xAC, 0x6C, 0xEC, 0x1C, 0x9C, 0x5C, 0xDC, 0x3C, 0xBC, 0x7C, 0xFC,
		0x02, 0x82, 0x42, 0xC2, 0x22, 0xA2, 0x62, 0xE2, 0x12, 0x92, 0x52, 0xD2, 0x32, 0xB2, 0x72, 0xF2,
		0x0A, 0x8A, 0x4A, 0xCA, 0x2A, 0xAA, 0x6A, 0xEA, 0x1A, 0x9A, 0x5A, 0xDA, 0x3A, 0xBA, 0x7A, 0xFA,
		0x06, 0x86, 0x46, 0xC6, 0x26, 0xA6, 0x66, 0xE6, 0x16, 0x96, 0x56, 0xD6, 0x36, 0xB6, 0x76, 0xF6,
		0x0E, 0x8E, 0x4E, 0xCE, 0x2E, 0xAE, 0x6E, 0xEE, 0x1E, 0x9E, 0x5E, 0xDE, 0x3E, 0xBE, 0x7E, 0xFE,
		0x01, 0x81, 0x41, 0xC1, 0x21, 0xA1, 0x61, 0xE1, 0x11, 0x91, 0x51, 0xD1, 0x31, 0xB1, 0x71, 0xF1,
		0x09, 0x89, 0x49, 0xC9, 0x29, 0xA9, 0x69, 0xE9, 0x19, 0x99, 0x59, 0xD9, 0x39, 0xB9, 0x79, 0xF9,
		0x05, 0x85, 0x45, 0xC5, 0x25, 0xA5, 0x65, 0xE5, 0x15, 0x95, 0x55, 0xD5, 0x35, 0xB5, 0x75, 0xF5,
		0x0D, 0x8D, 0x4D, 0xCD, 0x2D, 0xAD, 0x6D, 0xED, 0x1D, 0x9D, 0x5D, 0xDD, 0x3D, 0xBD, 0x7D, 0xFD,
		0x03, 0x83, 0x43, 0xC3, 0x23, 0xA3, 0x63, 0xE3, 0x13, 0x93, 0x53, 0xD3, 0x33, 0xB3, 0x73, 0xF3,
		0x0B, 0x8B, 0x4B, 0xCB, 0x2B, 0xAB, 0x6B, 0xEB, 0x1B, 0x9B, 0x5B, 0xDB, 0x3B, 0xBB, 0x7B, 0xFB,
		0x07, 0x87, 0x47, 0xC7, 0x27, 0xA7, 0x67, 0xE7, 0x17, 0x97, 0x57, 0xD7, 0x37, 0xB7, 0x77, 0xF7,
		0x0F, 0x8F, 0x4F, 0xCF, 0x2F, 0xAF, 0x6F, 0xEF, 0x1F, 0x9F, 0x5F, 0xDF, 0x3F, 0xBF, 0x7F, 0xFF
	};
    return BITREVERSETABLE256[ nValue ];
}

VOID TP2834_SET_PTZ_DATA( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, BYTE chs, BYTE psz_data[ 8 ] ) // [HUENGPEI] [2018.01.30.V73.FULL] -----> TP2802_SET_PTZ_DATA
{
	MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(pDevice->m_pCustomSystemConfigProperty);

	BYTE std = TP2834_STD_TVI;

	BYTE mode = TP2834_INVALID_FORMAT;
	
	if( g_pDevice[ pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE + chs ] ) {

		MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(g_pDevice[ pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE + chs ]->m_pCustomSystemConfigProperty);
			
		F42A18AF66EFF459eA332CA253FFF8A65 * g_p_device = g_pDevice[ pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE + chs ];

		TP2834_SIGNAL_INFO * p_sg_info = &(p_sys_cfg->m_s_tp2834_sg_info);

		if( g_p_device->m_nCustomAnalogVideoPinTopologyProperty == 0 ) { std = TP2834_STD_TVI; }

		if( g_p_device->m_nCustomAnalogVideoPinTopologyProperty == 1 ) { std = TP2834_STD_HDA; }

		if( g_p_device->m_nCustomAnalogVideoPinTopologyProperty == 2 ) { std = TP2834_STD_HDC; }

		if( g_p_device->m_nCustomAnalogVideoPinTopologyProperty >= 3 ) { std = (BYTE)(p_sg_info->std[ chs ]); }

		mode = (BYTE)(p_sg_info->mode[ chs ]);
	}
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "[%02d] CH%02d: std = %02X, mode = %02X, %02X.%02X.%02X.%02X.%02X.%02X.%02X.%02X\n", pDevice->F0C7DF8CDF1004a6eB97071CBDF459ECE, chs, std, mode, psz_data[ 0 ], psz_data[ 1 ], psz_data[ 2 ], psz_data[ 3 ], psz_data[ 4 ], psz_data[ 5 ], psz_data[ 6 ], psz_data[ 7 ]);
		
	if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ||  // PRODUCT_TP2826
		
		p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ||  // PRODUCT_TP2826C
		
		p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ||  // PRODUCT_TP2827
		
		p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { // PRODUCT_TP2827C

		if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ||
			
			p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) {
			
			TP2827C_PTZ_MODE( pDevice, mode, chs, std );
		}
		else {

			TP2826_PTZ_MODE( pDevice, mode, chs, std );
		}
		BYTE i = 0;
		for( i = 0 ; i < 24 ; i++ ) {
			
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x55 + i, 0x00 );
		}
		if( TP2834_STD_TVI == std ) {

            E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x56, 0x02 );

            E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x57, psz_data[ 0 ] );
            E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x58, psz_data[ 1 ] );
            E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x59, psz_data[ 2 ] );
            E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5A, psz_data[ 3 ] );

            E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5C, 0x02 );

            E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5D, psz_data[ 4 ] );
            E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5E, psz_data[ 5 ] );
            E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5F, psz_data[ 6 ] );
            E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x60, psz_data[ 7 ] );

            E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x62, 0x02 );

            E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x63, psz_data[ 0 ] );
            E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x64, psz_data[ 1 ] );
            E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x65, psz_data[ 2 ] );
            E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x66, psz_data[ 3 ] );

            E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x68, 0x02 );

            E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x69, psz_data[ 4 ] );
            E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x6A, psz_data[ 5 ] );
            E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x6B, psz_data[ 6 ] );
            E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x6C, psz_data[ 7 ] );

            TP2826_PTZ_START_TX( pDevice, chs );
		}
		else if( TP2834_STD_HDC == std || TP2834_STD_HDC_DEFAULT == std ) {
		
			if( TP2834_QHD30 == mode || TP2834_QHD25 == mode ) { // PTZ_HDC_QHD

				TP28XX_PTZ_SET_HDC_QHD_DATA( pDevice, 0x56, psz_data[ 0 ] );
				TP28XX_PTZ_SET_HDC_QHD_DATA( pDevice, 0x5C, psz_data[ 1 ] );
				TP28XX_PTZ_SET_HDC_QHD_DATA( pDevice, 0x62, psz_data[ 2 ] );
				TP28XX_PTZ_SET_HDC_QHD_DATA( pDevice, 0x68, psz_data[ 3 ] );

				TP2826_PTZ_START_TX( pDevice, chs );

				TP28XX_PTZ_SET_HDC_QHD_DATA( pDevice, 0x56, psz_data[ 4 ] );
				TP28XX_PTZ_SET_HDC_QHD_DATA( pDevice, 0x5C, psz_data[ 5 ] );
				TP28XX_PTZ_SET_HDC_QHD_DATA( pDevice, 0x62, psz_data[ 6 ] );
				TP28XX_PTZ_SET_HDC_QHD_DATA( pDevice, 0x68, 0xFFFF );

				TP2826_PTZ_START_TX( pDevice, chs );
			}
			else {

				TP28XX_PTZ_SET_HDC_DATA( pDevice, 0x56, psz_data[ 0 ] );
				TP28XX_PTZ_SET_HDC_DATA( pDevice, 0x5C, psz_data[ 1 ] );
				TP28XX_PTZ_SET_HDC_DATA( pDevice, 0x62, psz_data[ 2 ] );
				TP28XX_PTZ_SET_HDC_DATA( pDevice, 0x68, psz_data[ 3 ] );

				TP2826_PTZ_START_TX( pDevice, chs );

				TP28XX_PTZ_SET_HDC_DATA( pDevice, 0x56, psz_data[ 4 ] );
				TP28XX_PTZ_SET_HDC_DATA( pDevice, 0x5C, psz_data[ 5 ] );
				TP28XX_PTZ_SET_HDC_DATA( pDevice, 0x62, psz_data[ 6 ] );
				TP28XX_PTZ_SET_HDC_DATA( pDevice, 0x68, 0xFFFF );

				TP2826_PTZ_START_TX( pDevice, chs );
			}
		}
		else if( TP2834_NTSC == mode || TP2834_PAL == mode ) {

			TP28XX_PTZ_SET_HDA_ACPV1DATA( pDevice, 0x55, 0x00 );
			TP28XX_PTZ_SET_HDA_ACPV1DATA( pDevice, 0x58, 0x00 );
			TP28XX_PTZ_SET_HDA_ACPV1DATA( pDevice, 0x5B, 0x00 );
			TP28XX_PTZ_SET_HDA_ACPV1DATA( pDevice, 0x5E, 0x00 );

			TP2826_PTZ_START_TX( pDevice, chs );

			TP2826_PTZ_START_TX( pDevice, chs );

			TP28XX_PTZ_SET_HDA_ACPV1DATA( pDevice, 0x55, psz_data[ 0 ] );
			TP28XX_PTZ_SET_HDA_ACPV1DATA( pDevice, 0x58, psz_data[ 1 ] );
			TP28XX_PTZ_SET_HDA_ACPV1DATA( pDevice, 0x5B, psz_data[ 2 ] );
			TP28XX_PTZ_SET_HDA_ACPV1DATA( pDevice, 0x5E, psz_data[ 3 ] );

			TP2826_PTZ_START_TX( pDevice, chs );

			TP2826_PTZ_START_TX( pDevice, chs );
		}
	//	else if( TP2834_A1080P30 == mode || TP2834_A1080P25 == mode ) {

		else if( TP2834_1080P30 == mode || TP2834_1080P25 == mode || // PTZ_HDA_1080P
			
				 TP2834_QXGA18 == mode ||                            // PTZ_HDA_3M18

				 TP2834_QXGA30 == mode || TP2834_QXGA25 == mode ) {  // PTZ_HDA_3M25
				 
			TP28XX_PTZ_SET_HDA_ACPV2DATA( pDevice, 0x58, 0x00 );
			TP28XX_PTZ_SET_HDA_ACPV2DATA( pDevice, 0x5E, 0x00 );
			TP28XX_PTZ_SET_HDA_ACPV2DATA( pDevice, 0x64, 0x00 );
			TP28XX_PTZ_SET_HDA_ACPV2DATA( pDevice, 0x6A, 0x00 );

			TP2826_PTZ_START_TX( pDevice, chs );

			TP28XX_PTZ_SET_HDA_ACPV2DATA( pDevice, 0x58, psz_data[ 0 ] );
			TP28XX_PTZ_SET_HDA_ACPV2DATA( pDevice, 0x5E, psz_data[ 1 ] );
			TP28XX_PTZ_SET_HDA_ACPV2DATA( pDevice, 0x64, psz_data[ 2 ] );
			TP28XX_PTZ_SET_HDA_ACPV2DATA( pDevice, 0x6A, psz_data[ 3 ] );

			TP2826_PTZ_START_TX( pDevice, chs );
		}
	//	else if( TP2834_A720P30 == mode || TP2834_A720P25 == mode ) {

		else if( TP2834_720P30 == mode || TP2834_720P25 == mode ||
			
				 TP2834_720P30V2 == mode || TP2834_720P25V2 == mode ||
			
				 TP2834_720P60 == mode || TP2834_720P50 == mode ) {

			TP28XX_PTZ_SET_HDA_ACPV1DATA( pDevice, 0x55, 0x00 );
			TP28XX_PTZ_SET_HDA_ACPV1DATA( pDevice, 0x58, 0x00 );
			TP28XX_PTZ_SET_HDA_ACPV1DATA( pDevice, 0x5B, 0x00 );
			TP28XX_PTZ_SET_HDA_ACPV1DATA( pDevice, 0x5E, 0x00 );

			TP2826_PTZ_START_TX( pDevice, chs );

			TP28XX_PTZ_SET_HDA_ACPV1DATA( pDevice, 0x55, psz_data[ 0 ] );
			TP28XX_PTZ_SET_HDA_ACPV1DATA( pDevice, 0x58, psz_data[ 1 ] );
			TP28XX_PTZ_SET_HDA_ACPV1DATA( pDevice, 0x5B, psz_data[ 2 ] );
			TP28XX_PTZ_SET_HDA_ACPV1DATA( pDevice, 0x5E, psz_data[ 3 ] );

			TP2826_PTZ_START_TX( pDevice, chs );
		}
		else if( TP2834_QHD30 == mode || TP2834_QHD25 == mode || TP2834_5M20 == mode || // PTZ_HDA_4M25
			
				 TP2834_QHD15 == mode || TP2834_5M12 == mode ) {                        // PTZ_HDA_4M15

			ULONG i = 0;
			for( i = 0 ; i < 8 ; i++ ) {

				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x6E, 0x00 );
			}
			TP2826_PTZ_START_TX( pDevice, chs );

			for( i = 0 ; i < 8 ; i++ ) {

				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x6E, TP28XX_PTZ_REVERSE_BYTE( psz_data[ i ] ) );
			}
			TP2826_PTZ_START_TX( pDevice, chs );
		}
		else {

			;
		}
	}
	else { // PRODUCT_TP2834

		TP2834_PTZ_MODE( pDevice, mode, chs, std );

		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x00 ); // BACK#0

		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x56 + chs * 10, 0x00 );
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x57 + chs * 10, 0x00 );
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5B + chs * 10, 0x00 );
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5C + chs * 10, 0x00 );

		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x10 ); // BACK#1

		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x56 + chs * 10, 0x00 );
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x57 + chs * 10, 0x00 );
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5B + chs * 10, 0x00 );
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5C + chs * 10, 0x00 );
		
		if( TP2834_STD_TVI == std ) {

			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x00 );

			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x56 + chs * 10, 0x02 );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x57 + chs * 10, psz_data[ 0 ] );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x58 + chs * 10, psz_data[ 1 ] );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x59 + chs * 10, psz_data[ 2 ] );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5A + chs * 10, psz_data[ 3 ] );

			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5B + chs * 10, 0x02 );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5C + chs * 10, psz_data[ 4 ] );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5D + chs * 10, psz_data[ 5 ] );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5E + chs * 10, psz_data[ 6 ] );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5F + chs * 10, psz_data[ 7 ] );

			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x10 );

			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x56 + chs * 10, 0x02 );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x57 + chs * 10, psz_data[ 0 ] );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x58 + chs * 10, psz_data[ 1 ] );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x59 + chs * 10, psz_data[ 2 ] );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5A + chs * 10, psz_data[ 3 ] );

			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5B + chs * 10, 0x02 );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5C + chs * 10, psz_data[ 4 ] );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5D + chs * 10, psz_data[ 5 ] );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5E + chs * 10, psz_data[ 6 ] );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5F + chs * 10, psz_data[ 7 ] );

			TP2834_PTZ_START_TX( pDevice, chs );
		}
		else if( TP2834_STD_HDC == std || TP2834_STD_HDC_DEFAULT == std ) {
		
			if( TP2834_QHD30 == mode || TP2834_QHD25 == mode ) { // PTZ_HDC_QHD

				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x00 );

				TP28XX_PTZ_SET_HDC_QHD_DATA( pDevice, 0x56 + chs * 10, psz_data[ 0 ] );
				TP28XX_PTZ_SET_HDC_QHD_DATA( pDevice, 0x5B + chs * 10, psz_data[ 1 ] );

				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x10 );

				TP28XX_PTZ_SET_HDC_QHD_DATA( pDevice, 0x56 + chs * 10, psz_data[ 2 ] );
				TP28XX_PTZ_SET_HDC_QHD_DATA( pDevice, 0x5B + chs * 10, psz_data[ 3 ] );

				TP2834_PTZ_START_TX( pDevice, chs );

				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x00 );

				TP28XX_PTZ_SET_HDC_QHD_DATA( pDevice, 0x56 + chs * 10, psz_data[ 4 ] );
				TP28XX_PTZ_SET_HDC_QHD_DATA( pDevice, 0x5B + chs * 10, psz_data[ 5 ] );

				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x10 );

				TP28XX_PTZ_SET_HDC_QHD_DATA( pDevice, 0x56 + chs * 10, psz_data[ 6 ] );
				TP28XX_PTZ_SET_HDC_QHD_DATA( pDevice, 0x5B + chs * 10, 0xFFFF );

				TP2834_PTZ_START_TX( pDevice, chs );
			}
			else {

				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x00 );

				TP28XX_PTZ_SET_HDC_DATA( pDevice, 0x56 + chs * 10, psz_data[ 0 ] );
				TP28XX_PTZ_SET_HDC_DATA( pDevice, 0x5B + chs * 10, psz_data[ 1 ] );

				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x10 );

				TP28XX_PTZ_SET_HDC_DATA( pDevice, 0x56 + chs * 10, psz_data[ 2 ] );
				TP28XX_PTZ_SET_HDC_DATA( pDevice, 0x5B + chs * 10, psz_data[ 3 ] );

				TP2834_PTZ_START_TX( pDevice, chs );

				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x00 );

				TP28XX_PTZ_SET_HDC_DATA( pDevice, 0x56 + chs * 10, psz_data[ 4 ] );
				TP28XX_PTZ_SET_HDC_DATA( pDevice, 0x5B + chs * 10, psz_data[ 5 ] );

				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x10 );

				TP28XX_PTZ_SET_HDC_DATA( pDevice, 0x56 + chs * 10, psz_data[ 6 ] );
				TP28XX_PTZ_SET_HDC_DATA( pDevice, 0x5B + chs * 10, 0xFFFF );

				TP2834_PTZ_START_TX( pDevice, chs );
			}
		}
		else if( TP2834_NTSC == mode || TP2834_PAL == mode ) {

			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x00 );

			ULONG tmp = TP28XX_PTZ_CONVERT_HDA_ACPV1DATA( 0x00 );

			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x7f + chs *  2, (BYTE)((tmp >> 16) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x56 + chs * 10, (BYTE)((tmp >>  8) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x57 + chs * 10, (BYTE)((tmp >>  0) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x58 + chs * 10, (BYTE)((tmp >> 16) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x59 + chs * 10, (BYTE)((tmp >>  8) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5A + chs * 10, (BYTE)((tmp >>  0) & 0xFF) );

			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x80 + chs *  2, (BYTE)((tmp >> 16) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5B + chs * 10, (BYTE)((tmp >>  8) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5C + chs * 10, (BYTE)((tmp >>  0) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5D + chs * 10, (BYTE)((tmp >> 16) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5E + chs * 10, (BYTE)((tmp >>  8) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5F + chs * 10, (BYTE)((tmp >>  0) & 0xFF) );
		
			TP2834_PTZ_START_TX( pDevice, chs );

			tmp = TP28XX_PTZ_CONVERT_HDA_ACPV1DATA( psz_data[ 0 ] );

			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x7f + chs *  2, (BYTE)((tmp >> 16) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x56 + chs * 10, (BYTE)((tmp >>  8) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x57 + chs * 10, (BYTE)((tmp >>  0) & 0xFF) );
		
			tmp = TP28XX_PTZ_CONVERT_HDA_ACPV1DATA( psz_data[ 1 ] );

			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x58 + chs * 10, (BYTE)((tmp >> 16) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x59 + chs * 10, (BYTE)((tmp >>  8) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5A + chs * 10, (BYTE)((tmp >>  0) & 0xFF) );
		
			tmp = TP28XX_PTZ_CONVERT_HDA_ACPV1DATA( psz_data[ 2 ] );

			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x80 + chs *  2, (BYTE)((tmp >> 16) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5B + chs * 10, (BYTE)((tmp >>  8) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5C + chs * 10, (BYTE)((tmp >>  0) & 0xFF) );
		
			tmp = TP28XX_PTZ_CONVERT_HDA_ACPV1DATA( psz_data[ 3 ] );

			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5D + chs * 10, (BYTE)((tmp >> 16) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5E + chs * 10, (BYTE)((tmp >>  8) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5F + chs * 10, (BYTE)((tmp >>  0) & 0xFF) );
		
			TP2834_PTZ_START_TX( pDevice, chs );
		}
	//	else if( TP2834_A1080P30 == mode || TP2834_A1080P25 == mode ) {

		else if( TP2834_1080P30 == mode || TP2834_1080P25 == mode ||                    // PTZ_HDA_1080P
			
				 TP2834_QXGA18 == mode ||                                               // PTZ_HDA_3M18

				 TP2834_QXGA30 == mode || TP2834_QXGA25 == mode ||                      // PTZ_HDA_3M25
	
				 TP2834_QHD30 == mode || TP2834_QHD25 == mode || TP2834_5M20 == mode || // PTZ_HDA_4M25
			
				 TP2834_QHD15 == mode || TP2834_5M12 == mode ) {                        // PTZ_HDA_4M15	
		        
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x00 );

			TP28XX_PTZ_SET_HDA_ACPV2DATA( pDevice, 0x58 + chs * 10, 0x00 );
			TP28XX_PTZ_SET_HDA_ACPV2DATA( pDevice, 0x5D + chs * 10, 0x00 );
		
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x10 );

			TP28XX_PTZ_SET_HDA_ACPV2DATA( pDevice, 0x58 + chs * 10, 0x00 );
			TP28XX_PTZ_SET_HDA_ACPV2DATA( pDevice, 0x5D + chs * 10, 0x00 );
		
	//      TP2834_PTZ_START_TX( pDevice, chs ); // REMOVE IT BY PETER
		
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x00 );

			TP28XX_PTZ_SET_HDA_ACPV2DATA( pDevice, 0x58 + chs * 10, psz_data[ 0 ] );
			TP28XX_PTZ_SET_HDA_ACPV2DATA( pDevice, 0x5D + chs * 10, psz_data[ 1 ] );
		
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x10 );

			TP28XX_PTZ_SET_HDA_ACPV2DATA( pDevice, 0x58 + chs * 10, psz_data[ 2 ] );
			TP28XX_PTZ_SET_HDA_ACPV2DATA( pDevice, 0x5D + chs * 10, psz_data[ 3 ] );
		
			TP2834_PTZ_START_TX( pDevice, chs );
		}
	//	else if( TP2834_A720P30 == mode || TP2834_A720P25 == mode ) {

		else if( TP2834_720P30 == mode || TP2834_720P25 == mode ||
			
				 TP2834_720P30V2 == mode || TP2834_720P25V2 == mode ||
			
				 TP2834_720P60 == mode || TP2834_720P50 == mode ) {

			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x00 );

			ULONG tmp = TP28XX_PTZ_CONVERT_HDA_ACPV1DATA( 0x00 );

			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x7f + chs *  2, (BYTE)((tmp >> 16) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x56 + chs * 10, (BYTE)((tmp >>  8) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x57 + chs * 10, (BYTE)((tmp >>  0) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x58 + chs * 10, (BYTE)((tmp >> 16) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x59 + chs * 10, (BYTE)((tmp >>  8) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5A + chs * 10, (BYTE)((tmp >>  0) & 0xFF) );

			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x80 + chs *  2, (BYTE)((tmp >> 16) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5B + chs * 10, (BYTE)((tmp >>  8) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5C + chs * 10, (BYTE)((tmp >>  0) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5D + chs * 10, (BYTE)((tmp >> 16) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5E + chs * 10, (BYTE)((tmp >>  8) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5F + chs * 10, (BYTE)((tmp >>  0) & 0xFF) );
		
			TP2834_PTZ_START_TX( pDevice, chs );

			tmp = TP28XX_PTZ_CONVERT_HDA_ACPV1DATA( psz_data[ 0 ] );

			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x7f + chs *  2, (BYTE)((tmp >> 16) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x56 + chs * 10, (BYTE)((tmp >>  8) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x57 + chs * 10, (BYTE)((tmp >>  0) & 0xFF) );
		
			tmp = TP28XX_PTZ_CONVERT_HDA_ACPV1DATA( psz_data[ 1 ] );

			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x58 + chs * 10, (BYTE)((tmp >> 16) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x59 + chs * 10, (BYTE)((tmp >>  8) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5A + chs * 10, (BYTE)((tmp >>  0) & 0xFF) );
		
			tmp = TP28XX_PTZ_CONVERT_HDA_ACPV1DATA( psz_data[ 2 ] );

			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x80 + chs *  2, (BYTE)((tmp >> 16) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5B + chs * 10, (BYTE)((tmp >>  8) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5C + chs * 10, (BYTE)((tmp >>  0) & 0xFF) );
		
			tmp = TP28XX_PTZ_CONVERT_HDA_ACPV1DATA( psz_data[ 3 ] );

			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5D + chs * 10, (BYTE)((tmp >> 16) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5E + chs * 10, (BYTE)((tmp >>  8) & 0xFF) );
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x5F + chs * 10, (BYTE)((tmp >>  0) & 0xFF) );
		
			TP2834_PTZ_START_TX( pDevice, chs );
		}
	}
}

VOID TP2834_GET_PTZ_DATA( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, BYTE chs, BYTE * psz_data ) // [HUENGPEI] [2018.01.30.V73.FULL] -----> TP2802_GET_PTZ_DATA
{
	MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(pDevice->m_pCustomSystemConfigProperty);
			
	if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826  ||  // PRODUCT_TP2826

		p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ||  // PRODUCT_TP2826C

		p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827  ||  // PRODUCT_TP2827

		p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { // PRODUCT_TP2827C

		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, chs ); // F7F93DF8A9ECE49c1884C75ADC18648B7 SWITCH

		psz_data[ 0 ] = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x8C ); // LINE1

		psz_data[ 1 ] = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x8D );

		psz_data[ 2 ] = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x8E );

		psz_data[ 3 ] = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x8F );

		psz_data[ 4 ] = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x92 ); // LINE2

		psz_data[ 5 ] = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x93 );

		psz_data[ 6 ] = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x94 );

		psz_data[ 7 ] = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x95 );
	}
	else { // PRODUCT_TP2834
		
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x40, 0x00 ); // F7F93DF8A9ECE49c1884C75ADC18648B7#00

		psz_data[ 0 ] = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x8C + chs * 10 ); // LINE1

		psz_data[ 1 ] = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x8D + chs * 10 );

		psz_data[ 2 ] = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x8E + chs * 10 );

		psz_data[ 3 ] = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x8F + chs * 10 );

		psz_data[ 4 ] = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x91 + chs * 10 ); // LINE2

		psz_data[ 5 ] = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x92 + chs * 10 );

		psz_data[ 6 ] = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x93 + chs * 10 );

		psz_data[ 7 ] = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x94 + chs * 10 );
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// 
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
VOID TP28XX_SYSCLK_V1( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, BYTE chs ) // [HUENGPEI] [2018.01.30.V73.FULL] -----> tp282x_SYSCLK_V1
{
	MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(pDevice->m_pCustomSystemConfigProperty);
	
	// SDR_1CH
	// 
	if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834 ||   // PRODUCT_TP2834
		
		p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827 ||   // PRODUCT_TP2827
		
		p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { // PRODUCT_TP2827C

		if( chs >= 4 ) { 
            
			ULONG i = 0;
			for( i = 0 ; i < 4 ; i++ ) {
			
				BYTE R = E337333B92284BE3A3A414AA44ED9827( pDevice, TP2834_CLK_ADDR[ i ] ); 
				
				R &= TP2834_CLK_AND[ i ];
    
				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, TP2834_CLK_ADDR[ i ], R );
			}
		}
		else {
			
			ULONG i = chs;
			
			BYTE R = E337333B92284BE3A3A414AA44ED9827( pDevice, TP2834_CLK_ADDR[ i ] ); 
				
			R &= TP2834_CLK_AND[ i ];
    
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, TP2834_CLK_ADDR[ i ], R );
		}
	}
	else if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826 ||   // PRODUCT_TP2826
		
			 p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { // PRODUCT_TP2826C
		
		if( chs >= 4 ) { 
            
			ULONG i = 0;
			for( i = 0 ; i < 2 ; i++ ) {
			
				BYTE R = E337333B92284BE3A3A414AA44ED9827( pDevice, TP2834_CLK_ADDR[ i * 2 ] ); 
				
				R &= TP2834_CLK_AND[ i * 2 ];
    
				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, TP2834_CLK_ADDR[ i * 2 ], R );
			}
		}
		else {
			
			ULONG i = chs % 2;
			
			BYTE R = E337333B92284BE3A3A414AA44ED9827( pDevice, TP2834_CLK_ADDR[ i * 2 ] ); 
				
			R &= TP2834_CLK_AND[ i * 2 ];
    
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, TP2834_CLK_ADDR[ i * 2 ], R );
		}
	}
}

VOID TP28XX_SYSCLK_V2( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, BYTE chs ) // [HUENGPEI] [2018.01.30.V73.FULL] -----> tp282x_SYSCLK_V2
{
	MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(pDevice->m_pCustomSystemConfigProperty);
		
	// SDR_1CH
	// 
	if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834 ||   // PRODUCT_TP2834
		
		p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827 ||   // PRODUCT_TP2827
		
		p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { // PRODUCT_TP2827C

		if( chs >= 4 ) {
            
			ULONG i = 0;
			for( i = 0 ; i < 4 ; i++ ) {
			
				BYTE R = E337333B92284BE3A3A414AA44ED9827( pDevice, TP2834_CLK_ADDR[ i ] ); 
				
				R &= TP2834_CLK_AND[ i ];

				R |= TP2834_CLK_MODE[ i ];
    
				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, TP2834_CLK_ADDR[ i ], R );
			}
		}
		else {
			
			ULONG i = chs;
			
			BYTE R = E337333B92284BE3A3A414AA44ED9827( pDevice, TP2834_CLK_ADDR[ i ] ); 
				
			R &= TP2834_CLK_AND[ i ];

			R |= TP2834_CLK_MODE[ i ];
    
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, TP2834_CLK_ADDR[ i ], R );
		}
	}
	else if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826 ||   // PRODUCT_TP2826
		
			 p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { // PRODUCT_TP2826C
			
		if( chs >= 4 ) {
            
			ULONG i = 0;
			for( i = 0 ; i < 2 ; i++ ) {
			
				BYTE R = E337333B92284BE3A3A414AA44ED9827( pDevice, TP2834_CLK_ADDR[ i * 2 ] ); 
				
				R &= TP2834_CLK_AND[ i * 2 ];

				R |= TP2834_CLK_MODE[ i * 2 ];
    
				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, TP2834_CLK_ADDR[ i * 2 ], R );
			}
		}
		else {
			
			ULONG i = chs % 2;
			
			BYTE R = E337333B92284BE3A3A414AA44ED9827( pDevice, TP2834_CLK_ADDR[ i * 2 ] ); 
				
			R &= TP2834_CLK_AND[ i * 2 ];

			R |= TP2834_CLK_MODE[ i * 2 ];
    
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, TP2834_CLK_ADDR[ i * 2 ], R );
		}
	}
	else {

		;
	}
}

VOID TP28XX_SYSCLK_V3( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, BYTE chs ) // [HUENGPEI] [2018.01.30.V73.FULL] -----> tp282x_SYSCLK_V3
{
	MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(pDevice->m_pCustomSystemConfigProperty);
		
	// SDR_1CH
	// 
	if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2834 ) { // PRODUCT_TP2834

		;
	}
	else if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827 ||   // PRODUCT_TP2827
		
			 p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2827C ) { // PRODUCT_TP2827C
			
		BYTE R35 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x35 ); R35 |= 0x40;
		
		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, R35 ); 

		if( chs >= 4 ) {

			ULONG i = 0;
			for( i = 0 ; i < 4 ; i++ ) {
			
				BYTE R = E337333B92284BE3A3A414AA44ED9827( pDevice, TP2834_CLK_ADDR[ i ] ); 
				
				R &= TP2834_CLK_AND[ i ];
    
				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, TP2834_CLK_ADDR[ i ], R );
			}
		}
		else {
			
			ULONG i = chs;
			
			BYTE R = E337333B92284BE3A3A414AA44ED9827( pDevice, TP2834_CLK_ADDR[ i ] ); 
				
			R &= TP2834_CLK_AND[ i ];
    
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, TP2834_CLK_ADDR[ i ], R );
		}
	}
	else if( p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826 ||   // PRODUCT_TP2826
		
			 p_sys_cfg->n_is_techpoint_support == PRODUCT_TP2826C ) { // PRODUCT_TP2826C
					
		BYTE R35 = E337333B92284BE3A3A414AA44ED9827( pDevice, 0x35 ); R35 |= 0x40;

		E2AC4F78FF95428CA3FD05CF4E898465( pDevice, 0x35, R35 ); 

		if( chs >= 4 ) {
            
			ULONG i = 0;
			for( i = 0 ; i < 2 ; i++ ) {
			
				BYTE R = E337333B92284BE3A3A414AA44ED9827( pDevice, TP2834_CLK_ADDR[ i * 2 ] ); 
				
				R &= TP2834_CLK_AND[ i * 2 ];
    
				E2AC4F78FF95428CA3FD05CF4E898465( pDevice, TP2834_CLK_ADDR[ i * 2 ], R );
			}
		}
		else {
			
			ULONG i = chs % 2;
			
			BYTE R = E337333B92284BE3A3A414AA44ED9827( pDevice, TP2834_CLK_ADDR[ i * 2 ] ); 
				
			R &= TP2834_CLK_AND[ i * 2 ];
    
			E2AC4F78FF95428CA3FD05CF4E898465( pDevice, TP2834_CLK_ADDR[ i * 2 ], R );
		}
	}
	else {

		;
	}
}
