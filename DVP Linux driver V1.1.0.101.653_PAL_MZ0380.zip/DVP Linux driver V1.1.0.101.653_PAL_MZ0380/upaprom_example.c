#include "upaprom_example.h"

void MySleep( int ms )	//unit: 1/1000 second
{
	F6B9E557A4BA24ffd926B820B836289C8_100NS( (ms * 10000) );
}

//devaddr = 8 bit I2C chip address
int i2c_write_bytes( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, unsigned char devaddr, unsigned char *txbuf, unsigned int txcount)
{	
	MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(pDevice->m_pCustomSystemConfigProperty);
	
	if( p_sys_cfg->n_mcu_version == 0)
	{
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "i2c_write_bytes, mcu version = 0 \n");
		return 0;
	}
	
	return MZ0380_ComboAnalogVideoDecoderRegisterX( pDevice, 0, devaddr, txbuf, txcount, 0 );

	//return 1;
}

//devaddr = 8 bit I2C chip address
int i2c_read_bytes( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, unsigned char devaddr, unsigned char *rxbuf, unsigned int rxcount)
{
	MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(pDevice->m_pCustomSystemConfigProperty);
	
	if( p_sys_cfg->n_mcu_version == 0)
	{
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "i2c_read_bytes, mcu version = 0 \n");
		return 0;
	}

	return MZ0380_ComboAnalogVideoDecoderRegisterX( pDevice, 0,  devaddr, rxbuf, rxcount, 1 );

	//return 1;
}

int mcu_i2c_access(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, unsigned char devaddr, unsigned int txcount, unsigned char *txbuf, unsigned int rxcount, unsigned char *rxbuf)
{
	unsigned char i2c_txcount = 0;
	unsigned char i2c_rxcount = 0;
	unsigned char i2c_txbuf[32] = {0};
	unsigned char i2c_rxbuf[32] = {0};

	MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(pDevice->m_pCustomSystemConfigProperty);
	
	if( p_sys_cfg->n_mcu_version == 0)
	{
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "mcu_i2c_access, mcu version = 0 \n");
		return 0;
	}
	devaddr <<= 1;
	if(txcount != 0)
	{
		if(rxcount != 0)
		{
			i2c_txcount = txcount+3;
			i2c_txbuf[0] = 0x66;
			i2c_txbuf[1] = devaddr|1;
			i2c_txbuf[2] = (unsigned char)rxcount;
			RtlCopyMemory( i2c_txbuf+3, txbuf, txcount );
		//	memcpy(i2c_txbuf+3, txbuf, txcount);
		}
		else
		{
			i2c_txcount = txcount+2;
			i2c_txbuf[0] = 0x66;
			i2c_txbuf[1] = devaddr;
			RtlCopyMemory( i2c_txbuf+2, txbuf, txcount );
		//	memcpy(i2c_txbuf+2, txbuf, txcount);
		}

		if( !i2c_write_bytes(pDevice, i2c_txbuf[0], i2c_txbuf+1, i2c_txcount-1 ) ) {

			F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "mcu_i2c_access() i2c_write_bytes error!!! \n");

			return 0;
		}
	}
	if(rxcount != 0)
	{
		if(txcount != 0)
			MySleep(150);				//must be sleep, until the MCU handle this request
		i2c_rxcount = (unsigned char)rxcount;
		i2c_txbuf[0] = 0x66;
		RtlFillMemory( i2c_rxbuf, rxcount, 0 );
	//	memset(i2c_rxbuf, 0, rxcount);
		if( !i2c_read_bytes(pDevice, i2c_txbuf[0], i2c_rxbuf, i2c_rxcount ) ) {

			F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "mcu_i2c_access() i2c_read_bytes error!!! \n");

			return 0;
		}
		RtlCopyMemory( rxbuf, i2c_rxbuf, rxcount );
	//	memcpy(rxbuf, i2c_rxbuf, rxcount);
	}
	return 1;
}

int WaitI2CReady_LDROM(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, int count)
{
#if 1
	MySleep(15);
	return 0;
#else
	int i;
	unsigned char rxbuf[1];


	i = 0;
	while(1)
	{
	    i2c_read_bytes(pDevice, 0x60, rxbuf, 1);
		if(rxbuf[0] == 0)
		{
			//OutputDebugString("I2C ready \n");
		    break;
		}
		i++;
		if(i > 20)
		{
			F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "LDROM I2C Time out \n");
			break;
		}
		MySleep(1);
	}
	return 0;
#endif
}


int i2c_access_LDROM(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, unsigned char devaddr, unsigned int txcount, unsigned char *txbuf, unsigned int rxcount, unsigned char *rxbuf)
{
	if(txcount != 0)
	{
		if( !i2c_write_bytes( pDevice, 0x6c, txbuf, txcount ) ) 
		{
				return FALSE;
		}
	}
	if(rxcount != 0)
	{
		WaitI2CReady_LDROM( pDevice, txcount + 2 );
		if( !i2c_read_bytes( pDevice, 0x6c, rxbuf, rxcount ) ) 
		{
			return FALSE;
		}
		F966EAAB748564259849CBD3F3D6C48A7( KERN_INFO, "i2c_access_LDROM read 0x%x, 0x%x, 0x%x \n", rxbuf[0], rxbuf[1], rxbuf[2]);
	}
	return TRUE;
}

unsigned char UpdateAP_Tx[64];
unsigned char UpdateAP_Rx[64];
#define CMD_UPDATE_APROM	0xA0
#define CMD_UPDATE_CONFIG	0xA1
#define CMD_ERASE_ALL		0xA2
#define CMD_GET_FWVER		0xA3
#define CMD_RUN_APROM		0xA4
#define CMD_RUN_LDROM		0xA5
#define CMD_RESET			0xA6
#define CMD_PAYLOAD_END		0xA7
#define CMD_GET_ROMINFO		0xA8
#define CMD_GET_DEVICEID	0xA9
#define CMD_GET_FLASHMODE 	0xAA
#define CMD_BLANK_CHECK		0xAB
#define CMD_IDLE_CHECK		0xAC
#define CMD_I2C_TEST		0xAD
#define CMD_DUMMY			0xFF

struct D_CMD_UPDATE_CONFIG
{
	unsigned char commandid;
	unsigned char char_0xaa;
	unsigned char char_0x55;
	unsigned char char_0x44;
	unsigned int  config0;		//must be 4 alignment 
	unsigned int  config1;		//must be 4 alignment 
};

struct D_CMD_GET_ROMINFO
{
	unsigned char firmversion;
	unsigned char pdid;
	unsigned char reserve1;		//0xaa
	unsigned char reserve2;		//0x55;
	unsigned int  config0;		//must be 4 alignment 
	unsigned int  config1;		//must be 4 alignment 
	unsigned int  aprom_checksum;//must be 4 alignment 
	unsigned int  aprom_len;	//must be 4 alignment 
};

struct D_CMD_UPDATE_APROM
{
	unsigned char commandid;
	unsigned char currentpage;	//512 bytes per page;
	unsigned char payloadlen;
	unsigned char payload[61];
};

struct D_CMD_PAYLOAD_END
{
	unsigned char commandid;
	unsigned char payloadlen;
	unsigned char char_0xaa;
	unsigned char char_0x55;
	unsigned int  pagechecksum;//must be 4 alignment 
};

#define AP_SIZE		0x8000
#define MCU_PAGE_SIZE	0x200
#define UPDATE_SUCCESS		0
#define FAIL_JMP_LDROM		1
#define FAIL_READ_BIN_FILE	2
#define FAIL_ERASE_APROM	3
#define FAIL_BLANKCHECK		4
#define FAIL_UPDATE_PAGE	5
#define FAIL_CHECKSUM		6
#define FAIL_MCU_NOT_EXIST  7
#define FAIL_JMP_APROM		8
#define FAIL_BUSY_LDROM		9
#define FAIL_PAGE_TRANSFER	10

int UpdateOnePage(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, unsigned int pageno, unsigned char *fbuf, unsigned int pagesize)
{
//#define MAX_I2C_TX_SIZE		64	//ADDED FOR H56
#define MAX_I2C_TX_SIZE		16
	unsigned int size, i;
	struct D_CMD_UPDATE_APROM s_update;
	struct D_CMD_PAYLOAD_END s_pageend;
	unsigned char *ptemp;

	s_pageend.commandid = CMD_PAYLOAD_END;
	s_pageend.payloadlen = (BYTE)pagesize;
	s_pageend.char_0xaa = 0xaa;
	s_pageend.char_0x55 = 0x55;
	s_pageend.pagechecksum = 0;

	ptemp = fbuf;
	s_update.commandid = CMD_UPDATE_APROM;
	s_update.currentpage = (BYTE)pageno;
	while(1)
	{
		if(pagesize > MAX_I2C_TX_SIZE-3)
			size = MAX_I2C_TX_SIZE-3;
		else
			size = pagesize;
		s_update.payloadlen = (BYTE)size;
		for(i = 0;i < size;i++)
		{
			s_update.payload[i] = *ptemp;
			s_pageend.pagechecksum += *ptemp;
			ptemp++;
		}
		pagesize -= size;
//		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "page no %d, size %d\n", pageno, size);
		i2c_access_LDROM(pDevice, 0x36, MAX_I2C_TX_SIZE, (unsigned char *)&s_update, 0, UpdateAP_Rx);
		if(pagesize == 0)
			break;
		s_update.currentpage = 0xff;	//means not the start of page
	}
	i2c_access_LDROM(pDevice, 0x36, sizeof(struct D_CMD_PAYLOAD_END), (unsigned char *)&s_pageend, 0, UpdateAP_Rx);
	i = 0;
	MySleep(100);
		return 0;
}

int CheckLD_ROM_Idle(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice)
{
	int i;

	i = 0;
	while(1)
	{
		UpdateAP_Tx[0] = CMD_IDLE_CHECK;
		UpdateAP_Rx[0] = 0x11;
#if 0
		i2c_access_LDROM(pDevice,0x36, 1, UpdateAP_Tx, 3, UpdateAP_Rx);
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::CheckLD_ROM_Idle (0x%x, 0x%x, 0x%x)\n", UpdateAP_Rx[0], UpdateAP_Rx[1], UpdateAP_Rx[2]);
		if((UpdateAP_Rx[0] == 0xab && UpdateAP_Rx[1] == 0xcd && UpdateAP_Rx[2] == 0xef) ||
		   (UpdateAP_Rx[0] == 0xab && UpdateAP_Rx[1] == 0xe6 && UpdateAP_Rx[2] == 0xff))
#else
		i2c_access_LDROM(pDevice,0x36, 1, UpdateAP_Tx, 1, UpdateAP_Rx);
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::CheckLD_ROM_Idle (0x%x)\n", UpdateAP_Rx[0]);
		if(UpdateAP_Rx[0] == 0xab)
#endif
		{
			break;
		}
		MySleep(50);
		i++;
		if(i > 5)
			return  1;	
	}
	return 0;
}

//1.i2c_access()
//		if(devaddr == 0x55 && rxbuf[0] == 0x45 && rxbuf[1] == 0x67 && rxbuf[2] == 0x89)
//		{
//			//it's special key, for the MCU is busy in starttimer(), not in the I2C loop 
//			return ret;
//		}
//
//2.i2c_access_LDROM()
//#define BAD_MCU		1

int TestI2C(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice)
{
	int i, j, value, sendlength;
	
	i = 0;
	while(1)
	{
		UpdateAP_Tx[0] = CMD_I2C_TEST;
		for(j = 0;j < i;j++)
			memset(UpdateAP_Tx+1, (BYTE)(0xaa+i+j), 16);
		memset(UpdateAP_Rx, 0, 16);
		sendlength = (i&0xf)+2;
		if(sendlength > 16)
			sendlength = 16;
		i2c_access_LDROM(pDevice,0x36, sendlength, UpdateAP_Tx, sendlength, UpdateAP_Rx);
		for(j = 0;j < sendlength;j++)
		{
			if(UpdateAP_Rx[j] != UpdateAP_Tx[j])
				break;
		}
		if(j == sendlength)
				{
//			F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::TestI2C success %d", sendlength);
		}
		else
		{
			F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::TestI2C fail %d", sendlength);
		}
		i++;
		if(i > 20000)
			return  1;	
	}
	return 0;
}

int UpdateAPROM(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice,unsigned char *bin_name, unsigned char * read_buf, unsigned int flength)
{
	struct D_CMD_GET_ROMINFO rominfo;
	unsigned char *ptemp;
	unsigned int currentpage;
	unsigned int total_checksum;
	unsigned int i;
	unsigned int tempsize; 
	

//Action 1:
//set those pins to the following values, and let LDROM get into update the APROM
	if(CheckLD_ROM_Idle(pDevice) == 1)
	{

		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "NO MCU ....\n");
		return 1;	
	}
	else
	{
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "Already in the LD ROM \n");
	}

	MySleep(500);
//	TestI2C(pDevice);

//Erase AP ROM, key point is here
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "In Erase All... \n");
	UpdateAP_Tx[0] = CMD_ERASE_ALL;
	i2c_access_LDROM(pDevice,0x36, 1, UpdateAP_Tx, 0, 0);
	MySleep(2500);		//for a new MCU, 2014, 08, 05
//put get checksum here to save time
	ptemp = read_buf;
	total_checksum = 0;
	for(i = 0;i < flength;i++)
		total_checksum += *ptemp++;
    F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "Out Erase All... \n");

//Action 7
//Update the AP ROM with per page (512 bytes)
	currentpage = 0;
	ptemp = read_buf;
	tempsize = flength;
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "Update File Length %d\n", flength);
	while(1)
	{
		int res;

		if(tempsize >= MCU_PAGE_SIZE)
			res = UpdateOnePage(pDevice,currentpage, ptemp, MCU_PAGE_SIZE);
		else
			res = UpdateOnePage(pDevice,currentpage, ptemp, tempsize);
		if(tempsize == MCU_PAGE_SIZE && flength != 32*1024)
		{
			//it's a special case, it's to write the checksum and totallength 
			//to the end of APROM
			ptemp = read_buf;
			RtlFillMemory( ptemp, 0x10, 0 );
		//	memset(ptemp, 0, 0x10);
			res = UpdateOnePage(pDevice,currentpage+1, ptemp, 0x10);
			break;
		}
		if(tempsize < MCU_PAGE_SIZE)
			break;
		tempsize -= MCU_PAGE_SIZE;
		ptemp += MCU_PAGE_SIZE;
		currentpage++;
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "Update page, current page %d...\n", currentpage);
	}

	MySleep(100);

//Action 9
//Jump back to APROM again
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "Run APROM \n");
	UpdateAP_Tx[0] = CMD_RUN_APROM;
	UpdateAP_Rx[0] = 0;
	i2c_access_LDROM(pDevice,0x36, 1, UpdateAP_Tx, 0, 0);
	MySleep(1500);		//for a new MCU, 2014, 08, 05
	MySleep(1500);		//for a new MCU, 2014, 08, 05

	{
		unsigned char aprom[ 3 ] = { 0, 0, 0 };
		unsigned char mcucode[3] = { 0, 0, 0 };
		unsigned int aprom_date;
		MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(pDevice->m_pCustomSystemConfigProperty);
	
		GetMCUROMVersion(pDevice, aprom, mcucode);
		aprom_date = 0;
		if(mcucode[0] == 0x51 && mcucode[1] == 0x10 && mcucode[2] == 0x27)
			aprom_date = (unsigned int)aprom[0]*10000+aprom[1]*100+aprom[2];
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "Run APROM date: %d\n", aprom_date);
		p_sys_cfg->n_mcu_version = aprom_date;
		if(aprom_date > 170820)
		{
			int i;

			i = 0;
			while(1)
			{
				unsigned char txbuf[3], rxbuf[3];
				txbuf[0] = 0x12;
				txbuf[1] = 0x34;
				txbuf[2] = 0x5a;	//0x56 ==> 51 10 27
				mcu_i2c_access(pDevice,0x55, 3, txbuf, 3, rxbuf);
				F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::EnableSecurity (0x%x, 0x%x, 0x%x) \n", rxbuf[0], rxbuf[1], rxbuf[2]);
				if(rxbuf[0] == 0xaa && rxbuf[1] == 0x55 && rxbuf[2] == 0x27)
				break;
				MySleep(200);
				i++;
				if(i > 50)
					break;
			}
		}
		if(aprom_date == 0)
			return 1;
		else
			return UPDATE_SUCCESS;
	}
	return UPDATE_SUCCESS;
}


void GetMCUROMVersion(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice,unsigned char *aprom, unsigned char *mcucode)
{
	unsigned char txbuf[16];
	unsigned char rxbuf[16];
	int i;
	struct D_CMD_GET_ROMINFO rominfo;
	MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(pDevice->m_pCustomSystemConfigProperty);

//Step 1: make sure the MCU is working fine
//get the MCU key word
	i = 0;
	while(1)
	{
		txbuf[0] = 0x12;
		txbuf[1] = 0x34;
		txbuf[2] = 0x57;	//0x56 ==> 51 10 27
		mcu_i2c_access(pDevice,0x55, 3, txbuf, 3, rxbuf);
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::AP ROM flag (0x%x, 0x%x, 0x%x) \n", rxbuf[0], rxbuf[1], rxbuf[2]);
		if(rxbuf[0] == 0x51 && rxbuf[1] == 0x10 && rxbuf[2] == 0x27)
		{   
			break;
		}
		if(rxbuf[0] == 0x51 && rxbuf[1] == 0x10 && rxbuf[2] == 0x28)
		{   
			break;
		}
		i++;
		if(i >= 5)
			return;			//something wrong in the MCU, not in the LD rom and AP rom
		MySleep(300); // [2017.12.05] [HUENGPEI] FIX MCU VERSION 0.0 ISSUE
	}
	mcucode[0] = rxbuf[0];
	mcucode[1] = rxbuf[1];
	mcucode[2] = rxbuf[2];

	while(1)
	{
	/* get APROM version */
	txbuf[0] = 0x12;
	txbuf[1] = 0x34;
	txbuf[2] = 0x58;	//0x56 ==> 51 10 27
	mcu_i2c_access(pDevice,0x55, 3, txbuf, 3, rxbuf);
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::APROM version(0x%x, 0x%x, 0x%x) \n", rxbuf[0], rxbuf[1], rxbuf[2]);
		if(rxbuf[0] >= 17 &&  rxbuf[0] <= 79)		//under 0x51	
		{
			aprom[0] = rxbuf[0];
			aprom[1] = rxbuf[1];
			aprom[2] = rxbuf[2];
			break;
		}
		MySleep(200);
		i++;
		if(i >= 50)
			return;			//something wrong in the MCU, not in the LD rom and AP rom
	}
	return;				//now in the APROM
}


void Jump2LDROM(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice,unsigned char *ldrom)
{
	unsigned char txbuf[32];
	unsigned char rxbuf[32];
	int i;
	struct D_CMD_GET_ROMINFO rominfo;

	//Jump to LD ROM
	i = 0;
//	while(1)
		{
		txbuf[0] = 0x03;
		txbuf[1] = 0x0D;
		txbuf[2] = 0x12;
		txbuf[3] = 0x04;	
		txbuf[4] = 0x86;
		txbuf[5] = 0x54;
		txbuf[6] = 0x06;	
		txbuf[7] = 0xAA;
		mcu_i2c_access(pDevice,0x55, 8, txbuf, 0, rxbuf);		//do not need to read anything
//		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::Jump2LDROM (0x%x, 0x%x, 0x%x)\n", rxbuf[0], rxbuf[1], rxbuf[2]);
//		if(rxbuf[0] == 0x45 && rxbuf[1] == 0x67 && rxbuf[2] == 0x89)
//		{
//			break;
//		}
		
	}

	MySleep(1000);

#if 0
	{
		//Get LD ROM information
		//Check the I2C bus check if is in the LD ROM or not
		txbuf[0] = CMD_GET_ROMINFO;
		rxbuf[0] = 0;
		i2c_access_LDROM(pDevice,0x36, 1, txbuf, sizeof(struct D_CMD_GET_ROMINFO), (unsigned char *)&rominfo);
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::LDROM firmversion 0x%x \n", rominfo.firmversion);
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::LDROM pdid 0x%x \n", rominfo.pdid);
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::LDROM reserve1 0x%x \n", rominfo.reserve1);
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::LDROM reserve2 0x%x \n", rominfo.reserve2);
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::LDROM config0 0x%x \n", rominfo.config0);
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::LDROM config1 0x%x \n", rominfo.config1);
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::LDROM aprom_checksum 0x%x \n", rominfo.aprom_checksum);
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::LDROM aprom_len 0x%x \n", rominfo.aprom_len);
	}
	if(rominfo.reserve1 == 0xaa && rominfo.reserve2 == 0x55)
		*ldrom = rominfo.firmversion;	//should be 0x13
	else
		*ldrom = 0;
#endif
}

//daniel, 2017, 3, 17
int UpdateEDID(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, unsigned char *edid_buf)
{
	unsigned char txbuf[8];
	unsigned char rxbuf[8];
	int i, checksum;
	MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(pDevice->m_pCustomSystemConfigProperty);
	
	if( p_sys_cfg->n_mcu_version == 0)
	{
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "UpdateEDID, mcu version = 0 \n");
		return 0;
	}
	i = 0;
	txbuf[0] = 0x12;
	txbuf[1] = 0x34;
	txbuf[2] = 0x59;
	mcu_i2c_access(pDevice,0x55, 3, txbuf, 3, rxbuf);
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::Enter UpdateEDID (0x%x, 0x%x, 0x%x) \n", rxbuf[0], rxbuf[1], rxbuf[2]);
	for(i = 0;i < 50;i++)
	{
		if(rxbuf[0] == 0x51 && rxbuf[1] == 0x10 && rxbuf[2] == 0x30)
			break;
		MySleep(100);
		mcu_i2c_access(pDevice,0x55, 0, txbuf, 3, rxbuf);
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::Enter UpdateEDID %d (0x%x, 0x%x, 0x%x) \n", i, rxbuf[0], rxbuf[1], rxbuf[2]);
	}
	if(rxbuf[0] == 0x51 && rxbuf[1] == 0x10 && rxbuf[2] == 0x30)
	{
		checksum = 0;
		for(i = 0;i < 256;i += 16)
		{
			int j = 0;
			for(j = 0;j < 16;j++)
				checksum += edid_buf[i+j];
			int ret = i2c_write_bytes(pDevice, 0x66, edid_buf+i, 16);
			F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::send EDID data (0x%x) ret(0x%x)\n", i, ret);
		}
	}
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::update EDID checksum (0x%x) \n", checksum);
	i = 0;
	while(1)
	{
		MySleep(300);
		txbuf[0] = 0xcc;
		mcu_i2c_access(pDevice,0x55, 3, txbuf, 3, rxbuf);
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::Exit UpdateEDID wait %d (0x%x, 0x%x, 0x%x) \n", i, rxbuf[0], rxbuf[1], rxbuf[2]);
		if(rxbuf[0] == 0x51 && rxbuf[1] == 0x10 && rxbuf[2] == 0x31)
			break;
		i++;
		if(i == 3)
			break;
	}
	//the si9777 is update EDID now, wait until MCU is ready
	while(1)
	{
		/* get APROM version */
		txbuf[0] = 0x12;
		txbuf[1] = 0x34;
		txbuf[2] = 0x58;
		mcu_i2c_access(pDevice,0x55, 3, txbuf, 3, rxbuf);
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::APROM version(0x%x, 0x%x, 0x%x) \n", rxbuf[0], rxbuf[1], rxbuf[2]);
		if(rxbuf[0] >= 17 &&  rxbuf[0] <= 37 && rxbuf[1] < 12 && rxbuf[2] < 31)		//under 0x51	
			break;
		MySleep(200);
		i++;
		if(i >= 50)
			return 1;	//something wrong in the MCU, not in the LD rom and AP rom
	}

	return 1;
}

//daniel, 2017, 5, 15
int ReadEDID(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, unsigned char *edid_buf, BYTE id )
{
	unsigned char txbuf[8];
	unsigned char rxbuf[8];
	int i, checksum;
	MZ0380_SYS_CFG * p_sys_cfg = (MZ0380_SYS_CFG *)(pDevice->m_pCustomSystemConfigProperty);
	
	if( p_sys_cfg->n_mcu_version == 0)
	{
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "ReadEDID, mcu version = 0 \n");
		return 0;
	}


	txbuf[0] = 0x12;
	txbuf[1] = 0x34;
	txbuf[2] = id;
	mcu_i2c_access(pDevice,0x55, 3, txbuf, 3, rxbuf);
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::Enter ReadEDID (0x%x, 0x%x, 0x%x) \n", rxbuf[0], rxbuf[1], rxbuf[2]);
	for(i = 0;i < 50;i++)
	{
		if(rxbuf[0] == 0x51 && rxbuf[1] == 0x10 && rxbuf[2] == 0x35)
			break;
		MySleep(100);
		mcu_i2c_access(pDevice,0x55, 0, txbuf, 3, rxbuf);
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::Enter ReadEDID %d (0x%x, 0x%x, 0x%x) \n", i, rxbuf[0], rxbuf[1], rxbuf[2]);
	}
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "F42A18AF66EFF459eA332CA253FFF8A65::Enter ReadEDID\n");
	MySleep(100);
	for(i = 0;i < 256;i += 16)
	{
		txbuf[0] = 0x55;
		txbuf[1] = (BYTE)i;
		i2c_write_bytes(pDevice, 0x66, txbuf, 2);
		i2c_read_bytes(pDevice, 0x66, edid_buf+i, 16);
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "Read EDID 0x%x, (0x%x 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x) \n", i, 
			edid_buf[i], edid_buf[i+1], edid_buf[i+2], edid_buf[i+3], edid_buf[i+4], edid_buf[i+5], edid_buf[i+6], edid_buf[i+7],
			edid_buf[i+8], edid_buf[i+9], edid_buf[i+10], edid_buf[i+11], edid_buf[i+12], edid_buf[i+13], edid_buf[i+14], edid_buf[i+15]);
	}
	checksum = 0;
	for(i = 0;i < 256;i++)
	{
		checksum += edid_buf[i];
	}
	F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "read EDID data checksum 0x%x \n", checksum);
	i = 0;
	while(1)
	{
		txbuf[0] = 0xcc;
		mcu_i2c_access(pDevice,0x55, 3, txbuf, 3, rxbuf);
		F1838C0176E054c129B7F2BF440D1236E( KERN_INFO, "Exit ReadEDID wait %d (0x%x, 0x%x, 0x%x) \n", i, rxbuf[0], rxbuf[1], rxbuf[2]);
		if(rxbuf[0] == 0x51 && rxbuf[1] == 0x10 && rxbuf[2] == 0x31)
			return 0;
		i++;
		MySleep(100);
		if(i == 3)
			break;
	}

	txbuf[0] = 0x00;
	txbuf[1] = 0x00;		//a dummy write here
	i2c_write_bytes(pDevice, 0x66, txbuf, 2);
	return 1;
}