#ifndef __UPAPROM_H__
#define __UPAPROM_H__
#include "LINUXV4L2.h"

void MySleep( int ms );	//unit: 1/1000 second
int i2c_write_bytes( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, unsigned char devaddr, unsigned char *txbuf, unsigned int txcount);
int i2c_read_bytes( F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, unsigned char devaddr, unsigned char *rxbuf, unsigned int rxcount);
int mcu_i2c_access(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, unsigned char devaddr, unsigned int txcount, unsigned char *txbuf, unsigned int rxcount, unsigned char *rxbuf);
int WaitI2CReady_LDROM(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, int count);
int i2c_access_LDROM(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, unsigned char devaddr, unsigned int txcount, unsigned char *txbuf, unsigned int rxcount, unsigned char *rxbuf);
void GetMCUROMVersion(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, unsigned char *aprom, unsigned char *mcucode);
void Jump2LDROM(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, unsigned char *ldrom);
int UpdateEDIDContent(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, unsigned char *buf);
int i2c_access_LDROM(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, unsigned char devaddr, unsigned int txcount, unsigned char *txbuf, unsigned int rxcount, unsigned char *rxbuf);
int UpdateOnePage(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, unsigned int pageno, unsigned char *fbuf, unsigned int pagesize);
int CheckLD_ROM_Idle(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice);
int TestI2C(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice);
int UpdateAPROM(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice,unsigned char *bin_name, unsigned char * read_buf, unsigned int flength);
void GetMCUROMVersion(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice,unsigned char *aprom, unsigned char *mcucode);
int UpdateEDID(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, unsigned char *edid_buf);
int ReadEDID(F42A18AF66EFF459eA332CA253FFF8A65 * pDevice, unsigned char *edid_buf, BYTE id );

#endif